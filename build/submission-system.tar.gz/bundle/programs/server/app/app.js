var require = meteorInstall({"imports":{"api":{"entry.ts":function(require,exports,module){

////////////////////////////////////////////////////////////////////////
//                                                                    //
// imports/api/entry.ts                                               //
//                                                                    //
////////////////////////////////////////////////////////////////////////
                                                                      //
module.export({
  EntryType: () => EntryType,
  VerificationStatus: () => VerificationStatus,
  Entries: () => Entries
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
var EntryType;

(function (EntryType) {
  EntryType["VIDEO"] = "entry_video";
  EntryType["DOCUMENT"] = "entry_document";
})(EntryType || module.runSetters(EntryType = {}));

var VerificationStatus;

(function (VerificationStatus) {
  VerificationStatus["WAITING"] = "status_waiting";
  VerificationStatus["VERIFIED"] = "status_verified";
  VerificationStatus["REJECTED"] = "status_rejected";
  VerificationStatus["DISPUTED"] = "status_disputed";
})(VerificationStatus || module.runSetters(VerificationStatus = {}));

const Entries = new Mongo.Collection('entries');
////////////////////////////////////////////////////////////////////////

}}},"server":{"main.ts":function(require,exports,module){

////////////////////////////////////////////////////////////////////////
//                                                                    //
// server/main.ts                                                     //
//                                                                    //
////////////////////////////////////////////////////////////////////////
                                                                      //
module.link("../imports/api/entry");
////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".tsx"
  ]
});

var exports = require("/server/main.ts");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZW50cnkudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsT0FBTyxNQUFQLENBQWM7QUFBQSxXQUFRLGlCQUFSO0FBQXNCLDhDQUF0QjtBQUFzQjtBQUF0QixDQUFkO0FBQW9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFFcEMsSUFBWSxTQUFaOztBQUFBLFdBQVksU0FBWixFQUFxQjtBQUNwQjtBQUNBO0FBQ0EsQ0FIRCxFQUFZLFNBQVMsc0JBQVQsU0FBUyxNQUFyQjs7QUFLQSxJQUFZLGtCQUFaOztBQUFBLFdBQVksa0JBQVosRUFBOEI7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUxELEVBQVksa0JBQWtCLHNCQUFsQixrQkFBa0IsTUFBOUI7O0FBbUNPLE1BQU0sT0FBTyxHQUFHLElBQUksS0FBSyxDQUFDLFVBQVYsQ0FBNEIsU0FBNUIsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUMxQ1AsT0FBTyxJQUFQLENBQU8sc0JBQVAsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXG5cbmV4cG9ydCBlbnVtIEVudHJ5VHlwZSB7XG5cdFZJREVPID0gJ2VudHJ5X3ZpZGVvJyxcblx0RE9DVU1FTlQgPSAnZW50cnlfZG9jdW1lbnQnXG59XG5cbmV4cG9ydCBlbnVtIFZlcmlmaWNhdGlvblN0YXR1cyB7XG5cdFdBSVRJTkcgPSAnc3RhdHVzX3dhaXRpbmcnLFxuXHRWRVJJRklFRCA9ICdzdGF0dXNfdmVyaWZpZWQnLFxuXHRSRUpFQ1RFRCA9ICdzdGF0dXNfcmVqZWN0ZWQnLFxuXHRESVNQVVRFRCA9ICdzdGF0dXNfZGlzcHV0ZWQnXG59XG5cbi8qKiBCYXNlIGludGVyZmFjZSBmb3IgZW50cmllcywgc2hvdWxkbid0IGJlIHVzZWQgb24gaXRzIG93biBidXQgYXMgYW4gaW5oZXJpdGVkIGludGVyZmFjZS4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRW50cnlCYXNlIHtcblx0LyoqIEdlbmVyYXRlZCBieSBkYXRhYmFzZS4gKi9cblx0X2lkPzogc3RyaW5nXG5cdC8qKiBUaGUgZW50cnkgdHlwZS4gKi9cblx0dHlwZTogRW50cnlUeXBlXG5cdC8qKiBTdG9yZXMgd2hldGhlciB0aGUgZW50cnkgaGFzIGJlZW4gdmVyaWZpZWQgYnkgYSBodW1hbiBvcGVyYXRvci4gKi9cblx0dmVyaWZpY2F0aW9uU3RhdHVzOiBWZXJpZmljYXRpb25TdGF0dXNcblx0LyoqIEhvdyBtYW55IHRpbWVzIGFuIGVudHJ5IGhhcyBiZWVuIGRpc3B1dGVkLiAqL1xuXHRkaXNwdXRlQ291bnQ/OiBudW1iZXJcbn1cblxuLyoqIEludGVyZmFjZSBmb3IgdmlkZW8gZW50cmllcy4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVmlkZW9FbnRyeSBleHRlbmRzIEVudHJ5QmFzZSB7XG5cdHR5cGU6IEVudHJ5VHlwZS5WSURFT1xuXHQvKiogV2hldGhlciB0aGUgZmlsZSBwYXNzZXMgYXV0b21hdGVkIHRlY2huaWNhbCByZXF1aXJlbWVudHMgY2hlY2tzLiAqL1xuXHRmb3JtYXRWYWxpZGF0ZWQ/OiBib29sZWFuXG59XG5cbi8qKiBJbnRlcmZhY2UgZm9yIGRvY3VtZW50IGVudHJpZXMuICovXG5leHBvcnQgaW50ZXJmYWNlIERvY3VtZW50RW50cnkgZXh0ZW5kcyBFbnRyeUJhc2Uge1xuXHR0eXBlOiBFbnRyeVR5cGUuRE9DVU1FTlRcblx0LyoqIE5hbWUgb2YgdGhlIHVwbG9hZGVkIGZpbGUuICovXG5cdHVwbG9hZGVkRmlsZTogc3RyaW5nXG59XG5cbmV4cG9ydCB0eXBlIEVudHJ5ID0gVmlkZW9FbnRyeSB8IERvY3VtZW50RW50cnlcblxuZXhwb3J0IGNvbnN0IEVudHJpZXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbjxFbnRyeT4oJ2VudHJpZXMnKVxuIiwiaW1wb3J0ICcuLi9pbXBvcnRzL2FwaS9lbnRyeSdcbiJdfQ==
