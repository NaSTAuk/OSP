var require = meteorInstall({"imports":{"api":{"helpers":{"constants.ts":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/helpers/constants.ts                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  MINUTE: () => MINUTE
});
const MINUTE = 60 * 1000;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"enums.ts":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/helpers/enums.ts                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  Collections: () => Collections,
  Roles: () => Roles,
  DEFAULT_AWARDS_NAMES: () => DEFAULT_AWARDS_NAMES,
  SupportingEvidenceType: () => SupportingEvidenceType,
  EntryType: () => EntryType,
  VerificationStatus: () => VerificationStatus,
  DEFAULT_CATEGORY_NAMES: () => DEFAULT_CATEGORY_NAMES
});
var Collections;

(function (Collections) {
  Collections["AWARDS"] = "awards";
  Collections["CATEGORIES"] = "categories";
  Collections["STATIONS"] = "stations";
  Collections["SUPPORTING_EVIDENCE"] = "supporting_evidence";
  Collections["ENTRIES"] = "entries";
  Collections["EVIDENCE"] = "evidence";
  Collections["JudgeToCategory"] = "judgeToCategory";
  Collections["SCORES"] = "scores";
  Collections["RESULTS"] = "results";
  Collections["SYSTEM"] = "system";
})(Collections || module.runSetters(Collections = {}));

var Roles;

(function (Roles) {
  Roles["UNASSIGNED"] = "unassigned";
  Roles["HOST"] = "host";
  Roles["JUDGE"] = "judge";
  Roles["STATION"] = "station";
  Roles["ADMIN"] = "admin";
})(Roles || module.runSetters(Roles = {}));

var DEFAULT_AWARDS_NAMES;

(function (DEFAULT_AWARDS_NAMES) {
  DEFAULT_AWARDS_NAMES["NASTA"] = "NaSTA Awards";
  DEFAULT_AWARDS_NAMES["PEOPLES_CHOICE"] = "People's Choice Awards";
})(DEFAULT_AWARDS_NAMES || module.runSetters(DEFAULT_AWARDS_NAMES = {}));

var SupportingEvidenceType;

(function (SupportingEvidenceType) {
  SupportingEvidenceType["VIDEO"] = "VIDEO";
  SupportingEvidenceType["TEXT"] = "TEXT";
  SupportingEvidenceType["PDF"] = "PDF";
  SupportingEvidenceType["CALL"] = "CALL";
})(SupportingEvidenceType || module.runSetters(SupportingEvidenceType = {}));

var EntryType;

(function (EntryType) {
  EntryType["VIDEO"] = "entry_video";
  EntryType["DOCUMENT"] = "entry_document";
})(EntryType || module.runSetters(EntryType = {}));

var VerificationStatus;

(function (VerificationStatus) {
  VerificationStatus["WAITING"] = "status_waiting";
  VerificationStatus["VERIFIED"] = "status_verified";
  VerificationStatus["REJECTED"] = "status_rejected";
  VerificationStatus["DISPUTED"] = "status_disputed";
})(VerificationStatus || module.runSetters(VerificationStatus = {}));

var DEFAULT_CATEGORY_NAMES;

(function (DEFAULT_CATEGORY_NAMES) {
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_BEST_BROADCASTER"] = "Best Broadcaster";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_JISC"] = "Jisc award for Special Recognition";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_BEST_DRAMATIC_PERFORMANCE"] = "Best Dramatic Performance";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_BEST_ON_SCREEN_TALENT"] = "Best On-Screen Talent";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_STATION_MARKETING"] = "Station Marketing";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_TECHNICAL_ACHIEVEMENT"] = "Technical Achievement";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_FRESHERS_COVERAGE"] = "Freshers' Coverage";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_ANIMATION"] = "Animation";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_NEWS_AND_CURRENT_AFFAIRS"] = "News and Current Affairs";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_MARS_ELKINS_EL_BROGY"] = "The Mars Elkins El-Brogy Award for Multimedia Content";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_WRITING"] = "Writing";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_LIVE_BROADCAST"] = "Live Broadcast";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_CINEMATOGRAPHY"] = "Cimematography";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_LIGHT_ENTERTAINMENT"] = "Light Entertainment";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_TITLE_SEQUENCE"] = "Title Sequence";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_COMEDY"] = "Comedy";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_DRAMA"] = "Drama";
  DEFAULT_CATEGORY_NAMES["NASTA_AWARDS_DOCUMENTARY_AND_FACTUAL"] = "Documentary & Factual";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_SPORT"] = "Sport";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_POST_PRODUCTION_AWARD"] = "Post Production Award";
  DEFAULT_CATEGORY_NAMES["NaSTA_AWARDS_SUPER_BLOOPER"] = "Super Blooper";
  DEFAULT_CATEGORY_NAMES["PCAs_OPEN"] = "Open";
  DEFAULT_CATEGORY_NAMES["PCAs_LIVE_BROADCAST"] = "Live Broadcast";
  DEFAULT_CATEGORY_NAMES["PCAs_CONTENT_INNOVATION"] = "Content Innovation";
  DEFAULT_CATEGORY_NAMES["PCAs_TECHNICAL_INNOVATION"] = "Technical Innovation";
  DEFAULT_CATEGORY_NAMES["PCAs_VISUAL_CREATIVITY_AND_QUALITY"] = "Visual Creativity & Quality";
  DEFAULT_CATEGORY_NAMES["PCAs_BEST_ON_SCREEN_TALENT"] = "Best On-Screen Talent";
  DEFAULT_CATEGORY_NAMES["PCAs_UN_SUNG_HERO"] = "Un-Sung Hero";
  DEFAULT_CATEGORY_NAMES["PCAs_STATION_OF_THE_YEAR"] = "Station Of The Year";
})(DEFAULT_CATEGORY_NAMES || module.runSetters(DEFAULT_CATEGORY_NAMES = {}));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.ts":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/helpers/methods.ts                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  DROPBOX_TOKEN: () => DROPBOX_TOKEN
});
let Dropbox;
module.link("dropbox", {
  Dropbox(v) {
    Dropbox = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let fetch;
module.link("node-fetch", {
  default(v) {
    fetch = v;
  }

}, 3);
let UserHasRole;
module.link("../accounts", {
  UserHasRole(v) {
    UserHasRole = v;
  }

}, 4);
let Categories;
module.link("../categories", {
  Categories(v) {
    Categories = v;
  }

}, 5);
let Entries;
module.link("../entries", {
  Entries(v) {
    Entries = v;
  }

}, 6);
let EvidenceCollection, InsertEvidence;
module.link("../evidence", {
  EvidenceCollection(v) {
    EvidenceCollection = v;
  },

  InsertEvidence(v) {
    InsertEvidence = v;
  }

}, 7);
let JudgeToCategory;
module.link("../judgeToCategory", {
  JudgeToCategory(v) {
    JudgeToCategory = v;
  }

}, 8);
let Results;
module.link("../results", {
  Results(v) {
    Results = v;
  }

}, 9);
let Scores;
module.link("../scores", {
  Scores(v) {
    Scores = v;
  }

}, 10);
let GetStationForUser, Stations;
module.link("../stations", {
  GetStationForUser(v) {
    GetStationForUser = v;
  },

  Stations(v) {
    Stations = v;
  }

}, 11);
let Roles, SupportingEvidenceType, VerificationStatus;
module.link("./enums", {
  Roles(v) {
    Roles = v;
  },

  SupportingEvidenceType(v) {
    SupportingEvidenceType = v;
  },

  VerificationStatus(v) {
    VerificationStatus = v;
  }

}, 12);
const DROPBOX_TOKEN = Meteor.settings.dropbox.accessToken;
const dbx = new Dropbox({
  accessToken: DROPBOX_TOKEN,
  fetch
});

function b64ToBuffer(b64Encoding) {
  const index = b64Encoding.indexOf(';base64,');
  return new Buffer(b64Encoding.slice(index + ';base64,'.length), 'base64');
}

function GetSharingLink(filePathLower) {
  return new Promise((resolve, reject) => {
    dbx.sharingCreateSharedLinkWithSettings({
      path: filePathLower,
      settings: {
        requested_visibility: {
          '.tag': 'public'
        },
        audience: {
          '.tag': 'public'
        }
      }
    }).then(result => {
      resolve(result.url);
    }).catch(err => {
      reject(err);
    });
  });
}

Meteor.methods({
  'submission.startSession'(chunk) {
    return Promise.asyncApply(() => {
      check(chunk, String);
      console.log('Starting new upload session');
      return dbx.filesUploadSessionStart({
        contents: b64ToBuffer(chunk),
        close: false
      }).catch(err => {
        return Promise.reject(err);
      }).then(result => {
        return Promise.resolve(result.session_id);
      });
    });
  },

  'submission.uploadChunk'(chunk, sessionId, chunkSize, chunkNumber, finish, path) {
    return Promise.asyncApply(() => {
      check(chunk, String);
      check(sessionId, String);
      check(chunkSize, Number);
      check(chunkNumber, Number);
      check(finish, Boolean);
      check(path, String);
      console.log("Uploading offset ".concat(chunkNumber * chunkSize));

      if (finish) {
        return dbx.filesUploadSessionFinish({
          contents: b64ToBuffer(chunk),
          cursor: {
            session_id: sessionId,
            offset: chunkSize * chunkNumber
          },
          commit: {
            path,
            mode: {
              '.tag': 'add'
            }
          }
        }).catch(err => {
          return Promise.reject(err);
        }).then(result => {
          return Promise.resolve(result.path_lower);
        });
      } else {
        return dbx.filesUploadSessionAppend({
          contents: b64ToBuffer(chunk),
          session_id: sessionId,
          offset: chunkNumber * chunkSize
        }).catch(err => {
          return Promise.reject(err);
        }).then(result => {
          return Promise.resolve(result);
        });
      }
    });
  },

  'submission.uploadFile'(b64Encoding, path) {
    return Promise.asyncApply(() => {
      check(b64Encoding, String);
      check(path, String);
      const file = b64ToBuffer(b64Encoding);

      if (file.length > 100 * 1024 * 1024) {
        console.log('Too large');
        return; // TODO: Send some error
      }

      return dbx.filesUpload({
        contents: file,
        path
      }).catch(error => {
        console.log(error);
      }).then(result => {
        if (result) {
          return Promise.resolve(result.path_lower);
        }

        console.log('Uploaded a small file');
      });
    });
  },

  'submission.submit'(values, categoryId) {
    return Promise.asyncApply(() => {
      console.log(JSON.stringify(values));
      check(categoryId, String);

      if (Meteor.userId()) {
        const station = GetStationForUser();

        if (!station) {
          return new Meteor.Error('You do not belong to an eligible station');
        }

        if (!station._id) {
          return new Meteor.Error('You do not belong to an eligible station');
        }

        const category = Categories.findOne({
          _id: categoryId
        });

        if (!category) {
          return new Meteor.Error('Category not found');
        }

        let allPresent = true;
        category.supportingEvidence.forEach(ev => {
          if (!Object.keys(values).includes(ev._id) && ev.type !== SupportingEvidenceType.CALL) {
            allPresent = false;
          }
        });

        if (!allPresent) {
          return new Meteor.Error('You have not provided all required evidence for this submission');
        }

        const evidence = []; // tslint:disable-next-line: forin

        for (const support of category.supportingEvidence) {
          if (!support._id) {
            continue;
          }

          let id = '';

          if (support.type === SupportingEvidenceType.CALL) {
            id = Promise.await(InsertEvidence({
              type: SupportingEvidenceType.CALL,
              content: 'Call Required',
              verified: false,
              supportingEvidenceId: support._id,
              awardId: categoryId,
              stationId: station._id
            }));
          } else {
            if (support.type === SupportingEvidenceType.VIDEO || support.type === SupportingEvidenceType.PDF) {
              let sharingLink = '';
              let shortClipSharingLink = '';

              try {
                sharingLink = Promise.await(GetSharingLink(values[support._id]));
              } catch (error) {
                if (error.error.error['.tag'] === 'shared_link_already_exists') {
                  const prev = EvidenceCollection.findOne({
                    stationId: station._id,
                    awardId: categoryId,
                    supportingEvidenceId: support._id
                  });

                  if (prev && prev.sharingLink.length) {
                    sharingLink = prev.sharingLink;
                  } else {
                    throw new Error('Something went wrong, please try again');
                  }
                }
              }

              if (values["".concat(support._id, "10Sec")]) {
                try {
                  shortClipSharingLink = Promise.await(GetSharingLink(values["".concat(support._id, "10Sec")]));
                } catch (error) {
                  if (error.error.error['.tag'] === 'shared_link_already_exists') {
                    const prev = EvidenceCollection.findOne({
                      stationId: station._id,
                      awardId: categoryId,
                      supportingEvidenceId: support._id
                    });

                    if (prev && prev.shortClipSharingLink.length) {
                      shortClipSharingLink = prev.shortClipSharingLink;
                    } else {
                      throw new Error('Something went wrong, please try again');
                    }
                  }
                }
              }

              id = Promise.await(InsertEvidence({
                type: support.type,
                content: values[support._id],
                verified: false,
                supportingEvidenceId: support._id,
                awardId: categoryId,
                stationId: station._id,
                sharingLink,
                shortClipSharingLink
              }));
            } else {
              id = Promise.await(InsertEvidence({
                type: support.type,
                content: values[support._id],
                verified: support.type === SupportingEvidenceType.TEXT,
                supportingEvidenceId: support._id,
                awardId: categoryId,
                stationId: station._id
              }));
            }
          }

          evidence.push(id);
        }

        Entries.insert({
          stationId: station._id,
          categoryId,
          date: Date.now(),
          evidenceIds: evidence,
          videoLinks: values.LINKS,
          verified: VerificationStatus.WAITING
        }, error => {
          if (error) return new Meteor.Error(error);
          return Promise.resolve();
        });
      } else {
        return new Meteor.Error('You\'re not logged in');
      }
    });
  },

  'role.add'(role, userId) {
    check(userId, String);
    if (!Meteor.userId() || !UserHasRole([Roles.ADMIN])) return;
    const user = Meteor.users.findOne({
      _id: userId
    });
    if (!user) return;
    if (user.roles.includes(role)) return;
    Meteor.users.update(userId, {
      $set: {
        roles: [...user.roles, role]
      }
    });
  },

  'role.remove'(role, userId) {
    check(userId, String);
    if (!Meteor.userId() || !UserHasRole([Roles.ADMIN])) return;
    const user = Meteor.users.findOne({
      _id: userId
    });
    if (!user) return;

    if (user.roles.includes(role)) {
      Meteor.users.update(userId, {
        $set: {
          roles: user.roles.filter(r => r !== role)
        }
      });
    }
  },

  'station.add'(name) {
    check(name, String);
    if (!Meteor.userId() || !UserHasRole([Roles.ADMIN])) return;
    const exists = Stations.find({
      name
    }).fetch();
    if (exists.length) return;
    Stations.insert({
      name,
      eligibleForEntry: true,
      authorizedUsers: []
    });
  },

  'station.delete'(id) {
    check(id, String);
    if (!Meteor.userId() || !UserHasRole([Roles.ADMIN])) return;
    const exists = Stations.find({
      _id: id
    }).fetch();
    if (!exists.length) return;
    Stations.remove({
      _id: id
    });
    Meteor.users.find({
      stationId: id
    }).fetch().forEach(user => {
      Meteor.users.remove({
        _id: user._id
      });
    });
  },

  'comments.add'(stationId, categoryId, judgedBy, comments) {
    return Promise.asyncApply(() => {
      check(stationId, String);
      check(categoryId, String);
      check(judgedBy, String);
      check(comments, String);
      return new Promise((resolve, reject) => {
        const existing = Scores.findOne({
          stationId,
          categoryId,
          judgedBy
        });

        if (existing) {
          Scores.update({
            _id: existing._id
          }, {
            stationId,
            categoryId,
            judgedBy,
            comments,
            date: Date.now()
          }, {}, error => {
            if (error) reject(error);
            resolve();
          });
        } else {
          Scores.insert({
            stationId,
            categoryId,
            judgedBy,
            comments,
            date: Date.now()
          }, error => {
            if (error) reject(error);
            resolve();
          });
        }
      });
    });
  },

  'result.set'(categoryId, result, jointFirst, jointHighlyCommended) {
    return Promise.asyncApply(() => {
      return new Promise((resolve, reject) => {
        const id = Meteor.userId();
        if (!id) return reject(); // TODO: Add judgedBy if allowing two judges per category to have different orderings.

        const existing = Results.findOne({
          categoryId
        });

        if (existing) {
          Results.update({
            _id: existing._id
          }, {
            categoryId,
            judgedBy: id,
            jointFirst,
            jointHighlyCommended,
            order: result
          }, {}, err => {
            if (err) reject();
            resolve();
          });
        } else {
          Results.insert({
            categoryId,
            judgedBy: id,
            jointFirst,
            jointHighlyCommended,
            order: result
          }, err => {
            if (err) reject();
            resolve();
          });
        }
      });
    });
  },

  'setJudgeToCategory'(judgeId, categoryId) {
    return Promise.asyncApply(() => {
      check(judgeId, String);
      check(categoryId, String);
      return new Promise((resolve, reject) => {
        const toCat = JudgeToCategory.findOne({
          judgeId
        });

        if (toCat) {
          JudgeToCategory.update({
            _id: toCat._id
          }, {
            categoryId,
            judgeId
          }, {}, err => {
            if (err) reject(err);
            resolve();
          });
        } else {
          JudgeToCategory.insert({
            categoryId,
            judgeId
          }, err => {
            if (err) reject(err);
            resolve();
          });
        }
      });
    });
  },

  'entry:setVerification'(entryId, status) {
    check(entryId, String);
    Entries.update({
      _id: entryId
    }, {
      $set: {
        verified: status
      }
    });
  },

  'evidence:setVerified'(evidenceId, checked) {
    return Promise.asyncApply(() => {
      check(evidenceId, String);
      check(checked, Boolean);
      return new Promise((resolve, _reject) => {
        EvidenceCollection.update({
          _id: evidenceId
        }, {
          $set: {
            verified: checked
          }
        }, {}, () => {
          resolve();
        });
      });
    });
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"accounts.ts":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/accounts.ts                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
module.export({
  GetUserFromId: () => GetUserFromId,
  UserHasRole: () => UserHasRole
});
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 3);
let Roles;
module.link("./helpers/enums", {
  Roles(v) {
    Roles = v;
  }

}, 4);
let Stations;
module.link("./stations", {
  Stations(v) {
    Stations = v;
  }

}, 5);

if (Meteor.isServer) {
  Accounts.onCreateUser((options, user) => {
    const nastaUser = _objectSpread({}, user, {
      roles: [Roles.STATION] // TODO: Replace

    });

    if (options.profile) {
      nastaUser.profile = options.profile;
    }

    return nastaUser;
  });
  Accounts.emailTemplates.siteName = 'NaSTA Submissions Portal';
  Accounts.emailTemplates.from = 'NaSTA Entries <entries@nasta.tv>';

  Accounts.emailTemplates.enrollAccount.subject = () => {
    return "You have been invited to the NaSTA submissions portal";
  };

  Accounts.emailTemplates.enrollAccount.text = (_user, url) => {
    return "You have been invited to the NaSTA submissions portal, click the link below to activate your account\n" + "".concat(url, "\n") + "Any issues, please contact tech@nasta.tv. Replies to this email will not be delivered.";
  };

  Accounts.urls.enrollAccount = token => {
    return Meteor.absoluteUrl("enroll-account/".concat(token));
  };

  Meteor.publish('users', () => {
    return Meteor.users.find({}, {
      fields: {
        stationId: 1,
        emails: 1,
        roles: 1
      }
    });
  });
  Meteor.publish('enrolledUser', token => {
    return Meteor.users.find({
      'services.password.reset.token': token
    });
  });
}

Meteor.methods({
  'accounts.create'(email, password) {
    check(email, String);
    check(password, String);
    Accounts.createUser({
      email,
      password
    });
  },

  'accounts.delete'(userId) {
    check(userId, String);
    Meteor.users.remove({
      _id: userId
    });
  },

  'accounts.new.withStation'(email, stationId) {
    return Promise.asyncApply(() => {
      const id = Promise.await(createAccount(email));
      const stationdb = Stations.findOne({
        _id: stationId
      });

      if (!stationdb || !stationdb._id) {
        return Promise.reject("Failed to find station: ".concat(stationId));
      }

      Promise.await(addStationIdToUser(id, stationdb._id));
      return new Promise((resolve, reject) => {
        Stations.update({
          _id: stationdb._id
        }, {
          $push: {
            authorizedUsers: id
          }
        }, {}, err => {
          if (err) reject();
          resolve();
        });
      });
    });
  },

  'accounts.new'(email) {
    return Promise.asyncApply(() => {
      check(email, String);
      const id = Promise.await(createAccount(email));
      if (!id) return Promise.reject('Failed to create user');
      Accounts.sendEnrollmentEmail(id, email);
      return Promise.resolve(id);
    });
  },

  'accounts.login'(email, password) {
    check(email, String);
    check(password, String);
    Meteor.loginWithPassword(email, password);
  },

  'accounts.setPassword'(userId, password) {
    check(userId, String);
    check(password, String);

    if (!this.isSimulation) {
      Accounts.setPassword(userId, password);
    }
  }

});

function GetUserFromId() {
  const id = Meteor.userId();

  if (id) {
    const user = Meteor.users.findOne({
      _id: id
    });

    if (user) {
      return user;
    }
  }
}

function UserHasRole(roles) {
  const user = GetUserFromId();

  if (user) {
    return roles.some(role => {
      if (user.roles.includes(role)) {
        return true;
      }
    });
  }
}

function createAccount(email) {
  if (Meteor.users.find({
    emails: {
      $elemMatch: {
        address: email
      }
    }
  }).count()) {
    throw new Meteor.Error('Email already registered');
  }

  return new Promise((resolve, reject) => {
    const id = Accounts.createUser({
      email,
      password: Random.hexString(12)
    });

    if (id) {
      resolve(id);
    } else {
      reject();
    }
  });
}

function addStationIdToUser(userId, stationId) {
  return new Promise((resolve, reject) => {
    Meteor.users.update({
      _id: userId
    }, {
      $set: {
        stationId
      }
    }, {}, err => {
      if (err) reject(err);
      resolve();
    });
  });
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"awards.ts":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/awards.ts                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  Awards: () => Awards,
  DEFAULT_AWARDS: () => DEFAULT_AWARDS,
  DEFAULT_CATEGORIES_FOR_AWARDS: () => DEFAULT_CATEGORIES_FOR_AWARDS
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let Collections, DEFAULT_AWARDS_NAMES, DEFAULT_CATEGORY_NAMES;
module.link("./helpers/enums", {
  Collections(v) {
    Collections = v;
  },

  DEFAULT_AWARDS_NAMES(v) {
    DEFAULT_AWARDS_NAMES = v;
  },

  DEFAULT_CATEGORY_NAMES(v) {
    DEFAULT_CATEGORY_NAMES = v;
  }

}, 2);
const Awards = new Mongo.Collection(Collections.AWARDS);

if (Meteor.isServer) {
  Meteor.publish(Collections.AWARDS, function awardsPublictaion() {
    if (Meteor.userId()) {
      return Awards.find();
    }
  });
}

const DEFAULT_AWARDS = [{
  name: DEFAULT_AWARDS_NAMES.NASTA,
  categories: [],
  active: true
}, {
  name: DEFAULT_AWARDS_NAMES.PEOPLES_CHOICE,
  categories: [],
  active: false
}];
const DEFAULT_CATEGORIES_FOR_AWARDS = {
  [DEFAULT_AWARDS_NAMES.NASTA]: [DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_BEST_BROADCASTER, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_JISC, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_BEST_DRAMATIC_PERFORMANCE, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_BEST_ON_SCREEN_TALENT, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_STATION_MARKETING, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_TECHNICAL_ACHIEVEMENT, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_FRESHERS_COVERAGE, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_ANIMATION, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_NEWS_AND_CURRENT_AFFAIRS, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_MARS_ELKINS_EL_BROGY, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_WRITING, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_LIVE_BROADCAST, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_CINEMATOGRAPHY, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_LIGHT_ENTERTAINMENT, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_TITLE_SEQUENCE, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_COMEDY, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_DRAMA, DEFAULT_CATEGORY_NAMES.NASTA_AWARDS_DOCUMENTARY_AND_FACTUAL, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_SPORT, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_POST_PRODUCTION_AWARD, DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_SUPER_BLOOPER],
  [DEFAULT_AWARDS_NAMES.PEOPLES_CHOICE]: [DEFAULT_CATEGORY_NAMES.PCAs_OPEN, DEFAULT_CATEGORY_NAMES.PCAs_LIVE_BROADCAST, DEFAULT_CATEGORY_NAMES.PCAs_CONTENT_INNOVATION, DEFAULT_CATEGORY_NAMES.PCAs_TECHNICAL_INNOVATION, DEFAULT_CATEGORY_NAMES.PCAs_VISUAL_CREATIVITY_AND_QUALITY, DEFAULT_CATEGORY_NAMES.PCAs_BEST_ON_SCREEN_TALENT, DEFAULT_CATEGORY_NAMES.PCAs_UN_SUNG_HERO, DEFAULT_CATEGORY_NAMES.PCAs_STATION_OF_THE_YEAR]
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"categories.ts":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/categories.ts                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  Categories: () => Categories,
  DEFAULT_CATEGORIES: () => DEFAULT_CATEGORIES
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 2);
let MINUTE;
module.link("./helpers/constants", {
  MINUTE(v) {
    MINUTE = v;
  }

}, 3);
let Collections, DEFAULT_AWARDS_NAMES, DEFAULT_CATEGORY_NAMES, SupportingEvidenceType;
module.link("./helpers/enums", {
  Collections(v) {
    Collections = v;
  },

  DEFAULT_AWARDS_NAMES(v) {
    DEFAULT_AWARDS_NAMES = v;
  },

  DEFAULT_CATEGORY_NAMES(v) {
    DEFAULT_CATEGORY_NAMES = v;
  },

  SupportingEvidenceType(v) {
    SupportingEvidenceType = v;
  }

}, 4);
const Categories = new Mongo.Collection(Collections.CATEGORIES);

if (Meteor.isServer) {
  Meteor.publish(Collections.CATEGORIES, function categoriesPublication() {
    if (Meteor.userId()) {
      return Categories.find();
    }
  });
}

const DEFAULT_CATEGORIES = [{
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_BEST_BROADCASTER,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }, {
    _id: Random.id(),
    type: SupportingEvidenceType.PDF,
    maxLength: '500 Words'
  }],
  description: 'A showreel demonstrating the range, quality and skills of the station and its programming, to be accompanied by a written report, with details of the operation of the station and contributions made which may not necessarily appear on screen.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_JISC,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.TEXT,
    maxLength: 750,
    description: ''
  }, {
    _id: Random.id(),
    type: SupportingEvidenceType.CALL,
    description: 'Skype call between representatives from Jisc and the entering station.'
  }],
  description: 'This category looks for a station worthy of special recognition for outstanding achievement, especially with respect to the station’s commitment to overcoming challenging circumstances and achievement through innovation in the past year.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_BEST_DRAMATIC_PERFORMANCE,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 5 * MINUTE
  }],
  description: 'A showreel demonstrating the on-screen acting skills, styles and techniques of a particular Individual in any form of fictional production. This showreel may be made up of content from multiple productions or episodes.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_BEST_ON_SCREEN_TALENT,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 5 * MINUTE
  }],
  description: 'A showreel demonstrating the on-screen skills, styles and techniques of aparticular individual in any production excluding fictional content. This showreel may be made up of content from multiple productions.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_STATION_MARKETING,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE,
    description: 'A video submission demonstrating the achievements of your station’s marketing recognising how your station recruited members and built audiences across your campus and online, incorporating special events, advertising, social media and on-air branding and idents.'
  }, {
    _id: Random.id(),
    type: SupportingEvidenceType.TEXT,
    maxLength: 500,
    description: 'The submission must be accompanied by a written document detailing marketing strategies, tools, and techniques used by your station.'
  }],
  description: 'Recruiting and retaining members, and building an audience are two of the biggest challenges faced by student TV stations. This award recognises the efforts that stations go to to ensure that they have an active membership and that their content is watched and valued by their university, local and national viewers.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_TECHNICAL_ACHIEVEMENT,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.PDF,
    maxLength: '500 Words'
  }],
  description: 'A report which gives an account of any technical achievement(s) and/or developed to support your station’s output. Entries will demonstrate both the technical challenges faced and overcome, and the benefits this brought to the production(s).',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_FRESHERS_COVERAGE,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }],
  description: 'This category recognises the quality and diversity of a station\'s covering of their campus\' Freshers\' week(s) activities. This category also includes all including all freshers\' themed content.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_ANIMATION,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }],
  description: 'A single animation programme (or a shortened edit from an episode or series), or an original piece of animation of any type, which has been produced by the station. This can include but is not limited to: Cartoons, Computer generated images, Title sequences.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_NEWS_AND_CURRENT_AFFAIRS,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }],
  description: 'A single programme (or a shortened edit from an episode or series) that demonstrates coverage of university, local community, national or international news. It demonstrates an understanding of television journalism and utilises, where appropriate, the skills of video journalism.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_MARS_ELKINS_EL_BROGY,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }],
  description: 'A showreel demonstrating effective, innovative and strong use of multimedia content with an accompanying document.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_WRITING,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 5 * MINUTE,
    description: 'Video entry limit of 5 minutes for reference, demonstrating how the script has been visualized.'
  }, {
    _id: Random.id(),
    type: SupportingEvidenceType.PDF,
    maxLength: '',
    description: 'Written entry limit of 30 pages of text at font size 12. This will be what is judged.'
  }],
  description: 'A script in any genre or format, for any kind of show produced by the station. This can include, but is not limited to, fictional teleplays, factual links and features, documentary scripts, live scripts, news piece, etc. Writing may be from a single programme or shortened from an episode or series.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_LIVE_BROADCAST,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }],
  description: 'A single programme (or a shortened edit from an episode or series) that has been broadcast live or shot as-live by your station. Entries for this category must not have had any audio or video processing applied after transmission. Entries may be edited in post production to produce a showreel e.g. any part of the broadcast edited together to music, but must not have processing to fix technical problems that were present during the broadcast e.g. edit music from a multitrack recording, compressors/gates applied, colour correction, exposure changes, filters.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_CINEMATOGRAPHY,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }],
  description: 'An opportunity for filmmakers to showcase their best work, demonstrating a knowledge of appropriate lighting, camera moves and other associated techniques of the craft, and how well these things are implemented in film or television. This showreel should be made up of content from a single programme (or a shortened edit from an episode or series)',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_LIGHT_ENTERTAINMENT,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }],
  description: 'A single programme (or a shortened edit from an episode or series) intended as light entertainment.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_TITLE_SEQUENCE,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 90 * 1000
  }, {
    _id: Random.id(),
    type: SupportingEvidenceType.TEXT,
    maxLength: 100,
    description: 'Written entry limit of 100 words, not judged but allowed to help judge how well the entry introduces the program. This is supplementary evidence and not judged in itself.'
  }],
  description: 'The introductory sequence to one of your station’s programmes. The very beginning of an exemplar programme may be included. This entry must be a complete video not a cut down video or an edited highlights reel.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_COMEDY,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }],
  description: 'A single programme or series episode that aims to make the viewer laugh, including, but not limited to: Sitcoms, Comedy Dramas, Stand-up, SketchShows.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_DRAMA,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }],
  description: 'A single programme (or a shortened edit from an episode or series) oforiginal scripted dramatic production. Note: Sitcoms or dramatic productions which are primarily comedic should be entered for the Comedy category.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NASTA_AWARDS_DOCUMENTARY_AND_FACTUAL,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }],
  description: 'A single programme (or a shortened edit from an episode or series) featuring factual material, presented in any format.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_SPORT,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }],
  description: 'Coverage of a sporting event or a single programme (or a shortened edit from an episode or series) which features live or recorded sport, and/or comments on sport or sports facilities.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_POST_PRODUCTION_AWARD,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }],
  description: 'A single programme (or a shortened edit from an episode or series) showreel demonstrating excellent post production and editing skills.',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_SUPER_BLOOPER,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }],
  description: 'Just for fun, upload a montage of your bloopers from this year!',
  forAwards: DEFAULT_AWARDS_NAMES.NASTA
}, {
  name: DEFAULT_CATEGORY_NAMES.PCAs_OPEN,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }],
  description: 'Any video content can be entered into this category.',
  forAwards: DEFAULT_AWARDS_NAMES.PEOPLES_CHOICE
}, {
  name: DEFAULT_CATEGORY_NAMES.PCAs_LIVE_BROADCAST,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }],
  description: 'A single programme (or a shortened edit from an episode or series) that has been broadcast live or shot as-live by your station. Entries for this category must not have had any audio or video processing applied after transmission. Entries may be edited in post production to produce a showreel e.g. any part of the broadcast edited together to music, but must not have processing to fix technical problems that were presentduring the broadcast e.g. edit music from a multitrack recording, compressors/gates applied, colour correction, exposure changes, filters.',
  forAwards: DEFAULT_AWARDS_NAMES.PEOPLES_CHOICE
}, {
  name: DEFAULT_CATEGORY_NAMES.PCAs_CONTENT_INNOVATION,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }],
  description: 'A single programme (or a shortened edit from an episode or series) showreel demonstrating innovative content. This can be an innovative show format, innovation in the use of features or segments, or innovative ways of engaging with your audience.',
  forAwards: DEFAULT_AWARDS_NAMES.PEOPLES_CHOICE
}, {
  name: DEFAULT_CATEGORY_NAMES.PCAs_TECHNICAL_INNOVATION,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.PDF,
    maxLength: '500 Words',
    description: 'A report which gives an account of any technical innovation developed to support your station’s output. Entries will demonstrate both the technical challenges faced, the innovative way(s) in which they were overcome, and the benefits this brought to the production(s).'
  }],
  description: 'It is expected that entries for this award demonstrate some technical development by your station, either in software (including online) or hardware, rather than use of existing technical solutions.',
  forAwards: DEFAULT_AWARDS_NAMES.PEOPLES_CHOICE
}, {
  name: DEFAULT_CATEGORY_NAMES.PCAs_VISUAL_CREATIVITY_AND_QUALITY,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }],
  description: 'A single programme (or a shortened edit from an episode or series) showcasing excellence in the following areas: cinematography, editing, animations and visual effects.',
  forAwards: DEFAULT_AWARDS_NAMES.PEOPLES_CHOICE
}, {
  name: DEFAULT_CATEGORY_NAMES.PCAs_BEST_ON_SCREEN_TALENT,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 5 * MINUTE
  }],
  description: 'A showreel demonstrating the on-screen skills, styles and techniques of a particular individual in any production excluding fictional content. This showreel may be made up of content from multiple productions.',
  forAwards: DEFAULT_AWARDS_NAMES.PEOPLES_CHOICE
}, {
  name: DEFAULT_CATEGORY_NAMES.PCAs_UN_SUNG_HERO,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.TEXT,
    maxLength: 500
  }],
  description: 'This award recognises the contribution of an individual to their station and/or the NaSTA community. Entries for this award must nominate a person who is a current member of your student TV station or who was a member within the last twelve months. Entries for this award may include contributions from the nominee’s whole time as a member of your station, not limited to the last twelve months. However it is intended that a major part of the contribution has taken part in the last twelve months.',
  forAwards: DEFAULT_AWARDS_NAMES.PEOPLES_CHOICE
}, {
  name: DEFAULT_CATEGORY_NAMES.PCAs_STATION_OF_THE_YEAR,
  supportingEvidence: [{
    _id: Random.id(),
    type: SupportingEvidenceType.VIDEO,
    maxLength: 10 * MINUTE
  }, {
    _id: Random.id(),
    type: SupportingEvidenceType.TEXT,
    maxLength: 500
  }],
  description: 'A showreel demonstrating the range, quality and skills of the station and its programming, to be accompanied by a written report, with details of the operation of the station and contributions made which may not necessarily appear on screen.',
  forAwards: DEFAULT_AWARDS_NAMES.PEOPLES_CHOICE
}];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"entries.ts":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/entries.ts                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  Entries: () => Entries
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let UserHasRole;
module.link("./accounts", {
  UserHasRole(v) {
    UserHasRole = v;
  }

}, 2);
let Collections, Roles;
module.link("./helpers/enums", {
  Collections(v) {
    Collections = v;
  },

  Roles(v) {
    Roles = v;
  }

}, 3);
const Entries = new Mongo.Collection(Collections.ENTRIES);

if (Meteor.isServer) {
  Meteor.publish(Collections.ENTRIES, function entriesPublictaion() {
    if (Meteor.userId() && UserHasRole([Roles.ADMIN, Roles.HOST, Roles.JUDGE])) {
      return Entries.find();
    } else if (Meteor.userId() && UserHasRole([Roles.STATION])) {
      return Entries.find({
        stationId: Meteor.user().stationId
      });
    }
  });
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"evidence.ts":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/evidence.ts                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  EvidenceCollection: () => EvidenceCollection,
  InsertEvidence: () => InsertEvidence
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let UserHasRole;
module.link("./accounts", {
  UserHasRole(v) {
    UserHasRole = v;
  }

}, 2);
let Collections, Roles;
module.link("./helpers/enums", {
  Collections(v) {
    Collections = v;
  },

  Roles(v) {
    Roles = v;
  }

}, 3);
const EvidenceCollection = new Mongo.Collection(Collections.EVIDENCE);

if (Meteor.isServer) {
  Meteor.publish(Collections.EVIDENCE, () => {
    if (Meteor.userId() && UserHasRole([Roles.ADMIN, Roles.HOST, Roles.JUDGE])) {
      return EvidenceCollection.find({});
    }
  });
}

function InsertEvidence(evidence) {
  return Promise.asyncApply(() => {
    return new Promise((resolve, reject) => {
      EvidenceCollection.insert(evidence, (error, id) => {
        if (error) reject(error); // TODO: Multiple entries
        // TODO: Entry IDs are null

        resolve(id);
      });
    });
  });
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"judgeToCategory.ts":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/judgeToCategory.ts                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  JudgeToCategory: () => JudgeToCategory
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let UserHasRole;
module.link("./accounts", {
  UserHasRole(v) {
    UserHasRole = v;
  }

}, 2);
let Collections, Roles;
module.link("./helpers/enums", {
  Collections(v) {
    Collections = v;
  },

  Roles(v) {
    Roles = v;
  }

}, 3);
const JudgeToCategory = new Mongo.Collection(Collections.JudgeToCategory);

if (Meteor.isServer) {
  Meteor.publish(Collections.JudgeToCategory, () => {
    if (Meteor.userId() && UserHasRole([Roles.JUDGE, Roles.ADMIN, Roles.HOST])) {
      return JudgeToCategory.find({});
    }
  });
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"results.ts":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/results.ts                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  Results: () => Results
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let UserHasRole;
module.link("./accounts", {
  UserHasRole(v) {
    UserHasRole = v;
  }

}, 2);
let Collections, Roles;
module.link("./helpers/enums", {
  Collections(v) {
    Collections = v;
  },

  Roles(v) {
    Roles = v;
  }

}, 3);
const Results = new Mongo.Collection(Collections.RESULTS);

if (Meteor.isServer) {
  Meteor.publish(Collections.RESULTS, () => {
    if (Meteor.userId()) {
      if (UserHasRole([Roles.ADMIN, Roles.HOST, Roles.JUDGE])) {
        return Results.find({});
      } else if (UserHasRole([Roles.JUDGE])) {
        return []; // TODO
      } else {
        return [];
      }
    }
  });
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"scores.ts":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/scores.ts                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  Scores: () => Scores
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let UserHasRole;
module.link("./accounts", {
  UserHasRole(v) {
    UserHasRole = v;
  }

}, 2);
let Collections, Roles;
module.link("./helpers/enums", {
  Collections(v) {
    Collections = v;
  },

  Roles(v) {
    Roles = v;
  }

}, 3);
const Scores = new Mongo.Collection(Collections.SCORES);

if (Meteor.isServer) {
  Meteor.publish(Collections.SCORES, () => {
    if (Meteor.userId() && UserHasRole([Roles.ADMIN, Roles.HOST, Roles.JUDGE])) {
      return Scores.find({});
    }
  });
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"stations.ts":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/stations.ts                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  Stations: () => Stations,
  GetStationForUser: () => GetStationForUser,
  DEFAULT_STATIONS: () => DEFAULT_STATIONS
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let GetUserFromId, UserHasRole;
module.link("./accounts", {
  GetUserFromId(v) {
    GetUserFromId = v;
  },

  UserHasRole(v) {
    UserHasRole = v;
  }

}, 2);
let Collections, Roles;
module.link("./helpers/enums", {
  Collections(v) {
    Collections = v;
  },

  Roles(v) {
    Roles = v;
  }

}, 3);
const Stations = new Mongo.Collection(Collections.STATIONS);

if (Meteor.isServer) {
  Meteor.publish(Collections.STATIONS, () => {
    const id = Meteor.userId();

    if (id) {
      const user = GetUserFromId();

      if (user) {
        if (UserHasRole([Roles.ADMIN, Roles.HOST])) {
          return Stations.find({});
        } else if (UserHasRole([Roles.JUDGE])) {
          return Stations.find({
            name: {
              $ne: 'NaSTA'
            }
          });
        } else {
          return Stations.find({
            _id: user.stationId,
            authorizedUsers: id
          });
        }
      }
    }
  });
}

function GetStationForUser() {
  const id = Meteor.userId();

  if (id) {
    const user = GetUserFromId();

    if (user && user.stationId) {
      return Stations.findOne({
        _id: user.stationId,
        authorizedUsers: id
      });
    }
  }
}

const DEFAULT_STATIONS = [{
  name: 'NaSTA',
  eligibleForEntry: true,
  authorizedUsers: []
}];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"system.ts":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/system.ts                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  System: () => System
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Collections;
module.link("./helpers/enums", {
  Collections(v) {
    Collections = v;
  }

}, 1);
const System = new Mongo.Collection(Collections.SYSTEM);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.ts":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.ts                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
module.link("../imports/api/accounts");
module.link("../imports/api/accounts");
module.link("../imports/api/entries");
module.link("../imports/api/evidence");
module.link("../imports/api/helpers/methods");
module.link("../imports/api/judgeToCategory");
let JudgeToCategory;
module.link("../imports/api/judgeToCategory", {
  JudgeToCategory(v) {
    JudgeToCategory = v;
  }

}, 2);
module.link("../imports/api/results");
module.link("../imports/api/scores");
module.link("../imports/api/stations");
module.link("../imports/api/system");
let System;
module.link("../imports/api/system", {
  System(v) {
    System = v;
  }

}, 3);
let Awards, DEFAULT_AWARDS, DEFAULT_CATEGORIES_FOR_AWARDS;
module.link("/imports/api/awards", {
  Awards(v) {
    Awards = v;
  },

  DEFAULT_AWARDS(v) {
    DEFAULT_AWARDS = v;
  },

  DEFAULT_CATEGORIES_FOR_AWARDS(v) {
    DEFAULT_CATEGORIES_FOR_AWARDS = v;
  }

}, 4);
let Categories, DEFAULT_CATEGORIES;
module.link("/imports/api/categories", {
  Categories(v) {
    Categories = v;
  },

  DEFAULT_CATEGORIES(v) {
    DEFAULT_CATEGORIES = v;
  }

}, 5);
let DEFAULT_AWARDS_NAMES, DEFAULT_CATEGORY_NAMES, Roles;
module.link("/imports/api/helpers/enums", {
  DEFAULT_AWARDS_NAMES(v) {
    DEFAULT_AWARDS_NAMES = v;
  },

  DEFAULT_CATEGORY_NAMES(v) {
    DEFAULT_CATEGORY_NAMES = v;
  },

  Roles(v) {
    Roles = v;
  }

}, 6);
let DEFAULT_STATIONS, Stations;
module.link("/imports/api/stations", {
  DEFAULT_STATIONS(v) {
    DEFAULT_STATIONS = v;
  },

  Stations(v) {
    Stations = v;
  }

}, 7);

function insertCategory(category) {
  Categories.insert(category);
}

Meteor.startup(() => {
  if (Categories.find().count() === 0) {
    DEFAULT_CATEGORIES.forEach(category => {
      insertCategory(category);
    });
  }

  if (Awards.find().count() === 0) {
    DEFAULT_AWARDS.forEach(award => {
      if (award.name in DEFAULT_CATEGORIES_FOR_AWARDS) {
        DEFAULT_CATEGORIES_FOR_AWARDS[award.name].forEach(category => {
          const cat = Categories.findOne({
            name: category,
            forAwards: award.name
          });

          if (cat && cat._id) {
            award.categories.push(cat._id);
          }
        });
      }

      Awards.insert(award);
    });
  }

  if (Meteor.users.find({}).fetch().length === 0) {
    Accounts.createUser({
      email: 'tech@nasta.tv',
      password: 'password'
    });
  }

  if (Stations.find().count() === 0) {
    const user = Meteor.users.findOne({
      emails: {
        address: 'tech@nasta.tv',
        verified: false
      }
    });

    if (user) {
      DEFAULT_STATIONS.forEach(station => {
        Stations.insert(_objectSpread({}, station, {}, {
          authorizedUsers: [user._id]
        }));
      });
      const nasta = Stations.findOne({
        name: 'NaSTA'
      });

      if (nasta) {
        Meteor.users.update(user._id, _objectSpread({}, user, {
          stationId: nasta._id,
          roles: [Roles.ADMIN, Roles.JUDGE, Roles.HOST, Roles.STATION]
        }));
        const bestBroadcaster = Categories.findOne({
          name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_BEST_BROADCASTER
        });

        if (bestBroadcaster && nasta._id && bestBroadcaster._id) {
          JudgeToCategory.insert({
            judgeId: user._id,
            categoryId: bestBroadcaster._id
          });
        }
      }
    }
  }

  if (JudgeToCategory.find().count() === 1) {
    // TODO: Remove, temporary during testing
    const user = Meteor.users.findOne({
      emails: {
        address: 'tech@nasta.tv',
        verified: false
      }
    });

    if (user) {
      const categories = Categories.find({}).fetch();
      categories.forEach(category => {
        if (category.name === DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_BEST_BROADCASTER) return;
        JudgeToCategory.insert({
          judgeId: user._id,
          categoryId: category._id || ''
        });
      });
    }
  } // Clear auth tokens after deploying new version


  if (Meteor.isProduction) {
    Meteor.users.update({}, {
      $set: {
        'services.resume.loginTokens': []
      }
    }, {
      multi: true
    });
  }

  if (System.find().fetch().length === 0) {
    System.insert({
      version: 'v1.0'
    });
    const blooperCategory = Categories.findOne({
      name: DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_SUPER_BLOOPER
    });

    if (!blooperCategory) {
      const toInsert = DEFAULT_CATEGORIES.find(category => category.name === DEFAULT_CATEGORY_NAMES.NaSTA_AWARDS_SUPER_BLOOPER);

      if (toInsert) {
        const id = Categories.insert(toInsert);
        const nasta = Awards.findOne({
          name: DEFAULT_AWARDS_NAMES.NASTA
        });

        if (nasta) {
          Awards.update({
            _id: nasta._id
          }, {
            $push: {
              categories: id
            }
          });
        }
      }
    }
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".mjs",
    ".tsx"
  ]
});

var exports = require("/server/main.ts");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvaGVscGVycy9jb25zdGFudHMudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2hlbHBlcnMvZW51bXMudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2hlbHBlcnMvbWV0aG9kcy50cyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYWNjb3VudHMudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2F3YXJkcy50cyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY2F0ZWdvcmllcy50cyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZW50cmllcy50cyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZXZpZGVuY2UudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2p1ZGdlVG9DYXRlZ29yeS50cyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcmVzdWx0cy50cyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc2NvcmVzLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zdGF0aW9ucy50cyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc3lzdGVtLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLE1BQU0sQ0FBQyxNQUFQLENBQWE7QUFBQSxRQUFNLEVBQUcsTUFBRTtBQUFYLENBQWI7QUFBTyxNQUFNLE1BQU0sR0FBRyxLQUFLLElBQXBCLEM7Ozs7Ozs7Ozs7O0FDQVA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBS0EsSUFBa0IsV0FBbEI7O0FBQUEsV0FBa0IsV0FBbEIsRUFBNkI7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVhELEVBQWtCLFdBQVcsc0JBQVgsV0FBVyxNQUE3Qjs7QUFhQSxJQUFrQixLQUFsQjs7QUFBQSxXQUFrQixLQUFsQixFQUF1QjtBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FORCxFQUFrQixLQUFLLHNCQUFMLEtBQUssTUFBdkI7O0FBUUEsSUFBa0Isb0JBQWxCOztBQUFBLFdBQWtCLG9CQUFsQixFQUFzQztBQUNyQztBQUNBO0FBQ0EsQ0FIRCxFQUFrQixvQkFBb0Isc0JBQXBCLG9CQUFvQixNQUF0Qzs7QUFLQSxJQUFrQixzQkFBbEI7O0FBQUEsV0FBa0Isc0JBQWxCLEVBQXdDO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FMRCxFQUFrQixzQkFBc0Isc0JBQXRCLHNCQUFzQixNQUF4Qzs7QUFPQSxJQUFrQixTQUFsQjs7QUFBQSxXQUFrQixTQUFsQixFQUEyQjtBQUMxQjtBQUNBO0FBQ0EsQ0FIRCxFQUFrQixTQUFTLHNCQUFULFNBQVMsTUFBM0I7O0FBS0EsSUFBa0Isa0JBQWxCOztBQUFBLFdBQWtCLGtCQUFsQixFQUFvQztBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBLENBTEQsRUFBa0Isa0JBQWtCLHNCQUFsQixrQkFBa0IsTUFBcEM7O0FBT0EsSUFBa0Isc0JBQWxCOztBQUFBLFdBQWtCLHNCQUFsQixFQUF3QztBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0E5QkQsRUFBa0Isc0JBQXNCLHNCQUF0QixzQkFBc0IsTUFBeEMsRTs7Ozs7Ozs7Ozs7QUNsREEsT0FBTyxNQUFQLENBQVM7QUFBQSxlQUFlLFFBQVM7QUFBeEIsQ0FBVDtBQUFpQztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQWUxQixNQUFNLGFBQWEsR0FBRyxNQUFNLENBQUMsUUFBUCxDQUFnQixPQUFoQixDQUF3QixXQUE5QztBQUVQLE1BQU0sR0FBRyxHQUFHLElBQUksT0FBSixDQUFZO0FBQUUsYUFBVyxFQUFFLGFBQWY7QUFBOEI7QUFBOUIsQ0FBWixDQUFaOztBQUVBLFNBQVMsV0FBVCxDQUFzQixXQUF0QixFQUF5QztBQUN4QyxRQUFNLEtBQUssR0FBRyxXQUFXLENBQUMsT0FBWixDQUFvQixVQUFwQixDQUFkO0FBRUEsU0FBTyxJQUFJLE1BQUosQ0FBVyxXQUFXLENBQUMsS0FBWixDQUFrQixLQUFLLEdBQUcsV0FBVyxNQUFyQyxDQUFYLEVBQXlELFFBQXpELENBQVA7QUFDQTs7QUFFRCxTQUFTLGNBQVQsQ0FBeUIsYUFBekIsRUFBOEM7QUFDN0MsU0FBTyxJQUFJLE9BQUosQ0FBWSxDQUFDLE9BQUQsRUFBVSxNQUFWLEtBQW9CO0FBQ3RDLE9BQUcsQ0FBQyxtQ0FBSixDQUF3QztBQUN2QyxVQUFJLEVBQUUsYUFEaUM7QUFFdkMsY0FBUSxFQUFFO0FBQ1QsNEJBQW9CLEVBQUU7QUFDckIsa0JBQVE7QUFEYSxTQURiO0FBSVQsZ0JBQVEsRUFBRTtBQUNULGtCQUFRO0FBREM7QUFKRDtBQUY2QixLQUF4QyxFQVVHLElBVkgsQ0FVUyxNQUFELElBQVc7QUFDbEIsYUFBTyxDQUFDLE1BQU0sQ0FBQyxHQUFSLENBQVA7QUFDQSxLQVpELEVBWUcsS0FaSCxDQVlVLEdBQUQsSUFBUTtBQUNoQixZQUFNLENBQUMsR0FBRCxDQUFOO0FBQ0EsS0FkRDtBQWVBLEdBaEJNLENBQVA7QUFpQkE7O0FBRUQsTUFBTSxDQUFDLE9BQVAsQ0FBZTtBQUNSLDJCQUFOLENBQWlDLEtBQWpDO0FBQUEsb0NBQThDO0FBQzdDLFdBQUssQ0FBQyxLQUFELEVBQVEsTUFBUixDQUFMO0FBQ0EsYUFBTyxDQUFDLEdBQVIsQ0FBWSw2QkFBWjtBQUNBLGFBQU8sR0FBRyxDQUFDLHVCQUFKLENBQTRCO0FBQ2xDLGdCQUFRLEVBQUUsV0FBVyxDQUFDLEtBQUQsQ0FEYTtBQUVsQyxhQUFLLEVBQUU7QUFGMkIsT0FBNUIsRUFHSixLQUhJLENBR0csR0FBRCxJQUFRO0FBQ2hCLGVBQU8sT0FBTyxDQUFDLE1BQVIsQ0FBZSxHQUFmLENBQVA7QUFDQSxPQUxNLEVBS0osSUFMSSxDQUtFLE1BQUQsSUFBVztBQUNsQixlQUFPLE9BQU8sQ0FBQyxPQUFSLENBQWdCLE1BQU0sQ0FBQyxVQUF2QixDQUFQO0FBQ0EsT0FQTSxDQUFQO0FBUUEsS0FYRDtBQUFBLEdBRGM7O0FBYVIsMEJBQU4sQ0FDQyxLQURELEVBQ2dCLFNBRGhCLEVBQ21DLFNBRG5DLEVBQ3NELFdBRHRELEVBQzJFLE1BRDNFLEVBQzRGLElBRDVGO0FBQUEsb0NBQ3dHO0FBRXZHLFdBQUssQ0FBQyxLQUFELEVBQVEsTUFBUixDQUFMO0FBQ0EsV0FBSyxDQUFDLFNBQUQsRUFBWSxNQUFaLENBQUw7QUFDQSxXQUFLLENBQUMsU0FBRCxFQUFZLE1BQVosQ0FBTDtBQUNBLFdBQUssQ0FBQyxXQUFELEVBQWMsTUFBZCxDQUFMO0FBQ0EsV0FBSyxDQUFDLE1BQUQsRUFBUyxPQUFULENBQUw7QUFDQSxXQUFLLENBQUMsSUFBRCxFQUFPLE1BQVAsQ0FBTDtBQUVBLGFBQU8sQ0FBQyxHQUFSLDRCQUFnQyxXQUFXLEdBQUMsU0FBNUM7O0FBRUEsVUFBSSxNQUFKLEVBQVk7QUFDWCxlQUFPLEdBQUcsQ0FBQyx3QkFBSixDQUE2QjtBQUNuQyxrQkFBUSxFQUFFLFdBQVcsQ0FBQyxLQUFELENBRGM7QUFFbkMsZ0JBQU0sRUFBRTtBQUNQLHNCQUFVLEVBQUUsU0FETDtBQUVQLGtCQUFNLEVBQUUsU0FBUyxHQUFHO0FBRmIsV0FGMkI7QUFNbkMsZ0JBQU0sRUFBRTtBQUNQLGdCQURPO0FBRVAsZ0JBQUksRUFBRTtBQUNMLHNCQUFRO0FBREg7QUFGQztBQU4yQixTQUE3QixFQVlHLEtBWkgsQ0FZVSxHQUFELElBQVE7QUFDdkIsaUJBQU8sT0FBTyxDQUFDLE1BQVIsQ0FBZSxHQUFmLENBQVA7QUFDQSxTQWRNLEVBY0osSUFkSSxDQWNFLE1BQUQsSUFBVztBQUNsQixpQkFBTyxPQUFPLENBQUMsT0FBUixDQUFnQixNQUFNLENBQUMsVUFBdkIsQ0FBUDtBQUNBLFNBaEJNLENBQVA7QUFpQkEsT0FsQkQsTUFrQk87QUFDTixlQUFPLEdBQUcsQ0FBQyx3QkFBSixDQUE2QjtBQUNuQyxrQkFBUSxFQUFFLFdBQVcsQ0FBQyxLQUFELENBRGM7QUFFbkMsb0JBQVUsRUFBRSxTQUZ1QjtBQUduQyxnQkFBTSxFQUFFLFdBQVcsR0FBQztBQUhlLFNBQTdCLEVBSUosS0FKSSxDQUlHLEdBQUQsSUFBUTtBQUNoQixpQkFBTyxPQUFPLENBQUMsTUFBUixDQUFlLEdBQWYsQ0FBUDtBQUNBLFNBTk0sRUFNSixJQU5JLENBTUUsTUFBRCxJQUFXO0FBQ2xCLGlCQUFPLE9BQU8sQ0FBQyxPQUFSLENBQWdCLE1BQWhCLENBQVA7QUFDQSxTQVJNLENBQVA7QUFTQTtBQUNELEtBekNEO0FBQUEsR0FiYzs7QUF1RFIseUJBQU4sQ0FBK0IsV0FBL0IsRUFBb0QsSUFBcEQ7QUFBQSxvQ0FBZ0U7QUFDL0QsV0FBSyxDQUFDLFdBQUQsRUFBYyxNQUFkLENBQUw7QUFDQSxXQUFLLENBQUMsSUFBRCxFQUFPLE1BQVAsQ0FBTDtBQUVBLFlBQU0sSUFBSSxHQUFHLFdBQVcsQ0FBQyxXQUFELENBQXhCOztBQUVBLFVBQUksSUFBSSxDQUFDLE1BQUwsR0FBYyxNQUFNLElBQU4sR0FBYSxJQUEvQixFQUFxQztBQUNwQyxlQUFPLENBQUMsR0FBUixDQUFZLFdBQVo7QUFDQSxlQUZvQyxDQUU3QjtBQUNQOztBQUVELGFBQU8sR0FBRyxDQUFDLFdBQUosQ0FBZ0I7QUFDdEIsZ0JBQVEsRUFBRSxJQURZO0FBRXRCO0FBRnNCLE9BQWhCLEVBR0osS0FISSxDQUdHLEtBQUQsSUFBVTtBQUNsQixlQUFPLENBQUMsR0FBUixDQUFZLEtBQVo7QUFDQSxPQUxNLEVBS0osSUFMSSxDQUtFLE1BQUQsSUFBVztBQUNsQixZQUFJLE1BQUosRUFBWTtBQUNYLGlCQUFPLE9BQU8sQ0FBQyxPQUFSLENBQWdCLE1BQU0sQ0FBQyxVQUF2QixDQUFQO0FBQ0E7O0FBQ0QsZUFBTyxDQUFDLEdBQVIsQ0FBWSx1QkFBWjtBQUNBLE9BVk0sQ0FBUDtBQVdBLEtBdEJEO0FBQUEsR0F2RGM7O0FBOEVSLHFCQUFOLENBQTJCLE1BQTNCLEVBQThELFVBQTlEO0FBQUEsb0NBQWdGO0FBQy9FLGFBQU8sQ0FBQyxHQUFSLENBQVksSUFBSSxDQUFDLFNBQUwsQ0FBZSxNQUFmLENBQVo7QUFDQSxXQUFLLENBQUMsVUFBRCxFQUFhLE1BQWIsQ0FBTDs7QUFFQSxVQUFJLE1BQU0sQ0FBQyxNQUFQLEVBQUosRUFBcUI7QUFDcEIsY0FBTSxPQUFPLEdBQUcsaUJBQWlCLEVBQWpDOztBQUVBLFlBQUksQ0FBQyxPQUFMLEVBQWM7QUFDYixpQkFBTyxJQUFJLE1BQU0sQ0FBQyxLQUFYLENBQWlCLDBDQUFqQixDQUFQO0FBQ0E7O0FBRUQsWUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFiLEVBQWtCO0FBQ2pCLGlCQUFPLElBQUksTUFBTSxDQUFDLEtBQVgsQ0FBaUIsMENBQWpCLENBQVA7QUFDQTs7QUFFRCxjQUFNLFFBQVEsR0FBRyxVQUFVLENBQUMsT0FBWCxDQUFtQjtBQUFFLGFBQUcsRUFBRTtBQUFQLFNBQW5CLENBQWpCOztBQUVBLFlBQUksQ0FBQyxRQUFMLEVBQWU7QUFDZCxpQkFBTyxJQUFJLE1BQU0sQ0FBQyxLQUFYLENBQWlCLG9CQUFqQixDQUFQO0FBQ0E7O0FBRUQsWUFBSSxVQUFVLEdBQUcsSUFBakI7QUFDQSxnQkFBUSxDQUFDLGtCQUFULENBQTRCLE9BQTVCLENBQXFDLEVBQUQsSUFBTztBQUMxQyxjQUFJLENBQUMsTUFBTSxDQUFDLElBQVAsQ0FBWSxNQUFaLEVBQW9CLFFBQXBCLENBQTZCLEVBQUUsQ0FBQyxHQUFoQyxDQUFELElBQXlDLEVBQUUsQ0FBQyxJQUFILEtBQVksc0JBQXNCLENBQUMsSUFBaEYsRUFBc0Y7QUFDckYsc0JBQVUsR0FBRyxLQUFiO0FBQ0E7QUFDRCxTQUpEOztBQU1BLFlBQUksQ0FBQyxVQUFMLEVBQWlCO0FBQ2hCLGlCQUFPLElBQUksTUFBTSxDQUFDLEtBQVgsQ0FBaUIsaUVBQWpCLENBQVA7QUFDQTs7QUFFRCxjQUFNLFFBQVEsR0FBYSxFQUEzQixDQTVCb0IsQ0E4QnBCOztBQUNBLGFBQUssTUFBTSxPQUFYLElBQXNCLFFBQVEsQ0FBQyxrQkFBL0IsRUFBbUQ7QUFDbEQsY0FBSSxDQUFDLE9BQU8sQ0FBQyxHQUFiLEVBQWtCO0FBQ2pCO0FBQ0E7O0FBRUQsY0FBSSxFQUFFLEdBQUcsRUFBVDs7QUFDQSxjQUFJLE9BQU8sQ0FBQyxJQUFSLEtBQWlCLHNCQUFzQixDQUFDLElBQTVDLEVBQWtEO0FBQ2pELGNBQUUsaUJBQVMsY0FBYyxDQUFDO0FBQ3pCLGtCQUFJLEVBQUUsc0JBQXNCLENBQUMsSUFESjtBQUV6QixxQkFBTyxFQUFFLGVBRmdCO0FBR3pCLHNCQUFRLEVBQUUsS0FIZTtBQUl6QixrQ0FBb0IsRUFBRSxPQUFPLENBQUMsR0FKTDtBQUt6QixxQkFBTyxFQUFFLFVBTGdCO0FBTXpCLHVCQUFTLEVBQUUsT0FBTyxDQUFDO0FBTk0sYUFBRCxDQUF2QixDQUFGO0FBUUEsV0FURCxNQVNPO0FBQ04sZ0JBQUksT0FBTyxDQUFDLElBQVIsS0FBaUIsc0JBQXNCLENBQUMsS0FBeEMsSUFBaUQsT0FBTyxDQUFDLElBQVIsS0FBaUIsc0JBQXNCLENBQUMsR0FBN0YsRUFBa0c7QUFFakcsa0JBQUksV0FBVyxHQUFHLEVBQWxCO0FBQ0Esa0JBQUksb0JBQW9CLEdBQUcsRUFBM0I7O0FBRUEsa0JBQUk7QUFDSCwyQkFBVyxpQkFBUyxjQUFjLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFULENBQVAsQ0FBdkIsQ0FBWDtBQUNBLGVBRkQsQ0FFRSxPQUFPLEtBQVAsRUFBYztBQUNmLG9CQUFJLEtBQUssQ0FBQyxLQUFOLENBQVksS0FBWixDQUFrQixNQUFsQixNQUE4Qiw0QkFBbEMsRUFBZ0U7QUFDL0Qsd0JBQU0sSUFBSSxHQUFHLGtCQUFrQixDQUFDLE9BQW5CLENBQTJCO0FBQ3ZDLDZCQUFTLEVBQUUsT0FBTyxDQUFDLEdBRG9CO0FBRXZDLDJCQUFPLEVBQUUsVUFGOEI7QUFHdkMsd0NBQW9CLEVBQUUsT0FBTyxDQUFDO0FBSFMsbUJBQTNCLENBQWI7O0FBTUEsc0JBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxXQUFMLENBQWlCLE1BQTdCLEVBQXFDO0FBQ3BDLCtCQUFXLEdBQUcsSUFBSSxDQUFDLFdBQW5CO0FBQ0EsbUJBRkQsTUFFTztBQUNOLDBCQUFNLElBQUksS0FBSixDQUFVLHdDQUFWLENBQU47QUFDQTtBQUNEO0FBQ0Q7O0FBRUQsa0JBQUksTUFBTSxXQUFJLE9BQU8sQ0FBQyxHQUFaLFdBQVYsRUFBbUM7QUFDbEMsb0JBQUk7QUFDSCxzQ0FBb0IsaUJBQVMsY0FBYyxDQUFDLE1BQU0sV0FBSSxPQUFPLENBQUMsR0FBWixXQUFQLENBQXZCLENBQXBCO0FBQ0EsaUJBRkQsQ0FFRSxPQUFPLEtBQVAsRUFBYztBQUNmLHNCQUFJLEtBQUssQ0FBQyxLQUFOLENBQVksS0FBWixDQUFrQixNQUFsQixNQUE4Qiw0QkFBbEMsRUFBZ0U7QUFDL0QsMEJBQU0sSUFBSSxHQUFHLGtCQUFrQixDQUFDLE9BQW5CLENBQTJCO0FBQ3ZDLCtCQUFTLEVBQUUsT0FBTyxDQUFDLEdBRG9CO0FBRXZDLDZCQUFPLEVBQUUsVUFGOEI7QUFHdkMsMENBQW9CLEVBQUUsT0FBTyxDQUFDO0FBSFMscUJBQTNCLENBQWI7O0FBTUEsd0JBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxvQkFBTCxDQUEwQixNQUF0QyxFQUE4QztBQUM3QywwQ0FBb0IsR0FBRyxJQUFJLENBQUMsb0JBQTVCO0FBQ0EscUJBRkQsTUFFTztBQUNOLDRCQUFNLElBQUksS0FBSixDQUFVLHdDQUFWLENBQU47QUFDQTtBQUNEO0FBQ0Q7QUFDRDs7QUFFRCxnQkFBRSxpQkFBUyxjQUFjLENBQUM7QUFDekIsb0JBQUksRUFBRSxPQUFPLENBQUMsSUFEVztBQUV6Qix1QkFBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBVCxDQUZVO0FBR3pCLHdCQUFRLEVBQUUsS0FIZTtBQUl6QixvQ0FBb0IsRUFBRSxPQUFPLENBQUMsR0FKTDtBQUt6Qix1QkFBTyxFQUFFLFVBTGdCO0FBTXpCLHlCQUFTLEVBQUUsT0FBTyxDQUFDLEdBTk07QUFPekIsMkJBUHlCO0FBUXpCO0FBUnlCLGVBQUQsQ0FBdkIsQ0FBRjtBQVVBLGFBckRELE1BcURPO0FBQ04sZ0JBQUUsaUJBQVMsY0FBYyxDQUFDO0FBQ3pCLG9CQUFJLEVBQUUsT0FBTyxDQUFDLElBRFc7QUFFekIsdUJBQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQVQsQ0FGVTtBQUd6Qix3QkFBUSxFQUFFLE9BQU8sQ0FBQyxJQUFSLEtBQWlCLHNCQUFzQixDQUFDLElBSHpCO0FBSXpCLG9DQUFvQixFQUFFLE9BQU8sQ0FBQyxHQUpMO0FBS3pCLHVCQUFPLEVBQUUsVUFMZ0I7QUFNekIseUJBQVMsRUFBRSxPQUFPLENBQUM7QUFOTSxlQUFELENBQXZCLENBQUY7QUFRQTtBQUNEOztBQUVELGtCQUFRLENBQUMsSUFBVCxDQUFjLEVBQWQ7QUFDQTs7QUFFRCxlQUFPLENBQUMsTUFBUixDQUFlO0FBQ2QsbUJBQVMsRUFBRSxPQUFPLENBQUMsR0FETDtBQUVkLG9CQUZjO0FBR2QsY0FBSSxFQUFFLElBQUksQ0FBQyxHQUFMLEVBSFE7QUFJZCxxQkFBVyxFQUFFLFFBSkM7QUFLZCxvQkFBVSxFQUFFLE1BQU0sQ0FBQyxLQUxMO0FBTWQsa0JBQVEsRUFBRSxrQkFBa0IsQ0FBQztBQU5mLFNBQWYsRUFPSSxLQUFELElBQWtCO0FBQ3BCLGNBQUksS0FBSixFQUFXLE9BQU8sSUFBSSxNQUFNLENBQUMsS0FBWCxDQUFpQixLQUFqQixDQUFQO0FBQ1gsaUJBQU8sT0FBTyxDQUFDLE9BQVIsRUFBUDtBQUNBLFNBVkQ7QUFXQSxPQTlIRCxNQThITztBQUNOLGVBQU8sSUFBSSxNQUFNLENBQUMsS0FBWCxDQUFpQix1QkFBakIsQ0FBUDtBQUNBO0FBQ0QsS0FySUQ7QUFBQSxHQTlFYzs7QUFvTmQsYUFBWSxJQUFaLEVBQXlCLE1BQXpCLEVBQXVDO0FBQ3RDLFNBQUssQ0FBQyxNQUFELEVBQVMsTUFBVCxDQUFMO0FBRUEsUUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFQLEVBQUQsSUFBb0IsQ0FBQyxXQUFXLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBUCxDQUFELENBQXBDLEVBQXFEO0FBRXJELFVBQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxLQUFQLENBQWEsT0FBYixDQUFxQjtBQUFFLFNBQUcsRUFBRTtBQUFQLEtBQXJCLENBQWI7QUFFQSxRQUFJLENBQUMsSUFBTCxFQUFXO0FBRVgsUUFBSSxJQUFJLENBQUMsS0FBTCxDQUFXLFFBQVgsQ0FBb0IsSUFBcEIsQ0FBSixFQUErQjtBQUUvQixVQUFNLENBQUMsS0FBUCxDQUFhLE1BQWIsQ0FBb0IsTUFBcEIsRUFBNEI7QUFDM0IsVUFBSSxFQUFFO0FBQ0wsYUFBSyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBVCxFQUFnQixJQUFoQjtBQURGO0FBRHFCLEtBQTVCO0FBS0EsR0FwT2E7O0FBcU9kLGdCQUFlLElBQWYsRUFBNEIsTUFBNUIsRUFBMEM7QUFDekMsU0FBSyxDQUFDLE1BQUQsRUFBUyxNQUFULENBQUw7QUFFQSxRQUFJLENBQUMsTUFBTSxDQUFDLE1BQVAsRUFBRCxJQUFvQixDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFQLENBQUQsQ0FBcEMsRUFBcUQ7QUFFckQsVUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLEtBQVAsQ0FBYSxPQUFiLENBQXFCO0FBQUUsU0FBRyxFQUFFO0FBQVAsS0FBckIsQ0FBYjtBQUVBLFFBQUksQ0FBQyxJQUFMLEVBQVc7O0FBRVgsUUFBSSxJQUFJLENBQUMsS0FBTCxDQUFXLFFBQVgsQ0FBb0IsSUFBcEIsQ0FBSixFQUErQjtBQUM5QixZQUFNLENBQUMsS0FBUCxDQUFhLE1BQWIsQ0FBb0IsTUFBcEIsRUFBNEI7QUFDM0IsWUFBSSxFQUFFO0FBQ0wsZUFBSyxFQUFFLElBQUksQ0FBQyxLQUFMLENBQVcsTUFBWCxDQUFtQixDQUFELElBQU8sQ0FBQyxLQUFLLElBQS9CO0FBREY7QUFEcUIsT0FBNUI7QUFLQTtBQUNELEdBclBhOztBQXNQZCxnQkFBZSxJQUFmLEVBQTJCO0FBQzFCLFNBQUssQ0FBQyxJQUFELEVBQU8sTUFBUCxDQUFMO0FBRUEsUUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFQLEVBQUQsSUFBb0IsQ0FBQyxXQUFXLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBUCxDQUFELENBQXBDLEVBQXFEO0FBRXJELFVBQU0sTUFBTSxHQUFHLFFBQVEsQ0FBQyxJQUFULENBQWM7QUFBRTtBQUFGLEtBQWQsRUFBd0IsS0FBeEIsRUFBZjtBQUVBLFFBQUksTUFBTSxDQUFDLE1BQVgsRUFBbUI7QUFFbkIsWUFBUSxDQUFDLE1BQVQsQ0FBZ0I7QUFDZixVQURlO0FBRWYsc0JBQWdCLEVBQUUsSUFGSDtBQUdmLHFCQUFlLEVBQUU7QUFIRixLQUFoQjtBQUtBLEdBcFFhOztBQXFRZCxtQkFBa0IsRUFBbEIsRUFBNEI7QUFDM0IsU0FBSyxDQUFFLEVBQUYsRUFBTSxNQUFOLENBQUw7QUFFQSxRQUFJLENBQUMsTUFBTSxDQUFDLE1BQVAsRUFBRCxJQUFvQixDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFQLENBQUQsQ0FBcEMsRUFBcUQ7QUFFckQsVUFBTSxNQUFNLEdBQUcsUUFBUSxDQUFDLElBQVQsQ0FBYztBQUFFLFNBQUcsRUFBRTtBQUFQLEtBQWQsRUFBMkIsS0FBM0IsRUFBZjtBQUVBLFFBQUksQ0FBQyxNQUFNLENBQUMsTUFBWixFQUFvQjtBQUVwQixZQUFRLENBQUMsTUFBVCxDQUFnQjtBQUFFLFNBQUcsRUFBRTtBQUFQLEtBQWhCO0FBRUEsVUFBTSxDQUFDLEtBQVAsQ0FBYSxJQUFiLENBQWtCO0FBQUUsZUFBUyxFQUFFO0FBQWIsS0FBbEIsRUFBcUMsS0FBckMsR0FBNkMsT0FBN0MsQ0FBc0QsSUFBRCxJQUFTO0FBQzdELFlBQU0sQ0FBQyxLQUFQLENBQWEsTUFBYixDQUFvQjtBQUFFLFdBQUcsRUFBRSxJQUFJLENBQUM7QUFBWixPQUFwQjtBQUNBLEtBRkQ7QUFHQSxHQW5SYTs7QUFvUlIsZ0JBQU4sQ0FBc0IsU0FBdEIsRUFBeUMsVUFBekMsRUFBNkQsUUFBN0QsRUFBK0UsUUFBL0U7QUFBQSxvQ0FBK0Y7QUFDOUYsV0FBSyxDQUFFLFNBQUYsRUFBYSxNQUFiLENBQUw7QUFDQSxXQUFLLENBQUMsVUFBRCxFQUFhLE1BQWIsQ0FBTDtBQUNBLFdBQUssQ0FBQyxRQUFELEVBQVcsTUFBWCxDQUFMO0FBQ0EsV0FBSyxDQUFDLFFBQUQsRUFBVyxNQUFYLENBQUw7QUFFQSxhQUFPLElBQUksT0FBSixDQUFZLENBQUMsT0FBRCxFQUFVLE1BQVYsS0FBb0I7QUFDdEMsY0FBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLE9BQVAsQ0FBZTtBQUFFLG1CQUFGO0FBQWEsb0JBQWI7QUFBeUI7QUFBekIsU0FBZixDQUFqQjs7QUFFQSxZQUFJLFFBQUosRUFBYztBQUNiLGdCQUFNLENBQUMsTUFBUCxDQUFjO0FBQUUsZUFBRyxFQUFFLFFBQVEsQ0FBQztBQUFoQixXQUFkLEVBQXFDO0FBQ3BDLHFCQURvQztBQUVwQyxzQkFGb0M7QUFHcEMsb0JBSG9DO0FBSXBDLG9CQUpvQztBQUtwQyxnQkFBSSxFQUFFLElBQUksQ0FBQyxHQUFMO0FBTDhCLFdBQXJDLEVBTUcsRUFOSCxFQU1TLEtBQUQsSUFBa0I7QUFDekIsZ0JBQUksS0FBSixFQUFXLE1BQU0sQ0FBQyxLQUFELENBQU47QUFDWCxtQkFBTztBQUNQLFdBVEQ7QUFVQSxTQVhELE1BV087QUFDTixnQkFBTSxDQUFDLE1BQVAsQ0FBYztBQUNiLHFCQURhO0FBRWIsc0JBRmE7QUFHYixvQkFIYTtBQUliLG9CQUphO0FBS2IsZ0JBQUksRUFBRSxJQUFJLENBQUMsR0FBTDtBQUxPLFdBQWQsRUFNSSxLQUFELElBQWtCO0FBQ3BCLGdCQUFJLEtBQUosRUFBVyxNQUFNLENBQUMsS0FBRCxDQUFOO0FBQ1gsbUJBQU87QUFDUCxXQVREO0FBVUE7QUFDRCxPQTFCTSxDQUFQO0FBMkJBLEtBakNEO0FBQUEsR0FwUmM7O0FBc1RSLGNBQU4sQ0FDQyxVQURELEVBQ3FCLE1BRHJCLEVBQzhELFVBRDlELEVBQ29GLG9CQURwRjtBQUFBLG9DQUNrSDtBQUVqSCxhQUFPLElBQUksT0FBSixDQUFZLENBQUMsT0FBRCxFQUFVLE1BQVYsS0FBb0I7QUFDdEMsY0FBTSxFQUFFLEdBQUcsTUFBTSxDQUFDLE1BQVAsRUFBWDtBQUVBLFlBQUksQ0FBQyxFQUFMLEVBQVMsT0FBTyxNQUFNLEVBQWIsQ0FINkIsQ0FLdEM7O0FBQ0EsY0FBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLE9BQVIsQ0FBZ0I7QUFDaEM7QUFEZ0MsU0FBaEIsQ0FBakI7O0FBSUEsWUFBSSxRQUFKLEVBQWM7QUFDYixpQkFBTyxDQUFDLE1BQVIsQ0FBZTtBQUFFLGVBQUcsRUFBRSxRQUFRLENBQUM7QUFBaEIsV0FBZixFQUFzQztBQUNyQyxzQkFEcUM7QUFFckMsb0JBQVEsRUFBRSxFQUYyQjtBQUdyQyxzQkFIcUM7QUFJckMsZ0NBSnFDO0FBS3JDLGlCQUFLLEVBQUU7QUFMOEIsV0FBdEMsRUFNRyxFQU5ILEVBTVMsR0FBRCxJQUFnQjtBQUN2QixnQkFBSSxHQUFKLEVBQVMsTUFBTTtBQUNmLG1CQUFPO0FBQ1AsV0FURDtBQVVBLFNBWEQsTUFXTztBQUNOLGlCQUFPLENBQUMsTUFBUixDQUFlO0FBQ2Qsc0JBRGM7QUFFZCxvQkFBUSxFQUFFLEVBRkk7QUFHZCxzQkFIYztBQUlkLGdDQUpjO0FBS2QsaUJBQUssRUFBRTtBQUxPLFdBQWYsRUFNSSxHQUFELElBQWdCO0FBQ2xCLGdCQUFJLEdBQUosRUFBUyxNQUFNO0FBQ2YsbUJBQU87QUFDUCxXQVREO0FBVUE7QUFDRCxPQWpDTSxDQUFQO0FBa0NBLEtBckNEO0FBQUEsR0F0VGM7O0FBNFZSLHNCQUFOLENBQTRCLE9BQTVCLEVBQTZDLFVBQTdDO0FBQUEsb0NBQStEO0FBQzlELFdBQUssQ0FBQyxPQUFELEVBQVUsTUFBVixDQUFMO0FBQ0EsV0FBSyxDQUFDLFVBQUQsRUFBYSxNQUFiLENBQUw7QUFFQSxhQUFPLElBQUksT0FBSixDQUFZLENBQUMsT0FBRCxFQUFVLE1BQVYsS0FBb0I7QUFDdEMsY0FBTSxLQUFLLEdBQUcsZUFBZSxDQUFDLE9BQWhCLENBQXdCO0FBQUU7QUFBRixTQUF4QixDQUFkOztBQUVBLFlBQUksS0FBSixFQUFXO0FBQ1YseUJBQWUsQ0FBQyxNQUFoQixDQUNDO0FBQUUsZUFBRyxFQUFFLEtBQUssQ0FBQztBQUFiLFdBREQsRUFDcUI7QUFBRSxzQkFBRjtBQUFjO0FBQWQsV0FEckIsRUFDOEMsRUFEOUMsRUFFRSxHQUFELElBQWdCO0FBQ2YsZ0JBQUksR0FBSixFQUFTLE1BQU0sQ0FBQyxHQUFELENBQU47QUFDVCxtQkFBTztBQUNQLFdBTEY7QUFPQSxTQVJELE1BUU87QUFDTix5QkFBZSxDQUFDLE1BQWhCLENBQ0M7QUFBRSxzQkFBRjtBQUFjO0FBQWQsV0FERCxFQUVFLEdBQUQsSUFBZ0I7QUFDZixnQkFBSSxHQUFKLEVBQVMsTUFBTSxDQUFDLEdBQUQsQ0FBTjtBQUNULG1CQUFPO0FBQ1AsV0FMRjtBQU9BO0FBQ0QsT0FwQk0sQ0FBUDtBQXFCQSxLQXpCRDtBQUFBLEdBNVZjOztBQXNYZCwwQkFBeUIsT0FBekIsRUFBMEMsTUFBMUMsRUFBb0U7QUFDbkUsU0FBSyxDQUFDLE9BQUQsRUFBVSxNQUFWLENBQUw7QUFFQSxXQUFPLENBQUMsTUFBUixDQUFlO0FBQUUsU0FBRyxFQUFFO0FBQVAsS0FBZixFQUFpQztBQUFFLFVBQUksRUFBRTtBQUFFLGdCQUFRLEVBQUU7QUFBWjtBQUFSLEtBQWpDO0FBQ0EsR0ExWGE7O0FBMlhSLHdCQUFOLENBQThCLFVBQTlCLEVBQWtELE9BQWxEO0FBQUEsb0NBQWtFO0FBQ2pFLFdBQUssQ0FBRSxVQUFGLEVBQWMsTUFBZCxDQUFMO0FBQ0EsV0FBSyxDQUFFLE9BQUYsRUFBVyxPQUFYLENBQUw7QUFFQSxhQUFPLElBQUksT0FBSixDQUFhLENBQUMsT0FBRCxFQUFVLE9BQVYsS0FBcUI7QUFDeEMsMEJBQWtCLENBQUMsTUFBbkIsQ0FBMEI7QUFBRSxhQUFHLEVBQUU7QUFBUCxTQUExQixFQUErQztBQUFFLGNBQUksRUFBRTtBQUFFLG9CQUFRLEVBQUU7QUFBWjtBQUFSLFNBQS9DLEVBQWdGLEVBQWhGLEVBQXFGLE1BQUs7QUFDekYsaUJBQU87QUFDUCxTQUZEO0FBR0EsT0FKTSxDQUFQO0FBS0EsS0FURDtBQUFBOztBQTNYYyxDQUFmLEU7Ozs7Ozs7Ozs7O0FDN0NBOztBQUFpQixNQUFFLENBQU0sSUFBUixDQUFRLHNDQUFSLEVBQThCO0FBQUE7QUFBQTtBQUFBOztBQUFBLENBQTlCLEVBQThCLENBQTlCO0FBQWpCLE9BQU8sTUFBUCxDQUFTO0FBQUEsZUFBZ0IscUJBQWhCO0FBQXNDO0FBQXRDLENBQVQ7QUFBK0M7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBOztBQWEvQyxJQUFJLE1BQU0sQ0FBQyxRQUFYLEVBQXFCO0FBQ3BCLFVBQVEsQ0FBQyxZQUFULENBQXNCLENBQUMsT0FBRCxFQUFVLElBQVYsS0FBa0I7QUFDdkMsVUFBTSxTQUFTLHFCQUNYLElBRFc7QUFFZCxXQUFLLEVBQUUsQ0FBRSxLQUFLLENBQUMsT0FBUixDQUZPLENBRVc7O0FBRlgsTUFBZjs7QUFLQSxRQUFJLE9BQU8sQ0FBQyxPQUFaLEVBQXFCO0FBQ3BCLGVBQVMsQ0FBQyxPQUFWLEdBQW9CLE9BQU8sQ0FBQyxPQUE1QjtBQUNBOztBQUVELFdBQU8sU0FBUDtBQUNBLEdBWEQ7QUFhQSxVQUFRLENBQUMsY0FBVCxDQUF3QixRQUF4QixHQUFtQywwQkFBbkM7QUFDQSxVQUFRLENBQUMsY0FBVCxDQUF3QixJQUF4QixHQUErQixrQ0FBL0I7O0FBQ0EsVUFBUSxDQUFDLGNBQVQsQ0FBd0IsYUFBeEIsQ0FBc0MsT0FBdEMsR0FBZ0QsTUFBSztBQUNwRDtBQUNBLEdBRkQ7O0FBR0EsVUFBUSxDQUFDLGNBQVQsQ0FBd0IsYUFBeEIsQ0FBc0MsSUFBdEMsR0FBNkMsQ0FBQyxLQUFELEVBQVEsR0FBUixLQUFlO0FBQzNELFdBQU8scUhBQ0YsR0FERSxrR0FBUDtBQUdBLEdBSkQ7O0FBS0EsVUFBUSxDQUFDLElBQVQsQ0FBYyxhQUFkLEdBQStCLEtBQUQsSUFBVTtBQUN2QyxXQUFPLE1BQU0sQ0FBQyxXQUFQLDBCQUFxQyxLQUFyQyxFQUFQO0FBQ0EsR0FGRDs7QUFJQSxRQUFNLENBQUMsT0FBUCxDQUFlLE9BQWYsRUFBd0IsTUFBSztBQUM1QixXQUFPLE1BQU0sQ0FBQyxLQUFQLENBQWEsSUFBYixDQUFrQixFQUFsQixFQUF1QjtBQUFFLFlBQU0sRUFBRTtBQUFFLGlCQUFTLEVBQUUsQ0FBYjtBQUFnQixjQUFNLEVBQUUsQ0FBeEI7QUFBMkIsYUFBSyxFQUFFO0FBQWxDO0FBQVYsS0FBdkIsQ0FBUDtBQUNBLEdBRkQ7QUFJQSxRQUFNLENBQUMsT0FBUCxDQUFlLGNBQWYsRUFBZ0MsS0FBRCxJQUFVO0FBQ3hDLFdBQU8sTUFBTSxDQUFDLEtBQVAsQ0FBYSxJQUFiLENBQWtCO0FBQUUsdUNBQWlDO0FBQW5DLEtBQWxCLENBQVA7QUFDQSxHQUZEO0FBR0E7O0FBRUQsTUFBTSxDQUFDLE9BQVAsQ0FBZTtBQUNkLG9CQUFtQixLQUFuQixFQUFrQyxRQUFsQyxFQUFrRDtBQUNqRCxTQUFLLENBQUMsS0FBRCxFQUFRLE1BQVIsQ0FBTDtBQUNBLFNBQUssQ0FBQyxRQUFELEVBQVcsTUFBWCxDQUFMO0FBRUEsWUFBUSxDQUFDLFVBQVQsQ0FBb0I7QUFBRSxXQUFGO0FBQVM7QUFBVCxLQUFwQjtBQUNBLEdBTmE7O0FBT2Qsb0JBQW1CLE1BQW5CLEVBQWlDO0FBQ2hDLFNBQUssQ0FBRSxNQUFGLEVBQVUsTUFBVixDQUFMO0FBRUEsVUFBTSxDQUFDLEtBQVAsQ0FBYSxNQUFiLENBQW9CO0FBQUUsU0FBRyxFQUFFO0FBQVAsS0FBcEI7QUFDQSxHQVhhOztBQVlSLDRCQUFOLENBQWtDLEtBQWxDLEVBQWlELFNBQWpEO0FBQUEsb0NBQWtFO0FBQ2pFLFlBQU0sRUFBRSxpQkFBUyxhQUFhLENBQUMsS0FBRCxDQUF0QixDQUFSO0FBRUEsWUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLE9BQVQsQ0FBaUI7QUFBRSxXQUFHLEVBQUU7QUFBUCxPQUFqQixDQUFsQjs7QUFFQSxVQUFJLENBQUMsU0FBRCxJQUFjLENBQUMsU0FBUyxDQUFDLEdBQTdCLEVBQWtDO0FBQ2pDLGVBQU8sT0FBTyxDQUFDLE1BQVIsbUNBQTBDLFNBQTFDLEVBQVA7QUFDQTs7QUFFRCxvQkFBTSxrQkFBa0IsQ0FBQyxFQUFELEVBQUssU0FBUyxDQUFDLEdBQWYsQ0FBeEI7QUFFQSxhQUFPLElBQUksT0FBSixDQUFZLENBQUMsT0FBRCxFQUFVLE1BQVYsS0FBb0I7QUFDdEMsZ0JBQVEsQ0FBQyxNQUFULENBQ0M7QUFBRSxhQUFHLEVBQUcsU0FBcUIsQ0FBQztBQUE5QixTQURELEVBRUM7QUFBRSxlQUFLLEVBQUU7QUFBRSwyQkFBZSxFQUFFO0FBQW5CO0FBQVQsU0FGRCxFQUdDLEVBSEQsRUFJRyxHQUFELElBQWdCO0FBQ2hCLGNBQUksR0FBSixFQUFTLE1BQU07QUFDZixpQkFBTztBQUNQLFNBUEY7QUFTQSxPQVZNLENBQVA7QUFXQSxLQXRCRDtBQUFBLEdBWmM7O0FBbUNSLGdCQUFOLENBQXNCLEtBQXRCO0FBQUEsb0NBQW1DO0FBQ2xDLFdBQUssQ0FBQyxLQUFELEVBQVEsTUFBUixDQUFMO0FBRUEsWUFBTSxFQUFFLGlCQUFTLGFBQWEsQ0FBQyxLQUFELENBQXRCLENBQVI7QUFFQSxVQUFJLENBQUMsRUFBTCxFQUFTLE9BQU8sT0FBTyxDQUFDLE1BQVIsQ0FBZSx1QkFBZixDQUFQO0FBRVQsY0FBUSxDQUFDLG1CQUFULENBQTZCLEVBQTdCLEVBQWlDLEtBQWpDO0FBRUEsYUFBTyxPQUFPLENBQUMsT0FBUixDQUFnQixFQUFoQixDQUFQO0FBQ0EsS0FWRDtBQUFBLEdBbkNjOztBQThDZCxtQkFBa0IsS0FBbEIsRUFBaUMsUUFBakMsRUFBaUQ7QUFDaEQsU0FBSyxDQUFDLEtBQUQsRUFBUSxNQUFSLENBQUw7QUFDQSxTQUFLLENBQUMsUUFBRCxFQUFXLE1BQVgsQ0FBTDtBQUVBLFVBQU0sQ0FBQyxpQkFBUCxDQUF5QixLQUF6QixFQUFnQyxRQUFoQztBQUNBLEdBbkRhOztBQW9EZCx5QkFBd0IsTUFBeEIsRUFBd0MsUUFBeEMsRUFBd0Q7QUFDdkQsU0FBSyxDQUFFLE1BQUYsRUFBVSxNQUFWLENBQUw7QUFDQSxTQUFLLENBQUUsUUFBRixFQUFZLE1BQVosQ0FBTDs7QUFFQSxRQUFJLENBQUMsS0FBSyxZQUFWLEVBQXdCO0FBQ3ZCLGNBQVEsQ0FBQyxXQUFULENBQXFCLE1BQXJCLEVBQTZCLFFBQTdCO0FBQ0E7QUFDRDs7QUEzRGEsQ0FBZjs7QUE4RE0sU0FBVSxhQUFWLEdBQXVCO0FBQzVCLFFBQU0sRUFBRSxHQUFHLE1BQU0sQ0FBQyxNQUFQLEVBQVg7O0FBQ0EsTUFBSSxFQUFKLEVBQVE7QUFDUCxVQUFNLElBQUksR0FBRyxNQUFNLENBQUMsS0FBUCxDQUFhLE9BQWIsQ0FBcUI7QUFBRSxTQUFHLEVBQUU7QUFBUCxLQUFyQixDQUFiOztBQUNBLFFBQUksSUFBSixFQUFVO0FBQ1QsYUFBTyxJQUFQO0FBQ0E7QUFDRDtBQUNEOztBQUVLLFNBQVUsV0FBVixDQUF1QixLQUF2QixFQUFxQztBQUMxQyxRQUFNLElBQUksR0FBRyxhQUFhLEVBQTFCOztBQUNBLE1BQUksSUFBSixFQUFVO0FBQ1QsV0FBTyxLQUFLLENBQUMsSUFBTixDQUFZLElBQUQsSUFBUztBQUMxQixVQUFJLElBQUksQ0FBQyxLQUFMLENBQVcsUUFBWCxDQUFvQixJQUFwQixDQUFKLEVBQStCO0FBQzlCLGVBQU8sSUFBUDtBQUNBO0FBQ0QsS0FKTSxDQUFQO0FBS0E7QUFDRDs7QUFFRCxTQUFTLGFBQVQsQ0FBd0IsS0FBeEIsRUFBcUM7QUFDcEMsTUFBSSxNQUFNLENBQUMsS0FBUCxDQUFhLElBQWIsQ0FBa0I7QUFBRSxVQUFNLEVBQUU7QUFBRSxnQkFBVSxFQUFFO0FBQUUsZUFBTyxFQUFFO0FBQVg7QUFBZDtBQUFWLEdBQWxCLEVBQW1FLEtBQW5FLEVBQUosRUFBZ0Y7QUFDL0UsVUFBTSxJQUFJLE1BQU0sQ0FBQyxLQUFYLENBQWlCLDBCQUFqQixDQUFOO0FBQ0E7O0FBRUQsU0FBTyxJQUFJLE9BQUosQ0FBWSxDQUFDLE9BQUQsRUFBVSxNQUFWLEtBQW9CO0FBQ3RDLFVBQU0sRUFBRSxHQUFHLFFBQVEsQ0FBQyxVQUFULENBQW9CO0FBQUUsV0FBRjtBQUFTLGNBQVEsRUFBRSxNQUFNLENBQUMsU0FBUCxDQUFpQixFQUFqQjtBQUFuQixLQUFwQixDQUFYOztBQUNBLFFBQUksRUFBSixFQUFRO0FBQ1AsYUFBTyxDQUFDLEVBQUQsQ0FBUDtBQUNBLEtBRkQsTUFFTztBQUNOLFlBQU07QUFDTjtBQUNELEdBUE0sQ0FBUDtBQVFBOztBQUVELFNBQVMsa0JBQVQsQ0FBNkIsTUFBN0IsRUFBNkMsU0FBN0MsRUFBOEQ7QUFDN0QsU0FBTyxJQUFJLE9BQUosQ0FBWSxDQUFDLE9BQUQsRUFBVSxNQUFWLEtBQW9CO0FBQ3JDLFVBQU0sQ0FBQyxLQUFQLENBQTZDLE1BQTdDLENBQ0E7QUFBRSxTQUFHLEVBQUU7QUFBUCxLQURBLEVBQ2lCO0FBQUUsVUFBSSxFQUFFO0FBQUU7QUFBRjtBQUFSLEtBRGpCLEVBRUEsRUFGQSxFQUdFLEdBQUQsSUFBZ0I7QUFDaEIsVUFBSSxHQUFKLEVBQVMsTUFBTSxDQUFDLEdBQUQsQ0FBTjtBQUNULGFBQU87QUFDUCxLQU5EO0FBUUQsR0FUTSxDQUFQO0FBVUEsQzs7Ozs7Ozs7Ozs7QUMvSkQsT0FBTyxNQUFQLENBQVM7QUFBTSxRQUFFLFFBQU0sTUFBZDtBQUFjLGdCQUFlLHNCQUE3QjtBQUE2QjtBQUE3QixDQUFUO0FBQXNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBZS9CLE1BQU0sTUFBTSxHQUFHLElBQUksS0FBSyxDQUFDLFVBQVYsQ0FBNEIsV0FBVyxDQUFDLE1BQXhDLENBQWY7O0FBRVAsSUFBSSxNQUFNLENBQUMsUUFBWCxFQUFxQjtBQUNwQixRQUFNLENBQUMsT0FBUCxDQUFlLFdBQVcsQ0FBQyxNQUEzQixFQUFtQyxTQUFTLGlCQUFULEdBQTBCO0FBQzVELFFBQUksTUFBTSxDQUFDLE1BQVAsRUFBSixFQUFxQjtBQUNwQixhQUFPLE1BQU0sQ0FBQyxJQUFQLEVBQVA7QUFDQTtBQUNELEdBSkQ7QUFLQTs7QUFFTSxNQUFNLGNBQWMsR0FBWSxDQUN0QztBQUNDLE1BQUksRUFBRSxvQkFBb0IsQ0FBQyxLQUQ1QjtBQUVDLFlBQVUsRUFBRSxFQUZiO0FBR0MsUUFBTSxFQUFFO0FBSFQsQ0FEc0MsRUFNdEM7QUFDQyxNQUFJLEVBQUUsb0JBQW9CLENBQUMsY0FENUI7QUFFQyxZQUFVLEVBQUUsRUFGYjtBQUdDLFFBQU0sRUFBRTtBQUhULENBTnNDLENBQWhDO0FBYUEsTUFBTSw2QkFBNkIsR0FBbUM7QUFDNUUsR0FBQyxvQkFBb0IsQ0FBQyxLQUF0QixHQUE4QixDQUM3QixzQkFBc0IsQ0FBQyw2QkFETSxFQUU3QixzQkFBc0IsQ0FBQyxpQkFGTSxFQUc3QixzQkFBc0IsQ0FBQyxzQ0FITSxFQUk3QixzQkFBc0IsQ0FBQyxrQ0FKTSxFQUs3QixzQkFBc0IsQ0FBQyw4QkFMTSxFQU03QixzQkFBc0IsQ0FBQyxrQ0FOTSxFQU83QixzQkFBc0IsQ0FBQyw4QkFQTSxFQVE3QixzQkFBc0IsQ0FBQyxzQkFSTSxFQVM3QixzQkFBc0IsQ0FBQyxxQ0FUTSxFQVU3QixzQkFBc0IsQ0FBQyxpQ0FWTSxFQVc3QixzQkFBc0IsQ0FBQyxvQkFYTSxFQVk3QixzQkFBc0IsQ0FBQywyQkFaTSxFQWE3QixzQkFBc0IsQ0FBQywyQkFiTSxFQWM3QixzQkFBc0IsQ0FBQyxnQ0FkTSxFQWU3QixzQkFBc0IsQ0FBQywyQkFmTSxFQWdCN0Isc0JBQXNCLENBQUMsbUJBaEJNLEVBaUI3QixzQkFBc0IsQ0FBQyxrQkFqQk0sRUFrQjdCLHNCQUFzQixDQUFDLG9DQWxCTSxFQW1CN0Isc0JBQXNCLENBQUMsa0JBbkJNLEVBb0I3QixzQkFBc0IsQ0FBQyxrQ0FwQk0sRUFxQjdCLHNCQUFzQixDQUFDLDBCQXJCTSxDQUQ4QztBQXdCNUUsR0FBQyxvQkFBb0IsQ0FBQyxjQUF0QixHQUF1QyxDQUN0QyxzQkFBc0IsQ0FBQyxTQURlLEVBRXRDLHNCQUFzQixDQUFDLG1CQUZlLEVBR3RDLHNCQUFzQixDQUFDLHVCQUhlLEVBSXRDLHNCQUFzQixDQUFDLHlCQUplLEVBS3RDLHNCQUFzQixDQUFDLGtDQUxlLEVBTXRDLHNCQUFzQixDQUFDLDBCQU5lLEVBT3RDLHNCQUFzQixDQUFDLGlCQVBlLEVBUXRDLHNCQUFzQixDQUFDLHdCQVJlO0FBeEJxQyxDQUF0RSxDOzs7Ozs7Ozs7OztBQ3RDUCxPQUFPLE1BQVAsQ0FBUztBQUFNLFlBQVEsa0JBQWQ7QUFBNkI7QUFBN0IsQ0FBVDtBQUFzQztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQWUvQixNQUFNLFVBQVUsR0FBRyxJQUFJLEtBQUssQ0FBQyxVQUFWLENBQStCLFdBQVcsQ0FBQyxVQUEzQyxDQUFuQjs7QUFFUCxJQUFJLE1BQU0sQ0FBQyxRQUFYLEVBQXFCO0FBQ3BCLFFBQU0sQ0FBQyxPQUFQLENBQWUsV0FBVyxDQUFDLFVBQTNCLEVBQXVDLFNBQVMscUJBQVQsR0FBOEI7QUFDcEUsUUFBSSxNQUFNLENBQUMsTUFBUCxFQUFKLEVBQXFCO0FBQ3BCLGFBQU8sVUFBVSxDQUFDLElBQVgsRUFBUDtBQUNBO0FBQ0QsR0FKRDtBQUtBOztBQUVNLE1BQU0sa0JBQWtCLEdBQWUsQ0FDN0M7QUFDQyxNQUFJLEVBQUUsc0JBQXNCLENBQUMsNkJBRDlCO0FBRUMsb0JBQWtCLEVBQUUsQ0FDbkI7QUFDQyxPQUFHLEVBQUUsTUFBTSxDQUFDLEVBQVAsRUFETjtBQUVDLFFBQUksRUFBRSxzQkFBc0IsQ0FBQyxLQUY5QjtBQUdDLGFBQVMsRUFBRSxLQUFLO0FBSGpCLEdBRG1CLEVBTW5CO0FBQ0MsT0FBRyxFQUFFLE1BQU0sQ0FBQyxFQUFQLEVBRE47QUFFQyxRQUFJLEVBQUUsc0JBQXNCLENBQUMsR0FGOUI7QUFHQyxhQUFTLEVBQUU7QUFIWixHQU5tQixDQUZyQjtBQWNDLGFBQVcsRUFBRSxtUEFkZDtBQWVDLFdBQVMsRUFBRSxvQkFBb0IsQ0FBQztBQWZqQyxDQUQ2QyxFQWtCN0M7QUFDQyxNQUFJLEVBQUUsc0JBQXNCLENBQUMsaUJBRDlCO0FBRUMsb0JBQWtCLEVBQUUsQ0FDbkI7QUFDQyxPQUFHLEVBQUUsTUFBTSxDQUFDLEVBQVAsRUFETjtBQUVDLFFBQUksRUFBRSxzQkFBc0IsQ0FBQyxJQUY5QjtBQUdDLGFBQVMsRUFBRSxHQUhaO0FBSUMsZUFBVyxFQUFFO0FBSmQsR0FEbUIsRUFPbkI7QUFDQyxPQUFHLEVBQUUsTUFBTSxDQUFDLEVBQVAsRUFETjtBQUVDLFFBQUksRUFBRSxzQkFBc0IsQ0FBQyxJQUY5QjtBQUdDLGVBQVcsRUFBRTtBQUhkLEdBUG1CLENBRnJCO0FBZUMsYUFBVyxFQUFFLCtPQWZkO0FBZ0JDLFdBQVMsRUFBRSxvQkFBb0IsQ0FBQztBQWhCakMsQ0FsQjZDLEVBb0M3QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQyxzQ0FEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEtBRjlCO0FBR0MsYUFBUyxFQUFFLElBQUk7QUFIaEIsR0FEbUIsQ0FGckI7QUFTQyxhQUFXLEVBQUUsNE5BVGQ7QUFVQyxXQUFTLEVBQUUsb0JBQW9CLENBQUM7QUFWakMsQ0FwQzZDLEVBZ0Q3QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQyxrQ0FEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEtBRjlCO0FBR0MsYUFBUyxFQUFFLElBQUk7QUFIaEIsR0FEbUIsQ0FGckI7QUFTQyxhQUFXLEVBQUUsa05BVGQ7QUFVQyxXQUFTLEVBQUUsb0JBQW9CLENBQUM7QUFWakMsQ0FoRDZDLEVBNEQ3QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQyw4QkFEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEtBRjlCO0FBR0MsYUFBUyxFQUFFLEtBQUssTUFIakI7QUFJQyxlQUFXLEVBQUU7QUFKZCxHQURtQixFQU9uQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLElBRjlCO0FBR0MsYUFBUyxFQUFFLEdBSFo7QUFJQyxlQUFXLEVBQUU7QUFKZCxHQVBtQixDQUZyQjtBQWdCQyxhQUFXLEVBQUUsOFRBaEJkO0FBaUJDLFdBQVMsRUFBRSxvQkFBb0IsQ0FBQztBQWpCakMsQ0E1RDZDLEVBK0U3QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQyxrQ0FEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEdBRjlCO0FBR0MsYUFBUyxFQUFFO0FBSFosR0FEbUIsQ0FGckI7QUFTQyxhQUFXLEVBQUUsbVBBVGQ7QUFVQyxXQUFTLEVBQUUsb0JBQW9CLENBQUM7QUFWakMsQ0EvRTZDLEVBMkY3QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQyw4QkFEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEtBRjlCO0FBR0MsYUFBUyxFQUFFLEtBQUs7QUFIakIsR0FEbUIsQ0FGckI7QUFTQyxhQUFXLEVBQUUsdU1BVGQ7QUFVQyxXQUFTLEVBQUUsb0JBQW9CLENBQUM7QUFWakMsQ0EzRjZDLEVBdUc3QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQyxzQkFEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEtBRjlCO0FBR0MsYUFBUyxFQUFFLEtBQUs7QUFIakIsR0FEbUIsQ0FGckI7QUFTQyxhQUFXLEVBQUUsb1FBVGQ7QUFVQyxXQUFTLEVBQUUsb0JBQW9CLENBQUM7QUFWakMsQ0F2RzZDLEVBbUg3QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQyxxQ0FEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEtBRjlCO0FBR0MsYUFBUyxFQUFFLEtBQUs7QUFIakIsR0FEbUIsQ0FGckI7QUFTQyxhQUFXLEVBQUUsMFJBVGQ7QUFVQyxXQUFTLEVBQUUsb0JBQW9CLENBQUM7QUFWakMsQ0FuSDZDLEVBK0g3QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQyxpQ0FEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEtBRjlCO0FBR0MsYUFBUyxFQUFFLEtBQUs7QUFIakIsR0FEbUIsQ0FGckI7QUFTQyxhQUFXLEVBQUUsb0hBVGQ7QUFVQyxXQUFTLEVBQUUsb0JBQW9CLENBQUM7QUFWakMsQ0EvSDZDLEVBMkk3QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQyxvQkFEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEtBRjlCO0FBR0MsYUFBUyxFQUFFLElBQUksTUFIaEI7QUFJQyxlQUFXLEVBQUU7QUFKZCxHQURtQixFQU9uQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEdBRjlCO0FBR0MsYUFBUyxFQUFFLEVBSFo7QUFJQyxlQUFXLEVBQUU7QUFKZCxHQVBtQixDQUZyQjtBQWdCQyxhQUFXLEVBQUUsNlNBaEJkO0FBaUJDLFdBQVMsRUFBRSxvQkFBb0IsQ0FBQztBQWpCakMsQ0EzSTZDLEVBOEo3QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQywyQkFEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEtBRjlCO0FBR0MsYUFBUyxFQUFFLEtBQUs7QUFIakIsR0FEbUIsQ0FGckI7QUFTQyxhQUFXLEVBQUUsb2pCQVRkO0FBVUMsV0FBUyxFQUFFLG9CQUFvQixDQUFDO0FBVmpDLENBOUo2QyxFQTBLN0M7QUFDQyxNQUFJLEVBQUUsc0JBQXNCLENBQUMsMkJBRDlCO0FBRUMsb0JBQWtCLEVBQUUsQ0FDbkI7QUFDQyxPQUFHLEVBQUUsTUFBTSxDQUFDLEVBQVAsRUFETjtBQUVDLFFBQUksRUFBRSxzQkFBc0IsQ0FBQyxLQUY5QjtBQUdDLGFBQVMsRUFBRSxLQUFLO0FBSGpCLEdBRG1CLENBRnJCO0FBU0MsYUFBVyxFQUFFLDhWQVRkO0FBVUMsV0FBUyxFQUFFLG9CQUFvQixDQUFDO0FBVmpDLENBMUs2QyxFQXNMN0M7QUFDQyxNQUFJLEVBQUUsc0JBQXNCLENBQUMsZ0NBRDlCO0FBRUMsb0JBQWtCLEVBQUUsQ0FDbkI7QUFDQyxPQUFHLEVBQUUsTUFBTSxDQUFDLEVBQVAsRUFETjtBQUVDLFFBQUksRUFBRSxzQkFBc0IsQ0FBQyxLQUY5QjtBQUdDLGFBQVMsRUFBRSxLQUFLO0FBSGpCLEdBRG1CLENBRnJCO0FBU0MsYUFBVyxFQUFFLHFHQVRkO0FBVUMsV0FBUyxFQUFFLG9CQUFvQixDQUFDO0FBVmpDLENBdEw2QyxFQWtNN0M7QUFDQyxNQUFJLEVBQUUsc0JBQXNCLENBQUMsMkJBRDlCO0FBRUMsb0JBQWtCLEVBQUUsQ0FDbkI7QUFDQyxPQUFHLEVBQUUsTUFBTSxDQUFDLEVBQVAsRUFETjtBQUVDLFFBQUksRUFBRSxzQkFBc0IsQ0FBQyxLQUY5QjtBQUdDLGFBQVMsRUFBRSxLQUFLO0FBSGpCLEdBRG1CLEVBTW5CO0FBQ0MsT0FBRyxFQUFFLE1BQU0sQ0FBQyxFQUFQLEVBRE47QUFFQyxRQUFJLEVBQUUsc0JBQXNCLENBQUMsSUFGOUI7QUFHQyxhQUFTLEVBQUUsR0FIWjtBQUlDLGVBQVcsRUFBRTtBQUpkLEdBTm1CLENBRnJCO0FBZUMsYUFBVyxFQUFFLG9OQWZkO0FBZ0JDLFdBQVMsRUFBRSxvQkFBb0IsQ0FBQztBQWhCakMsQ0FsTTZDLEVBb043QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQyxtQkFEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEtBRjlCO0FBR0MsYUFBUyxFQUFFLEtBQUs7QUFIakIsR0FEbUIsQ0FGckI7QUFTQyxhQUFXLEVBQUUsd0pBVGQ7QUFVQyxXQUFTLEVBQUUsb0JBQW9CLENBQUM7QUFWakMsQ0FwTjZDLEVBZ083QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQyxrQkFEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEtBRjlCO0FBR0MsYUFBUyxFQUFFLEtBQUs7QUFIakIsR0FEbUIsQ0FGckI7QUFTQyxhQUFXLEVBQUUsME5BVGQ7QUFVQyxXQUFTLEVBQUUsb0JBQW9CLENBQUM7QUFWakMsQ0FoTzZDLEVBNE83QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQyxvQ0FEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEtBRjlCO0FBR0MsYUFBUyxFQUFFLEtBQUs7QUFIakIsR0FEbUIsQ0FGckI7QUFTQyxhQUFXLEVBQUUseUhBVGQ7QUFVQyxXQUFTLEVBQUUsb0JBQW9CLENBQUM7QUFWakMsQ0E1TzZDLEVBd1A3QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQyxrQkFEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEtBRjlCO0FBR0MsYUFBUyxFQUFFLEtBQUs7QUFIakIsR0FEbUIsQ0FGckI7QUFTQyxhQUFXLEVBQUUsMExBVGQ7QUFVQyxXQUFTLEVBQUUsb0JBQW9CLENBQUM7QUFWakMsQ0F4UDZDLEVBb1E3QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQyxrQ0FEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEtBRjlCO0FBR0MsYUFBUyxFQUFFLEtBQUs7QUFIakIsR0FEbUIsQ0FGckI7QUFTQyxhQUFXLEVBQUUseUlBVGQ7QUFVQyxXQUFTLEVBQUUsb0JBQW9CLENBQUM7QUFWakMsQ0FwUTZDLEVBZ1I3QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQywwQkFEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEtBRjlCO0FBR0MsYUFBUyxFQUFFLEtBQUs7QUFIakIsR0FEbUIsQ0FGckI7QUFTQyxhQUFXLEVBQUUsaUVBVGQ7QUFVQyxXQUFTLEVBQUUsb0JBQW9CLENBQUM7QUFWakMsQ0FoUjZDLEVBNFI3QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQyxTQUQ5QjtBQUVDLG9CQUFrQixFQUFFLENBQ25CO0FBQ0MsT0FBRyxFQUFFLE1BQU0sQ0FBQyxFQUFQLEVBRE47QUFFQyxRQUFJLEVBQUUsc0JBQXNCLENBQUMsS0FGOUI7QUFHQyxhQUFTLEVBQUUsS0FBSztBQUhqQixHQURtQixDQUZyQjtBQVNDLGFBQVcsRUFBRSxzREFUZDtBQVVDLFdBQVMsRUFBRSxvQkFBb0IsQ0FBQztBQVZqQyxDQTVSNkMsRUF3UzdDO0FBQ0MsTUFBSSxFQUFFLHNCQUFzQixDQUFDLG1CQUQ5QjtBQUVDLG9CQUFrQixFQUFFLENBQ25CO0FBQ0MsT0FBRyxFQUFFLE1BQU0sQ0FBQyxFQUFQLEVBRE47QUFFQyxRQUFJLEVBQUUsc0JBQXNCLENBQUMsS0FGOUI7QUFHQyxhQUFTLEVBQUUsS0FBSztBQUhqQixHQURtQixDQUZyQjtBQVNDLGFBQVcsRUFBRSxtakJBVGQ7QUFVQyxXQUFTLEVBQUUsb0JBQW9CLENBQUM7QUFWakMsQ0F4UzZDLEVBb1Q3QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQyx1QkFEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEtBRjlCO0FBR0MsYUFBUyxFQUFFLEtBQUs7QUFIakIsR0FEbUIsQ0FGckI7QUFTQyxhQUFXLEVBQUUsd1BBVGQ7QUFVQyxXQUFTLEVBQUUsb0JBQW9CLENBQUM7QUFWakMsQ0FwVDZDLEVBZ1U3QztBQUNDLE1BQUksRUFBRSxzQkFBc0IsQ0FBQyx5QkFEOUI7QUFFQyxvQkFBa0IsRUFBRSxDQUNuQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLEdBRjlCO0FBR0MsYUFBUyxFQUFFLFdBSFo7QUFJQyxlQUFXLEVBQUU7QUFKZCxHQURtQixDQUZyQjtBQVVDLGFBQVcsRUFBRSx3TUFWZDtBQVdDLFdBQVMsRUFBRSxvQkFBb0IsQ0FBQztBQVhqQyxDQWhVNkMsRUE2VTdDO0FBQ0MsTUFBSSxFQUFFLHNCQUFzQixDQUFDLGtDQUQ5QjtBQUVDLG9CQUFrQixFQUFFLENBQ25CO0FBQ0MsT0FBRyxFQUFFLE1BQU0sQ0FBQyxFQUFQLEVBRE47QUFFQyxRQUFJLEVBQUUsc0JBQXNCLENBQUMsS0FGOUI7QUFHQyxhQUFTLEVBQUUsS0FBSztBQUhqQixHQURtQixDQUZyQjtBQVNDLGFBQVcsRUFBRSwwS0FUZDtBQVVDLFdBQVMsRUFBRSxvQkFBb0IsQ0FBQztBQVZqQyxDQTdVNkMsRUF5VjdDO0FBQ0MsTUFBSSxFQUFFLHNCQUFzQixDQUFDLDBCQUQ5QjtBQUVDLG9CQUFrQixFQUFFLENBQ25CO0FBQ0MsT0FBRyxFQUFFLE1BQU0sQ0FBQyxFQUFQLEVBRE47QUFFQyxRQUFJLEVBQUUsc0JBQXNCLENBQUMsS0FGOUI7QUFHQyxhQUFTLEVBQUUsSUFBSTtBQUhoQixHQURtQixDQUZyQjtBQVNDLGFBQVcsRUFBRSxtTkFUZDtBQVVDLFdBQVMsRUFBRSxvQkFBb0IsQ0FBQztBQVZqQyxDQXpWNkMsRUFxVzdDO0FBQ0MsTUFBSSxFQUFFLHNCQUFzQixDQUFDLGlCQUQ5QjtBQUVDLG9CQUFrQixFQUFFLENBQ25CO0FBQ0MsT0FBRyxFQUFFLE1BQU0sQ0FBQyxFQUFQLEVBRE47QUFFQyxRQUFJLEVBQUUsc0JBQXNCLENBQUMsSUFGOUI7QUFHQyxhQUFTLEVBQUU7QUFIWixHQURtQixDQUZyQjtBQVNDLGFBQVcsRUFBRSxvZkFUZDtBQVVDLFdBQVMsRUFBRSxvQkFBb0IsQ0FBQztBQVZqQyxDQXJXNkMsRUFpWDdDO0FBQ0MsTUFBSSxFQUFFLHNCQUFzQixDQUFDLHdCQUQ5QjtBQUVDLG9CQUFrQixFQUFFLENBQ25CO0FBQ0MsT0FBRyxFQUFFLE1BQU0sQ0FBQyxFQUFQLEVBRE47QUFFQyxRQUFJLEVBQUUsc0JBQXNCLENBQUMsS0FGOUI7QUFHQyxhQUFTLEVBQUUsS0FBSztBQUhqQixHQURtQixFQU1uQjtBQUNDLE9BQUcsRUFBRSxNQUFNLENBQUMsRUFBUCxFQUROO0FBRUMsUUFBSSxFQUFFLHNCQUFzQixDQUFDLElBRjlCO0FBR0MsYUFBUyxFQUFFO0FBSFosR0FObUIsQ0FGckI7QUFjQyxhQUFXLEVBQUUsbVBBZGQ7QUFlQyxXQUFTLEVBQUUsb0JBQW9CLENBQUM7QUFmakMsQ0FqWDZDLENBQXZDLEM7Ozs7Ozs7Ozs7O0FDekJQLE9BQU8sTUFBUCxDQUFTO0FBQU0sU0FBRSxFQUFNO0FBQWQsQ0FBVDtBQUF1QixJQUFlLE1BQWY7QUFBZTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFlL0IsTUFBTSxPQUFPLEdBQUcsSUFBSSxLQUFLLENBQUMsVUFBVixDQUE0QixXQUFXLENBQUMsT0FBeEMsQ0FBaEI7O0FBRVAsSUFBSSxNQUFNLENBQUMsUUFBWCxFQUFxQjtBQUNwQixRQUFNLENBQUMsT0FBUCxDQUFlLFdBQVcsQ0FBQyxPQUEzQixFQUFvQyxTQUFTLGtCQUFULEdBQTJCO0FBQzlELFFBQUksTUFBTSxDQUFDLE1BQVAsTUFBbUIsV0FBVyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQVAsRUFBYyxLQUFLLENBQUMsSUFBcEIsRUFBMEIsS0FBSyxDQUFDLEtBQWhDLENBQUQsQ0FBbEMsRUFBNEU7QUFDM0UsYUFBTyxPQUFPLENBQUMsSUFBUixFQUFQO0FBQ0EsS0FGRCxNQUVPLElBQUksTUFBTSxDQUFDLE1BQVAsTUFBbUIsV0FBVyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQVAsQ0FBRCxDQUFsQyxFQUFxRDtBQUMzRCxhQUFPLE9BQU8sQ0FBQyxJQUFSLENBQWE7QUFBRSxpQkFBUyxFQUFHLE1BQU0sQ0FBQyxJQUFQLEdBQTRCO0FBQTFDLE9BQWIsQ0FBUDtBQUNBO0FBQ0QsR0FORDtBQU9BLEM7Ozs7Ozs7Ozs7O0FDekJELE9BQU8sTUFBUCxDQUFTO0FBQU0sb0JBQVEsUUFBZSxrQkFBN0I7QUFBNkI7QUFBN0IsQ0FBVDtBQUFzQztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQXVDL0IsTUFBTSxrQkFBa0IsR0FBRyxJQUFJLEtBQUssQ0FBQyxVQUFWLENBQStCLFdBQVcsQ0FBQyxRQUEzQyxDQUEzQjs7QUFFUCxJQUFJLE1BQU0sQ0FBQyxRQUFYLEVBQXFCO0FBQ3BCLFFBQU0sQ0FBQyxPQUFQLENBQWUsV0FBVyxDQUFDLFFBQTNCLEVBQXFDLE1BQUs7QUFDekMsUUFBSSxNQUFNLENBQUMsTUFBUCxNQUFtQixXQUFXLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBUCxFQUFjLEtBQUssQ0FBQyxJQUFwQixFQUEwQixLQUFLLENBQUMsS0FBaEMsQ0FBRCxDQUFsQyxFQUE0RTtBQUMzRSxhQUFPLGtCQUFrQixDQUFDLElBQW5CLENBQXdCLEVBQXhCLENBQVA7QUFDQTtBQUNELEdBSkQ7QUFLQTs7QUFFTSxTQUFlLGNBQWYsQ0FBK0IsUUFBL0I7QUFBQSxrQ0FBaUQ7QUFDdkQsV0FBTyxJQUFJLE9BQUosQ0FBWSxDQUFDLE9BQUQsRUFBVSxNQUFWLEtBQW9CO0FBQ3RDLHdCQUFrQixDQUFDLE1BQW5CLENBQTBCLFFBQTFCLEVBQW9DLENBQUMsS0FBRCxFQUFhLEVBQWIsS0FBMkI7QUFDOUQsWUFBSSxLQUFKLEVBQVcsTUFBTSxDQUFDLEtBQUQsQ0FBTixDQURtRCxDQUU5RDtBQUNBOztBQUNBLGVBQU8sQ0FBQyxFQUFELENBQVA7QUFDQSxPQUxEO0FBTUEsS0FQTSxDQUFQO0FBUUEsR0FUTTtBQUFBLEM7Ozs7Ozs7Ozs7O0FDakRQLE9BQU8sTUFBUCxDQUFTO0FBQU0saUJBQVE7QUFBZCxDQUFUO0FBQXNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBVy9CLE1BQU0sZUFBZSxHQUFHLElBQUksS0FBSyxDQUFDLFVBQVYsQ0FBc0MsV0FBVyxDQUFDLGVBQWxELENBQXhCOztBQUVQLElBQUksTUFBTSxDQUFDLFFBQVgsRUFBcUI7QUFDcEIsUUFBTSxDQUFDLE9BQVAsQ0FBZSxXQUFXLENBQUMsZUFBM0IsRUFBNEMsTUFBSztBQUNoRCxRQUFJLE1BQU0sQ0FBQyxNQUFQLE1BQW1CLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFQLEVBQWMsS0FBSyxDQUFDLEtBQXBCLEVBQTJCLEtBQUssQ0FBQyxJQUFqQyxDQUFELENBQWxDLEVBQTRFO0FBQzNFLGFBQU8sZUFBZSxDQUFDLElBQWhCLENBQXFCLEVBQXJCLENBQVA7QUFDQTtBQUNELEdBSkQ7QUFLQSxDOzs7Ozs7Ozs7OztBQ25CRCxPQUFPLE1BQVAsQ0FBUztBQUFNLFNBQUUsRUFBTTtBQUFkLENBQVQ7QUFBdUIsSUFBZSxNQUFmO0FBQWU7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBZ0IvQixNQUFNLE9BQU8sR0FBRyxJQUFJLEtBQUssQ0FBQyxVQUFWLENBQTZCLFdBQVcsQ0FBQyxPQUF6QyxDQUFoQjs7QUFFUCxJQUFJLE1BQU0sQ0FBQyxRQUFYLEVBQXFCO0FBQ3BCLFFBQU0sQ0FBQyxPQUFQLENBQWUsV0FBVyxDQUFDLE9BQTNCLEVBQW9DLE1BQUs7QUFDeEMsUUFBSSxNQUFNLENBQUMsTUFBUCxFQUFKLEVBQXFCO0FBQ3BCLFVBQUksV0FBVyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQVAsRUFBYyxLQUFLLENBQUMsSUFBcEIsRUFBMEIsS0FBSyxDQUFDLEtBQWhDLENBQUQsQ0FBZixFQUF5RDtBQUN4RCxlQUFPLE9BQU8sQ0FBQyxJQUFSLENBQWEsRUFBYixDQUFQO0FBQ0EsT0FGRCxNQUVPLElBQUksV0FBVyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQVAsQ0FBRCxDQUFmLEVBQWdDO0FBQ3RDLGVBQU8sRUFBUCxDQURzQyxDQUM1QjtBQUNWLE9BRk0sTUFFQTtBQUNOLGVBQU8sRUFBUDtBQUNBO0FBQ0Q7QUFDRCxHQVZEO0FBV0EsQzs7Ozs7Ozs7Ozs7QUM5QkQsT0FBTyxNQUFQLENBQVM7QUFBTSxRQUFFLFFBQU07QUFBZCxDQUFUO0FBQXVCLElBQWUsTUFBZjtBQUFlO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQWMvQixNQUFNLE1BQU0sR0FBRyxJQUFJLEtBQUssQ0FBQyxVQUFWLENBQTRCLFdBQVcsQ0FBQyxNQUF4QyxDQUFmOztBQUVQLElBQUksTUFBTSxDQUFDLFFBQVgsRUFBcUI7QUFDcEIsUUFBTSxDQUFDLE9BQVAsQ0FBZSxXQUFXLENBQUMsTUFBM0IsRUFBbUMsTUFBSztBQUN2QyxRQUFJLE1BQU0sQ0FBQyxNQUFQLE1BQW1CLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFQLEVBQWMsS0FBSyxDQUFDLElBQXBCLEVBQTBCLEtBQUssQ0FBQyxLQUFoQyxDQUFELENBQWxDLEVBQTRFO0FBQzNFLGFBQU8sTUFBTSxDQUFDLElBQVAsQ0FBWSxFQUFaLENBQVA7QUFDQTtBQUNELEdBSkQ7QUFLQSxDOzs7Ozs7Ozs7OztBQ3RCRCxPQUFPLE1BQVAsQ0FBUztBQUFNLFVBQVEsZ0JBQWQ7QUFBYyxtQkFBZSx5QkFBN0I7QUFBNkI7QUFBN0IsQ0FBVDtBQUFzQztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFlL0IsTUFBTSxRQUFRLEdBQUcsSUFBSSxLQUFLLENBQUMsVUFBVixDQUE4QixXQUFXLENBQUMsUUFBMUMsQ0FBakI7O0FBRVAsSUFBSSxNQUFNLENBQUMsUUFBWCxFQUFxQjtBQUNwQixRQUFNLENBQUMsT0FBUCxDQUFlLFdBQVcsQ0FBQyxRQUEzQixFQUFxQyxNQUFLO0FBQ3pDLFVBQU0sRUFBRSxHQUFHLE1BQU0sQ0FBQyxNQUFQLEVBQVg7O0FBQ0EsUUFBSSxFQUFKLEVBQVE7QUFDUCxZQUFNLElBQUksR0FBRyxhQUFhLEVBQTFCOztBQUNBLFVBQUksSUFBSixFQUFVO0FBQ1QsWUFBSSxXQUFXLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBUCxFQUFjLEtBQUssQ0FBQyxJQUFwQixDQUFELENBQWYsRUFBNEM7QUFDM0MsaUJBQU8sUUFBUSxDQUFDLElBQVQsQ0FBYyxFQUFkLENBQVA7QUFDQSxTQUZELE1BRU8sSUFBSSxXQUFXLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBUCxDQUFELENBQWYsRUFBZ0M7QUFDdEMsaUJBQU8sUUFBUSxDQUFDLElBQVQsQ0FBYztBQUFFLGdCQUFJLEVBQUU7QUFBRSxpQkFBRyxFQUFFO0FBQVA7QUFBUixXQUFkLENBQVA7QUFDQSxTQUZNLE1BRUE7QUFDTixpQkFBTyxRQUFRLENBQUMsSUFBVCxDQUFjO0FBQUUsZUFBRyxFQUFFLElBQUksQ0FBQyxTQUFaO0FBQXVCLDJCQUFlLEVBQUU7QUFBeEMsV0FBZCxDQUFQO0FBQ0E7QUFDRDtBQUNEO0FBQ0QsR0FkRDtBQWVBOztBQUVLLFNBQVUsaUJBQVYsR0FBMkI7QUFDaEMsUUFBTSxFQUFFLEdBQUcsTUFBTSxDQUFDLE1BQVAsRUFBWDs7QUFDQSxNQUFJLEVBQUosRUFBUTtBQUNQLFVBQU0sSUFBSSxHQUFHLGFBQWEsRUFBMUI7O0FBQ0EsUUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFNBQWpCLEVBQTRCO0FBQzNCLGFBQU8sUUFBUSxDQUFDLE9BQVQsQ0FBaUI7QUFBRSxXQUFHLEVBQUUsSUFBSSxDQUFDLFNBQVo7QUFBdUIsdUJBQWUsRUFBRTtBQUF4QyxPQUFqQixDQUFQO0FBQ0E7QUFDRDtBQUNEOztBQUVNLE1BQU0sZ0JBQWdCLEdBQWMsQ0FDMUM7QUFDQyxNQUFJLEVBQUUsT0FEUDtBQUVDLGtCQUFnQixFQUFFLElBRm5CO0FBR0MsaUJBQWUsRUFBRTtBQUhsQixDQUQwQyxDQUFwQyxDOzs7Ozs7Ozs7OztBQzdDUCxPQUFPLE1BQVAsQ0FBYztBQUFBLFFBQUUsRUFBTTtBQUFSLENBQWQ7QUFBc0IsSUFBYyxLQUFkO0FBQWM7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBTzdCLE1BQU0sTUFBTSxHQUFHLElBQUksS0FBSyxDQUFDLFVBQVYsQ0FBa0MsV0FBVyxDQUFDLE1BQTlDLENBQWYsQzs7Ozs7Ozs7Ozs7QUNQUDs7QUFBaUIsTUFBRSxDQUFNLElBQVIsQ0FBUSxzQ0FBUixFQUE4QjtBQUFBO0FBQUE7QUFBQTs7QUFBQSxDQUE5QixFQUE4QixDQUE5QjtBQUFqQjtBQUFTLE1BQVUsS0FBVixDQUFnQixzQkFBaEIsRUFBc0M7QUFBQTtBQUFBO0FBQUE7O0FBQUEsQ0FBdEMsRUFBc0MsQ0FBdEM7QUFBc0M7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBOztBQW9CL0MsU0FBUyxjQUFULENBQXlCLFFBQXpCLEVBQTJDO0FBQzFDLFlBQVUsQ0FBQyxNQUFYLENBQWtCLFFBQWxCO0FBQ0E7O0FBRUQsTUFBTSxDQUFDLE9BQVAsQ0FBZSxNQUFLO0FBQ25CLE1BQUksVUFBVSxDQUFDLElBQVgsR0FBa0IsS0FBbEIsT0FBOEIsQ0FBbEMsRUFBcUM7QUFDcEMsc0JBQWtCLENBQUMsT0FBbkIsQ0FBNEIsUUFBRCxJQUFhO0FBQ3ZDLG9CQUFjLENBQUMsUUFBRCxDQUFkO0FBQ0EsS0FGRDtBQUdBOztBQUVELE1BQUksTUFBTSxDQUFDLElBQVAsR0FBYyxLQUFkLE9BQTBCLENBQTlCLEVBQWlDO0FBQ2hDLGtCQUFjLENBQUMsT0FBZixDQUF3QixLQUFELElBQVU7QUFDaEMsVUFBSSxLQUFLLENBQUMsSUFBTixJQUFjLDZCQUFsQixFQUFpRDtBQUNoRCxxQ0FBNkIsQ0FBQyxLQUFLLENBQUMsSUFBUCxDQUE3QixDQUEwQyxPQUExQyxDQUFtRCxRQUFELElBQWE7QUFDOUQsZ0JBQU0sR0FBRyxHQUFHLFVBQVUsQ0FBQyxPQUFYLENBQW1CO0FBQUUsZ0JBQUksRUFBRSxRQUFSO0FBQWtCLHFCQUFTLEVBQUUsS0FBSyxDQUFDO0FBQW5DLFdBQW5CLENBQVo7O0FBQ0EsY0FBSSxHQUFHLElBQUksR0FBRyxDQUFDLEdBQWYsRUFBb0I7QUFDbkIsaUJBQUssQ0FBQyxVQUFOLENBQWlCLElBQWpCLENBQXNCLEdBQUcsQ0FBQyxHQUExQjtBQUNBO0FBQ0QsU0FMRDtBQU1BOztBQUVELFlBQU0sQ0FBQyxNQUFQLENBQWMsS0FBZDtBQUNBLEtBWEQ7QUFZQTs7QUFFRCxNQUFJLE1BQU0sQ0FBQyxLQUFQLENBQWEsSUFBYixDQUFrQixFQUFsQixFQUF1QixLQUF2QixHQUErQixNQUEvQixLQUEwQyxDQUE5QyxFQUFpRDtBQUNoRCxZQUFRLENBQUMsVUFBVCxDQUFvQjtBQUFFLFdBQUssRUFBRSxlQUFUO0FBQTBCLGNBQVEsRUFBRTtBQUFwQyxLQUFwQjtBQUNBOztBQUVELE1BQUksUUFBUSxDQUFDLElBQVQsR0FBZ0IsS0FBaEIsT0FBNEIsQ0FBaEMsRUFBbUM7QUFDbEMsVUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLEtBQVAsQ0FBYSxPQUFiLENBQXFCO0FBQUUsWUFBTSxFQUFFO0FBQUUsZUFBTyxFQUFFLGVBQVg7QUFBNEIsZ0JBQVEsRUFBRTtBQUF0QztBQUFWLEtBQXJCLENBQWI7O0FBRUEsUUFBSSxJQUFKLEVBQVU7QUFDVCxzQkFBZ0IsQ0FBQyxPQUFqQixDQUEwQixPQUFELElBQVk7QUFDcEMsZ0JBQVEsQ0FBQyxNQUFULG1CQUNJLE9BREosTUFFSTtBQUNGLHlCQUFlLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBTjtBQURmLFNBRko7QUFNQSxPQVBEO0FBU0EsWUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLE9BQVQsQ0FBaUI7QUFBRSxZQUFJLEVBQUU7QUFBUixPQUFqQixDQUFkOztBQUNBLFVBQUksS0FBSixFQUFXO0FBQ1YsY0FBTSxDQUFDLEtBQVAsQ0FBYSxNQUFiLENBQW9CLElBQUksQ0FBQyxHQUF6QixvQkFDSSxJQURKO0FBRUMsbUJBQVMsRUFBRSxLQUFLLENBQUMsR0FGbEI7QUFHQyxlQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBUCxFQUFjLEtBQUssQ0FBQyxLQUFwQixFQUEyQixLQUFLLENBQUMsSUFBakMsRUFBdUMsS0FBSyxDQUFDLE9BQTdDO0FBSFI7QUFNQSxjQUFNLGVBQWUsR0FBRyxVQUFVLENBQUMsT0FBWCxDQUFtQjtBQUFFLGNBQUksRUFBRSxzQkFBc0IsQ0FBQztBQUEvQixTQUFuQixDQUF4Qjs7QUFDQSxZQUFJLGVBQWUsSUFBSSxLQUFLLENBQUMsR0FBekIsSUFBZ0MsZUFBZSxDQUFDLEdBQXBELEVBQXlEO0FBQ3hELHlCQUFlLENBQUMsTUFBaEIsQ0FBdUI7QUFDdEIsbUJBQU8sRUFBRSxJQUFJLENBQUMsR0FEUTtBQUV0QixzQkFBVSxFQUFFLGVBQWUsQ0FBQztBQUZOLFdBQXZCO0FBSUE7QUFDRDtBQUNEO0FBQ0Q7O0FBRUQsTUFBSSxlQUFlLENBQUMsSUFBaEIsR0FBdUIsS0FBdkIsT0FBbUMsQ0FBdkMsRUFBMEM7QUFDekM7QUFFQSxVQUFNLElBQUksR0FBRyxNQUFNLENBQUMsS0FBUCxDQUFhLE9BQWIsQ0FBcUI7QUFBRSxZQUFNLEVBQUU7QUFBRSxlQUFPLEVBQUUsZUFBWDtBQUE0QixnQkFBUSxFQUFFO0FBQXRDO0FBQVYsS0FBckIsQ0FBYjs7QUFFQSxRQUFJLElBQUosRUFBVTtBQUNULFlBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxJQUFYLENBQWdCLEVBQWhCLEVBQXFCLEtBQXJCLEVBQW5CO0FBRUEsZ0JBQVUsQ0FBQyxPQUFYLENBQW9CLFFBQUQsSUFBYTtBQUMvQixZQUFJLFFBQVEsQ0FBQyxJQUFULEtBQWtCLHNCQUFzQixDQUFDLDZCQUE3QyxFQUE0RTtBQUM1RSx1QkFBZSxDQUFDLE1BQWhCLENBQXVCO0FBQ3RCLGlCQUFPLEVBQUUsSUFBSSxDQUFDLEdBRFE7QUFFdEIsb0JBQVUsRUFBRSxRQUFRLENBQUMsR0FBVCxJQUFnQjtBQUZOLFNBQXZCO0FBSUEsT0FORDtBQU9BO0FBQ0QsR0ExRWtCLENBNEVuQjs7O0FBQ0EsTUFBSSxNQUFNLENBQUMsWUFBWCxFQUF5QjtBQUN4QixVQUFNLENBQUMsS0FBUCxDQUFhLE1BQWIsQ0FBb0IsRUFBcEIsRUFBeUI7QUFBRSxVQUFJLEVBQUU7QUFBRSx1Q0FBK0I7QUFBakM7QUFBUixLQUF6QixFQUEwRTtBQUFFLFdBQUssRUFBRTtBQUFULEtBQTFFO0FBQ0E7O0FBRUQsTUFBSSxNQUFNLENBQUMsSUFBUCxHQUFjLEtBQWQsR0FBc0IsTUFBdEIsS0FBaUMsQ0FBckMsRUFBd0M7QUFDdkMsVUFBTSxDQUFDLE1BQVAsQ0FBYztBQUNiLGFBQU8sRUFBRTtBQURJLEtBQWQ7QUFJQSxVQUFNLGVBQWUsR0FBRyxVQUFVLENBQUMsT0FBWCxDQUFtQjtBQUFFLFVBQUksRUFBRSxzQkFBc0IsQ0FBQztBQUEvQixLQUFuQixDQUF4Qjs7QUFFQSxRQUFJLENBQUMsZUFBTCxFQUFzQjtBQUNyQixZQUFNLFFBQVEsR0FBRyxrQkFBa0IsQ0FBQyxJQUFuQixDQUNmLFFBQUQsSUFBYyxRQUFRLENBQUMsSUFBVCxLQUFrQixzQkFBc0IsQ0FBQywwQkFEdkMsQ0FBakI7O0FBSUEsVUFBSSxRQUFKLEVBQWM7QUFDYixjQUFNLEVBQUUsR0FBRyxVQUFVLENBQUMsTUFBWCxDQUFrQixRQUFsQixDQUFYO0FBRUEsY0FBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLE9BQVAsQ0FBZTtBQUFFLGNBQUksRUFBRSxvQkFBb0IsQ0FBQztBQUE3QixTQUFmLENBQWQ7O0FBRUEsWUFBSSxLQUFKLEVBQVc7QUFDVixnQkFBTSxDQUFDLE1BQVAsQ0FBYztBQUFFLGVBQUcsRUFBRSxLQUFLLENBQUM7QUFBYixXQUFkLEVBQWtDO0FBQUUsaUJBQUssRUFBRTtBQUFFLHdCQUFVLEVBQUU7QUFBZDtBQUFULFdBQWxDO0FBQ0E7QUFDRDtBQUNEO0FBQ0Q7QUFDRCxDQXhHRCxFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgTUlOVVRFID0gNjAgKiAxMDAwXG4iLCIvKipcbiAqIEFsbCBlbnVtcyBzaG91bGQgYmUgcGxhY2VkIGluIHRoaXMgZmlsZSB0byBhdm9pZCBjaXJjdWxhciBkZXBlbmRlbmNpZXMsXG4gKiAgd2hpY2ggY2FuIGxlYWQgdG8gdGhlIHR5cGVzY3JpcHQgY29tcGlsZXIgbm90IGV2YWx1YXRpbmcgdGhlbSBwcm9wZXJseS5cbiAqL1xuXG5leHBvcnQgY29uc3QgZW51bSBDb2xsZWN0aW9ucyB7XG5cdEFXQVJEUyA9ICdhd2FyZHMnLFxuXHRDQVRFR09SSUVTID0gJ2NhdGVnb3JpZXMnLFxuXHRTVEFUSU9OUyA9ICdzdGF0aW9ucycsXG5cdFNVUFBPUlRJTkdfRVZJREVOQ0UgPSAnc3VwcG9ydGluZ19ldmlkZW5jZScsXG5cdEVOVFJJRVMgPSAnZW50cmllcycsXG5cdEVWSURFTkNFID0gJ2V2aWRlbmNlJyxcblx0SnVkZ2VUb0NhdGVnb3J5ID0gJ2p1ZGdlVG9DYXRlZ29yeScsXG5cdFNDT1JFUyA9ICdzY29yZXMnLFxuXHRSRVNVTFRTID0gJ3Jlc3VsdHMnLFxuXHRTWVNURU0gPSAnc3lzdGVtJ1xufVxuXG5leHBvcnQgY29uc3QgZW51bSBSb2xlcyB7XG5cdFVOQVNTSUdORUQgPSAndW5hc3NpZ25lZCcsXG5cdEhPU1QgPSAnaG9zdCcsXG5cdEpVREdFID0gJ2p1ZGdlJyxcblx0U1RBVElPTiA9ICdzdGF0aW9uJyxcblx0QURNSU4gPSAnYWRtaW4nXG59XG5cbmV4cG9ydCBjb25zdCBlbnVtIERFRkFVTFRfQVdBUkRTX05BTUVTIHtcblx0TkFTVEEgPSAnTmFTVEEgQXdhcmRzJyxcblx0UEVPUExFU19DSE9JQ0UgPSAnUGVvcGxlXFwncyBDaG9pY2UgQXdhcmRzJ1xufVxuXG5leHBvcnQgY29uc3QgZW51bSBTdXBwb3J0aW5nRXZpZGVuY2VUeXBlIHtcblx0VklERU8gPSAnVklERU8nLFxuXHRURVhUID0gJ1RFWFQnLFxuXHRQREYgPSAnUERGJyxcblx0Q0FMTCA9ICdDQUxMJ1xufVxuXG5leHBvcnQgY29uc3QgZW51bSBFbnRyeVR5cGUge1xuXHRWSURFTyA9ICdlbnRyeV92aWRlbycsXG5cdERPQ1VNRU5UID0gJ2VudHJ5X2RvY3VtZW50J1xufVxuXG5leHBvcnQgY29uc3QgZW51bSBWZXJpZmljYXRpb25TdGF0dXMge1xuXHRXQUlUSU5HID0gJ3N0YXR1c193YWl0aW5nJyxcblx0VkVSSUZJRUQgPSAnc3RhdHVzX3ZlcmlmaWVkJyxcblx0UkVKRUNURUQgPSAnc3RhdHVzX3JlamVjdGVkJyxcblx0RElTUFVURUQgPSAnc3RhdHVzX2Rpc3B1dGVkJ1xufVxuXG5leHBvcnQgY29uc3QgZW51bSBERUZBVUxUX0NBVEVHT1JZX05BTUVTIHtcblx0TmFTVEFfQVdBUkRTX0JFU1RfQlJPQURDQVNURVIgPSAnQmVzdCBCcm9hZGNhc3RlcicsXG5cdE5hU1RBX0FXQVJEU19KSVNDID0gJ0ppc2MgYXdhcmQgZm9yIFNwZWNpYWwgUmVjb2duaXRpb24nLFxuXHROYVNUQV9BV0FSRFNfQkVTVF9EUkFNQVRJQ19QRVJGT1JNQU5DRSA9ICdCZXN0IERyYW1hdGljIFBlcmZvcm1hbmNlJyxcblx0TmFTVEFfQVdBUkRTX0JFU1RfT05fU0NSRUVOX1RBTEVOVCA9ICdCZXN0IE9uLVNjcmVlbiBUYWxlbnQnLFxuXHROYVNUQV9BV0FSRFNfU1RBVElPTl9NQVJLRVRJTkcgPSAnU3RhdGlvbiBNYXJrZXRpbmcnLFxuXHROYVNUQV9BV0FSRFNfVEVDSE5JQ0FMX0FDSElFVkVNRU5UID0gJ1RlY2huaWNhbCBBY2hpZXZlbWVudCcsXG5cdE5hU1RBX0FXQVJEU19GUkVTSEVSU19DT1ZFUkFHRSA9ICdGcmVzaGVyc1xcJyBDb3ZlcmFnZScsXG5cdE5hU1RBX0FXQVJEU19BTklNQVRJT04gPSAnQW5pbWF0aW9uJyxcblx0TmFTVEFfQVdBUkRTX05FV1NfQU5EX0NVUlJFTlRfQUZGQUlSUyA9ICdOZXdzIGFuZCBDdXJyZW50IEFmZmFpcnMnLFxuXHROYVNUQV9BV0FSRFNfTUFSU19FTEtJTlNfRUxfQlJPR1kgPSAnVGhlIE1hcnMgRWxraW5zIEVsLUJyb2d5IEF3YXJkIGZvciBNdWx0aW1lZGlhIENvbnRlbnQnLFxuXHROYVNUQV9BV0FSRFNfV1JJVElORyA9ICdXcml0aW5nJyxcblx0TmFTVEFfQVdBUkRTX0xJVkVfQlJPQURDQVNUID0gJ0xpdmUgQnJvYWRjYXN0Jyxcblx0TmFTVEFfQVdBUkRTX0NJTkVNQVRPR1JBUEhZID0gJ0NpbWVtYXRvZ3JhcGh5Jyxcblx0TmFTVEFfQVdBUkRTX0xJR0hUX0VOVEVSVEFJTk1FTlQgPSAnTGlnaHQgRW50ZXJ0YWlubWVudCcsXG5cdE5hU1RBX0FXQVJEU19USVRMRV9TRVFVRU5DRSA9ICdUaXRsZSBTZXF1ZW5jZScsXG5cdE5hU1RBX0FXQVJEU19DT01FRFkgPSAnQ29tZWR5Jyxcblx0TmFTVEFfQVdBUkRTX0RSQU1BID0gJ0RyYW1hJyxcblx0TkFTVEFfQVdBUkRTX0RPQ1VNRU5UQVJZX0FORF9GQUNUVUFMID0gJ0RvY3VtZW50YXJ5ICYgRmFjdHVhbCcsXG5cdE5hU1RBX0FXQVJEU19TUE9SVCA9ICdTcG9ydCcsXG5cdE5hU1RBX0FXQVJEU19QT1NUX1BST0RVQ1RJT05fQVdBUkQgPSAnUG9zdCBQcm9kdWN0aW9uIEF3YXJkJyxcblx0TmFTVEFfQVdBUkRTX1NVUEVSX0JMT09QRVIgPSAnU3VwZXIgQmxvb3BlcicsXG5cdFBDQXNfT1BFTiA9ICdPcGVuJyxcblx0UENBc19MSVZFX0JST0FEQ0FTVCA9ICdMaXZlIEJyb2FkY2FzdCcsXG5cdFBDQXNfQ09OVEVOVF9JTk5PVkFUSU9OID0gJ0NvbnRlbnQgSW5ub3ZhdGlvbicsXG5cdFBDQXNfVEVDSE5JQ0FMX0lOTk9WQVRJT04gPSAnVGVjaG5pY2FsIElubm92YXRpb24nLFxuXHRQQ0FzX1ZJU1VBTF9DUkVBVElWSVRZX0FORF9RVUFMSVRZID0gJ1Zpc3VhbCBDcmVhdGl2aXR5ICYgUXVhbGl0eScsXG5cdFBDQXNfQkVTVF9PTl9TQ1JFRU5fVEFMRU5UID0gJ0Jlc3QgT24tU2NyZWVuIFRhbGVudCcsXG5cdFBDQXNfVU5fU1VOR19IRVJPID0gJ1VuLVN1bmcgSGVybycsXG5cdFBDQXNfU1RBVElPTl9PRl9USEVfWUVBUiA9ICdTdGF0aW9uIE9mIFRoZSBZZWFyJ1xufVxuIiwiaW1wb3J0IHsgRHJvcGJveCB9IGZyb20gJ2Ryb3Bib3gnXG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjaydcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgZmV0Y2ggZnJvbSAnbm9kZS1mZXRjaCdcbmltcG9ydCB7IE5hU1RBVXNlciwgVXNlckhhc1JvbGUgfSBmcm9tICcuLi9hY2NvdW50cydcbmltcG9ydCB7IENhdGVnb3JpZXMgfSBmcm9tICcuLi9jYXRlZ29yaWVzJ1xuaW1wb3J0IHsgRW50cmllcyB9IGZyb20gJy4uL2VudHJpZXMnXG5pbXBvcnQgeyBFdmlkZW5jZUNvbGxlY3Rpb24sIEV2aWRlbmNlUERGLCBFdmlkZW5jZVZpZGVvLCBJbnNlcnRFdmlkZW5jZSB9IGZyb20gJy4uL2V2aWRlbmNlJ1xuaW1wb3J0IHsgSnVkZ2VUb0NhdGVnb3J5IH0gZnJvbSAnLi4vanVkZ2VUb0NhdGVnb3J5J1xuaW1wb3J0IHsgUmVzdWx0LCBSZXN1bHRzIH0gZnJvbSAnLi4vcmVzdWx0cydcbmltcG9ydCB7IFNjb3JlcyB9IGZyb20gJy4uL3Njb3JlcydcbmltcG9ydCB7IEdldFN0YXRpb25Gb3JVc2VyLCBTdGF0aW9ucyB9IGZyb20gJy4uL3N0YXRpb25zJ1xuaW1wb3J0IHsgU3VwcG9ydGluZ0V2aWRlbmNlUERGLCBTdXBwb3J0aW5nRXZpZGVuY2VWaWRlbyB9IGZyb20gJy4uL3N1cHBvcnRpbmctZXZpZGVuY2UnXG5pbXBvcnQgeyBSb2xlcywgU3VwcG9ydGluZ0V2aWRlbmNlVHlwZSwgVmVyaWZpY2F0aW9uU3RhdHVzIH0gZnJvbSAnLi9lbnVtcydcblxuZXhwb3J0IGNvbnN0IERST1BCT1hfVE9LRU4gPSBNZXRlb3Iuc2V0dGluZ3MuZHJvcGJveC5hY2Nlc3NUb2tlblxuXG5jb25zdCBkYnggPSBuZXcgRHJvcGJveCh7IGFjY2Vzc1Rva2VuOiBEUk9QQk9YX1RPS0VOLCBmZXRjaCB9KVxuXG5mdW5jdGlvbiBiNjRUb0J1ZmZlciAoYjY0RW5jb2Rpbmc6IHN0cmluZyk6IEJ1ZmZlciB7XG5cdGNvbnN0IGluZGV4ID0gYjY0RW5jb2RpbmcuaW5kZXhPZignO2Jhc2U2NCwnKVxuXG5cdHJldHVybiBuZXcgQnVmZmVyKGI2NEVuY29kaW5nLnNsaWNlKGluZGV4ICsgJztiYXNlNjQsJy5sZW5ndGgpLCAnYmFzZTY0Jylcbn1cblxuZnVuY3Rpb24gR2V0U2hhcmluZ0xpbmsgKGZpbGVQYXRoTG93ZXI6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG5cdHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0ZGJ4LnNoYXJpbmdDcmVhdGVTaGFyZWRMaW5rV2l0aFNldHRpbmdzKHtcblx0XHRcdHBhdGg6IGZpbGVQYXRoTG93ZXIsXG5cdFx0XHRzZXR0aW5nczoge1xuXHRcdFx0XHRyZXF1ZXN0ZWRfdmlzaWJpbGl0eToge1xuXHRcdFx0XHRcdCcudGFnJzogJ3B1YmxpYydcblx0XHRcdFx0fSxcblx0XHRcdFx0YXVkaWVuY2U6IHtcblx0XHRcdFx0XHQnLnRhZyc6ICdwdWJsaWMnXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KS50aGVuKChyZXN1bHQpID0+IHtcblx0XHRcdHJlc29sdmUocmVzdWx0LnVybClcblx0XHR9KS5jYXRjaCgoZXJyKSA9PiB7XG5cdFx0XHRyZWplY3QoZXJyKVxuXHRcdH0pXG5cdH0pXG59XG5cbk1ldGVvci5tZXRob2RzKHtcblx0YXN5bmMgJ3N1Ym1pc3Npb24uc3RhcnRTZXNzaW9uJyAoY2h1bms6IHN0cmluZyk6IFByb21pc2U8YW55PiB7XG5cdFx0Y2hlY2soY2h1bmssIFN0cmluZylcblx0XHRjb25zb2xlLmxvZygnU3RhcnRpbmcgbmV3IHVwbG9hZCBzZXNzaW9uJylcblx0XHRyZXR1cm4gZGJ4LmZpbGVzVXBsb2FkU2Vzc2lvblN0YXJ0KHtcblx0XHRcdGNvbnRlbnRzOiBiNjRUb0J1ZmZlcihjaHVuayksXG5cdFx0XHRjbG9zZTogZmFsc2Vcblx0XHR9KS5jYXRjaCgoZXJyKSA9PiB7XG5cdFx0XHRyZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyKVxuXHRcdH0pLnRoZW4oKHJlc3VsdCkgPT4ge1xuXHRcdFx0cmV0dXJuIFByb21pc2UucmVzb2x2ZShyZXN1bHQuc2Vzc2lvbl9pZClcblx0XHR9KVxuXHR9LFxuXHRhc3luYyAnc3VibWlzc2lvbi51cGxvYWRDaHVuaycgKFxuXHRcdGNodW5rOiBzdHJpbmcsIHNlc3Npb25JZDogc3RyaW5nLCBjaHVua1NpemU6IG51bWJlciwgY2h1bmtOdW1iZXI6IG51bWJlciwgZmluaXNoOiBib29sZWFuLCBwYXRoOiBzdHJpbmdcblx0KTogUHJvbWlzZTxhbnk+IHtcblx0XHRjaGVjayhjaHVuaywgU3RyaW5nKVxuXHRcdGNoZWNrKHNlc3Npb25JZCwgU3RyaW5nKVxuXHRcdGNoZWNrKGNodW5rU2l6ZSwgTnVtYmVyKVxuXHRcdGNoZWNrKGNodW5rTnVtYmVyLCBOdW1iZXIpXG5cdFx0Y2hlY2soZmluaXNoLCBCb29sZWFuKVxuXHRcdGNoZWNrKHBhdGgsIFN0cmluZylcblxuXHRcdGNvbnNvbGUubG9nKGBVcGxvYWRpbmcgb2Zmc2V0ICR7Y2h1bmtOdW1iZXIqY2h1bmtTaXplfWApXG5cblx0XHRpZiAoZmluaXNoKSB7XG5cdFx0XHRyZXR1cm4gZGJ4LmZpbGVzVXBsb2FkU2Vzc2lvbkZpbmlzaCh7XG5cdFx0XHRcdGNvbnRlbnRzOiBiNjRUb0J1ZmZlcihjaHVuayksXG5cdFx0XHRcdGN1cnNvcjoge1xuXHRcdFx0XHRcdHNlc3Npb25faWQ6IHNlc3Npb25JZCxcblx0XHRcdFx0XHRvZmZzZXQ6IGNodW5rU2l6ZSAqIGNodW5rTnVtYmVyXG5cdFx0XHRcdH0sXG5cdFx0XHRcdGNvbW1pdDoge1xuXHRcdFx0XHRcdHBhdGgsXG5cdFx0XHRcdFx0bW9kZToge1xuXHRcdFx0XHRcdFx0Jy50YWcnOiAnYWRkJ1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fSBhcyBhbnkpLmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0cmV0dXJuIFByb21pc2UucmVqZWN0KGVycilcblx0XHRcdH0pLnRoZW4oKHJlc3VsdCkgPT4ge1xuXHRcdFx0XHRyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHJlc3VsdC5wYXRoX2xvd2VyKVxuXHRcdFx0fSlcblx0XHR9IGVsc2Uge1xuXHRcdFx0cmV0dXJuIGRieC5maWxlc1VwbG9hZFNlc3Npb25BcHBlbmQoe1xuXHRcdFx0XHRjb250ZW50czogYjY0VG9CdWZmZXIoY2h1bmspLFxuXHRcdFx0XHRzZXNzaW9uX2lkOiBzZXNzaW9uSWQsXG5cdFx0XHRcdG9mZnNldDogY2h1bmtOdW1iZXIqY2h1bmtTaXplXG5cdFx0XHR9KS5jYXRjaCgoZXJyKSA9PiB7XG5cdFx0XHRcdHJldHVybiBQcm9taXNlLnJlamVjdChlcnIpXG5cdFx0XHR9KS50aGVuKChyZXN1bHQpID0+IHtcblx0XHRcdFx0cmV0dXJuIFByb21pc2UucmVzb2x2ZShyZXN1bHQpXG5cdFx0XHR9KVxuXHRcdH1cblx0fSxcblx0YXN5bmMgJ3N1Ym1pc3Npb24udXBsb2FkRmlsZScgKGI2NEVuY29kaW5nOiBzdHJpbmcsIHBhdGg6IHN0cmluZyk6IFByb21pc2U8YW55PiB7XG5cdFx0Y2hlY2soYjY0RW5jb2RpbmcsIFN0cmluZylcblx0XHRjaGVjayhwYXRoLCBTdHJpbmcpXG5cblx0XHRjb25zdCBmaWxlID0gYjY0VG9CdWZmZXIoYjY0RW5jb2RpbmcpXG5cblx0XHRpZiAoZmlsZS5sZW5ndGggPiAxMDAgKiAxMDI0ICogMTAyNCkge1xuXHRcdFx0Y29uc29sZS5sb2coJ1RvbyBsYXJnZScpXG5cdFx0XHRyZXR1cm4gLy8gVE9ETzogU2VuZCBzb21lIGVycm9yXG5cdFx0fVxuXG5cdFx0cmV0dXJuIGRieC5maWxlc1VwbG9hZCh7XG5cdFx0XHRjb250ZW50czogZmlsZSxcblx0XHRcdHBhdGhcblx0XHR9KS5jYXRjaCgoZXJyb3IpID0+IHtcblx0XHRcdGNvbnNvbGUubG9nKGVycm9yKVxuXHRcdH0pLnRoZW4oKHJlc3VsdCkgPT4ge1xuXHRcdFx0aWYgKHJlc3VsdCkge1xuXHRcdFx0XHRyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHJlc3VsdC5wYXRoX2xvd2VyKVxuXHRcdFx0fVxuXHRcdFx0Y29uc29sZS5sb2coJ1VwbG9hZGVkIGEgc21hbGwgZmlsZScpXG5cdFx0fSlcblx0fSxcblx0YXN5bmMgJ3N1Ym1pc3Npb24uc3VibWl0JyAodmFsdWVzOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9LCBjYXRlZ29yeUlkOiBzdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuXHRcdGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHZhbHVlcykpXG5cdFx0Y2hlY2soY2F0ZWdvcnlJZCwgU3RyaW5nKVxuXG5cdFx0aWYgKE1ldGVvci51c2VySWQoKSkge1xuXHRcdFx0Y29uc3Qgc3RhdGlvbiA9IEdldFN0YXRpb25Gb3JVc2VyKClcblxuXHRcdFx0aWYgKCFzdGF0aW9uKSB7XG5cdFx0XHRcdHJldHVybiBuZXcgTWV0ZW9yLkVycm9yKCdZb3UgZG8gbm90IGJlbG9uZyB0byBhbiBlbGlnaWJsZSBzdGF0aW9uJylcblx0XHRcdH1cblxuXHRcdFx0aWYgKCFzdGF0aW9uLl9pZCkge1xuXHRcdFx0XHRyZXR1cm4gbmV3IE1ldGVvci5FcnJvcignWW91IGRvIG5vdCBiZWxvbmcgdG8gYW4gZWxpZ2libGUgc3RhdGlvbicpXG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IGNhdGVnb3J5ID0gQ2F0ZWdvcmllcy5maW5kT25lKHsgX2lkOiBjYXRlZ29yeUlkIH0pXG5cblx0XHRcdGlmICghY2F0ZWdvcnkpIHtcblx0XHRcdFx0cmV0dXJuIG5ldyBNZXRlb3IuRXJyb3IoJ0NhdGVnb3J5IG5vdCBmb3VuZCcpXG5cdFx0XHR9XG5cblx0XHRcdGxldCBhbGxQcmVzZW50ID0gdHJ1ZVxuXHRcdFx0Y2F0ZWdvcnkuc3VwcG9ydGluZ0V2aWRlbmNlLmZvckVhY2goKGV2KSA9PiB7XG5cdFx0XHRcdGlmICghT2JqZWN0LmtleXModmFsdWVzKS5pbmNsdWRlcyhldi5faWQpICYmIGV2LnR5cGUgIT09IFN1cHBvcnRpbmdFdmlkZW5jZVR5cGUuQ0FMTCkge1xuXHRcdFx0XHRcdGFsbFByZXNlbnQgPSBmYWxzZVxuXHRcdFx0XHR9XG5cdFx0XHR9KVxuXG5cdFx0XHRpZiAoIWFsbFByZXNlbnQpIHtcblx0XHRcdFx0cmV0dXJuIG5ldyBNZXRlb3IuRXJyb3IoJ1lvdSBoYXZlIG5vdCBwcm92aWRlZCBhbGwgcmVxdWlyZWQgZXZpZGVuY2UgZm9yIHRoaXMgc3VibWlzc2lvbicpXG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IGV2aWRlbmNlOiBzdHJpbmdbXSA9IFtdXG5cblx0XHRcdC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTogZm9yaW5cblx0XHRcdGZvciAoY29uc3Qgc3VwcG9ydCBvZiBjYXRlZ29yeS5zdXBwb3J0aW5nRXZpZGVuY2UpIHtcblx0XHRcdFx0aWYgKCFzdXBwb3J0Ll9pZCkge1xuXHRcdFx0XHRcdGNvbnRpbnVlXG5cdFx0XHRcdH1cblxuXHRcdFx0XHRsZXQgaWQgPSAnJ1xuXHRcdFx0XHRpZiAoc3VwcG9ydC50eXBlID09PSBTdXBwb3J0aW5nRXZpZGVuY2VUeXBlLkNBTEwpIHtcblx0XHRcdFx0XHRpZCA9IGF3YWl0IEluc2VydEV2aWRlbmNlKHtcblx0XHRcdFx0XHRcdHR5cGU6IFN1cHBvcnRpbmdFdmlkZW5jZVR5cGUuQ0FMTCxcblx0XHRcdFx0XHRcdGNvbnRlbnQ6ICdDYWxsIFJlcXVpcmVkJyxcblx0XHRcdFx0XHRcdHZlcmlmaWVkOiBmYWxzZSxcblx0XHRcdFx0XHRcdHN1cHBvcnRpbmdFdmlkZW5jZUlkOiBzdXBwb3J0Ll9pZCxcblx0XHRcdFx0XHRcdGF3YXJkSWQ6IGNhdGVnb3J5SWQsXG5cdFx0XHRcdFx0XHRzdGF0aW9uSWQ6IHN0YXRpb24uX2lkXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRpZiAoc3VwcG9ydC50eXBlID09PSBTdXBwb3J0aW5nRXZpZGVuY2VUeXBlLlZJREVPIHx8IHN1cHBvcnQudHlwZSA9PT0gU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5QREYpIHtcblxuXHRcdFx0XHRcdFx0bGV0IHNoYXJpbmdMaW5rID0gJydcblx0XHRcdFx0XHRcdGxldCBzaG9ydENsaXBTaGFyaW5nTGluayA9ICcnXG5cblx0XHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRcdHNoYXJpbmdMaW5rID0gYXdhaXQgR2V0U2hhcmluZ0xpbmsodmFsdWVzW3N1cHBvcnQuX2lkXSlcblx0XHRcdFx0XHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRcdFx0XHRcdGlmIChlcnJvci5lcnJvci5lcnJvclsnLnRhZyddID09PSAnc2hhcmVkX2xpbmtfYWxyZWFkeV9leGlzdHMnKSB7XG5cdFx0XHRcdFx0XHRcdFx0Y29uc3QgcHJldiA9IEV2aWRlbmNlQ29sbGVjdGlvbi5maW5kT25lKHtcblx0XHRcdFx0XHRcdFx0XHRcdHN0YXRpb25JZDogc3RhdGlvbi5faWQsXG5cdFx0XHRcdFx0XHRcdFx0XHRhd2FyZElkOiBjYXRlZ29yeUlkLFxuXHRcdFx0XHRcdFx0XHRcdFx0c3VwcG9ydGluZ0V2aWRlbmNlSWQ6IHN1cHBvcnQuX2lkXG5cdFx0XHRcdFx0XHRcdFx0fSkgYXMgRXZpZGVuY2VWaWRlbyB8IEV2aWRlbmNlUERGIHwgdW5kZWZpbmVkXG5cblx0XHRcdFx0XHRcdFx0XHRpZiAocHJldiAmJiBwcmV2LnNoYXJpbmdMaW5rLmxlbmd0aCkge1xuXHRcdFx0XHRcdFx0XHRcdFx0c2hhcmluZ0xpbmsgPSBwcmV2LnNoYXJpbmdMaW5rXG5cdFx0XHRcdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdFx0XHRcdHRocm93IG5ldyBFcnJvcignU29tZXRoaW5nIHdlbnQgd3JvbmcsIHBsZWFzZSB0cnkgYWdhaW4nKVxuXHRcdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0XHRpZiAodmFsdWVzW2Ake3N1cHBvcnQuX2lkfTEwU2VjYF0pIHtcblx0XHRcdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdFx0XHRzaG9ydENsaXBTaGFyaW5nTGluayA9IGF3YWl0IEdldFNoYXJpbmdMaW5rKHZhbHVlc1tgJHtzdXBwb3J0Ll9pZH0xMFNlY2BdKVxuXHRcdFx0XHRcdFx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0XHRcdFx0XHRcdGlmIChlcnJvci5lcnJvci5lcnJvclsnLnRhZyddID09PSAnc2hhcmVkX2xpbmtfYWxyZWFkeV9leGlzdHMnKSB7XG5cdFx0XHRcdFx0XHRcdFx0XHRjb25zdCBwcmV2ID0gRXZpZGVuY2VDb2xsZWN0aW9uLmZpbmRPbmUoe1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRzdGF0aW9uSWQ6IHN0YXRpb24uX2lkLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRhd2FyZElkOiBjYXRlZ29yeUlkLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRzdXBwb3J0aW5nRXZpZGVuY2VJZDogc3VwcG9ydC5faWRcblx0XHRcdFx0XHRcdFx0XHRcdH0pIGFzIEV2aWRlbmNlVmlkZW9cblxuXHRcdFx0XHRcdFx0XHRcdFx0aWYgKHByZXYgJiYgcHJldi5zaG9ydENsaXBTaGFyaW5nTGluay5sZW5ndGgpIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0c2hvcnRDbGlwU2hhcmluZ0xpbmsgPSBwcmV2LnNob3J0Q2xpcFNoYXJpbmdMaW5rXG5cdFx0XHRcdFx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHR0aHJvdyBuZXcgRXJyb3IoJ1NvbWV0aGluZyB3ZW50IHdyb25nLCBwbGVhc2UgdHJ5IGFnYWluJylcblx0XHRcdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdFx0aWQgPSBhd2FpdCBJbnNlcnRFdmlkZW5jZSh7XG5cdFx0XHRcdFx0XHRcdHR5cGU6IHN1cHBvcnQudHlwZSxcblx0XHRcdFx0XHRcdFx0Y29udGVudDogdmFsdWVzW3N1cHBvcnQuX2lkXSxcblx0XHRcdFx0XHRcdFx0dmVyaWZpZWQ6IGZhbHNlLFxuXHRcdFx0XHRcdFx0XHRzdXBwb3J0aW5nRXZpZGVuY2VJZDogc3VwcG9ydC5faWQsXG5cdFx0XHRcdFx0XHRcdGF3YXJkSWQ6IGNhdGVnb3J5SWQsXG5cdFx0XHRcdFx0XHRcdHN0YXRpb25JZDogc3RhdGlvbi5faWQsXG5cdFx0XHRcdFx0XHRcdHNoYXJpbmdMaW5rLFxuXHRcdFx0XHRcdFx0XHRzaG9ydENsaXBTaGFyaW5nTGlua1xuXHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0aWQgPSBhd2FpdCBJbnNlcnRFdmlkZW5jZSh7XG5cdFx0XHRcdFx0XHRcdHR5cGU6IHN1cHBvcnQudHlwZSxcblx0XHRcdFx0XHRcdFx0Y29udGVudDogdmFsdWVzW3N1cHBvcnQuX2lkXSxcblx0XHRcdFx0XHRcdFx0dmVyaWZpZWQ6IHN1cHBvcnQudHlwZSA9PT0gU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5URVhULFxuXHRcdFx0XHRcdFx0XHRzdXBwb3J0aW5nRXZpZGVuY2VJZDogc3VwcG9ydC5faWQsXG5cdFx0XHRcdFx0XHRcdGF3YXJkSWQ6IGNhdGVnb3J5SWQsXG5cdFx0XHRcdFx0XHRcdHN0YXRpb25JZDogc3RhdGlvbi5faWRcblx0XHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cblx0XHRcdFx0ZXZpZGVuY2UucHVzaChpZClcblx0XHRcdH1cblxuXHRcdFx0RW50cmllcy5pbnNlcnQoe1xuXHRcdFx0XHRzdGF0aW9uSWQ6IHN0YXRpb24uX2lkLFxuXHRcdFx0XHRjYXRlZ29yeUlkLFxuXHRcdFx0XHRkYXRlOiBEYXRlLm5vdygpLFxuXHRcdFx0XHRldmlkZW5jZUlkczogZXZpZGVuY2UsXG5cdFx0XHRcdHZpZGVvTGlua3M6IHZhbHVlcy5MSU5LUyxcblx0XHRcdFx0dmVyaWZpZWQ6IFZlcmlmaWNhdGlvblN0YXR1cy5XQUlUSU5HXG5cdFx0XHR9LCAoZXJyb3I6IHN0cmluZykgPT4ge1xuXHRcdFx0XHRpZiAoZXJyb3IpIHJldHVybiBuZXcgTWV0ZW9yLkVycm9yKGVycm9yKVxuXHRcdFx0XHRyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKClcblx0XHRcdH0pXG5cdFx0fSBlbHNlIHtcblx0XHRcdHJldHVybiBuZXcgTWV0ZW9yLkVycm9yKCdZb3VcXCdyZSBub3QgbG9nZ2VkIGluJylcblx0XHR9XG5cdH0sXG5cdCdyb2xlLmFkZCcgKHJvbGU6IFJvbGVzLCB1c2VySWQ6IHN0cmluZykge1xuXHRcdGNoZWNrKHVzZXJJZCwgU3RyaW5nKVxuXG5cdFx0aWYgKCFNZXRlb3IudXNlcklkKCkgfHwgIVVzZXJIYXNSb2xlKFtSb2xlcy5BRE1JTl0pKSByZXR1cm5cblxuXHRcdGNvbnN0IHVzZXIgPSBNZXRlb3IudXNlcnMuZmluZE9uZSh7IF9pZDogdXNlcklkIH0pIGFzIE5hU1RBVXNlclxuXG5cdFx0aWYgKCF1c2VyKSByZXR1cm5cblxuXHRcdGlmICh1c2VyLnJvbGVzLmluY2x1ZGVzKHJvbGUpKSByZXR1cm5cblxuXHRcdE1ldGVvci51c2Vycy51cGRhdGUodXNlcklkLCB7XG5cdFx0XHQkc2V0OiB7XG5cdFx0XHRcdHJvbGVzOiBbLi4udXNlci5yb2xlcywgcm9sZV1cblx0XHRcdH1cblx0XHR9KVxuXHR9LFxuXHQncm9sZS5yZW1vdmUnIChyb2xlOiBSb2xlcywgdXNlcklkOiBzdHJpbmcpIHtcblx0XHRjaGVjayh1c2VySWQsIFN0cmluZylcblxuXHRcdGlmICghTWV0ZW9yLnVzZXJJZCgpIHx8ICFVc2VySGFzUm9sZShbUm9sZXMuQURNSU5dKSkgcmV0dXJuXG5cblx0XHRjb25zdCB1c2VyID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoeyBfaWQ6IHVzZXJJZCB9KSBhcyBOYVNUQVVzZXJcblxuXHRcdGlmICghdXNlcikgcmV0dXJuXG5cblx0XHRpZiAodXNlci5yb2xlcy5pbmNsdWRlcyhyb2xlKSkge1xuXHRcdFx0TWV0ZW9yLnVzZXJzLnVwZGF0ZSh1c2VySWQsIHtcblx0XHRcdFx0JHNldDoge1xuXHRcdFx0XHRcdHJvbGVzOiB1c2VyLnJvbGVzLmZpbHRlcigocikgPT4gciAhPT0gcm9sZSlcblx0XHRcdFx0fVxuXHRcdFx0fSlcblx0XHR9XG5cdH0sXG5cdCdzdGF0aW9uLmFkZCcgKG5hbWU6IHN0cmluZykge1xuXHRcdGNoZWNrKG5hbWUsIFN0cmluZylcblxuXHRcdGlmICghTWV0ZW9yLnVzZXJJZCgpIHx8ICFVc2VySGFzUm9sZShbUm9sZXMuQURNSU5dKSkgcmV0dXJuXG5cblx0XHRjb25zdCBleGlzdHMgPSBTdGF0aW9ucy5maW5kKHsgbmFtZSB9KS5mZXRjaCgpXG5cblx0XHRpZiAoZXhpc3RzLmxlbmd0aCkgcmV0dXJuXG5cblx0XHRTdGF0aW9ucy5pbnNlcnQoe1xuXHRcdFx0bmFtZSxcblx0XHRcdGVsaWdpYmxlRm9yRW50cnk6IHRydWUsXG5cdFx0XHRhdXRob3JpemVkVXNlcnM6IFtdXG5cdFx0fSlcblx0fSxcblx0J3N0YXRpb24uZGVsZXRlJyAoaWQ6IHN0cmluZykge1xuXHRcdGNoZWNrIChpZCwgU3RyaW5nKVxuXG5cdFx0aWYgKCFNZXRlb3IudXNlcklkKCkgfHwgIVVzZXJIYXNSb2xlKFtSb2xlcy5BRE1JTl0pKSByZXR1cm5cblxuXHRcdGNvbnN0IGV4aXN0cyA9IFN0YXRpb25zLmZpbmQoeyBfaWQ6IGlkIH0pLmZldGNoKClcblxuXHRcdGlmICghZXhpc3RzLmxlbmd0aCkgcmV0dXJuXG5cblx0XHRTdGF0aW9ucy5yZW1vdmUoeyBfaWQ6IGlkIH0pXG5cblx0XHRNZXRlb3IudXNlcnMuZmluZCh7IHN0YXRpb25JZDogaWQgfSkuZmV0Y2goKS5mb3JFYWNoKCh1c2VyKSA9PiB7XG5cdFx0XHRNZXRlb3IudXNlcnMucmVtb3ZlKHsgX2lkOiB1c2VyLl9pZCB9KVxuXHRcdH0pXG5cdH0sXG5cdGFzeW5jICdjb21tZW50cy5hZGQnIChzdGF0aW9uSWQ6IHN0cmluZywgY2F0ZWdvcnlJZDogc3RyaW5nLCBqdWRnZWRCeTogc3RyaW5nLCBjb21tZW50czogc3RyaW5nKSB7XG5cdFx0Y2hlY2sgKHN0YXRpb25JZCwgU3RyaW5nKVxuXHRcdGNoZWNrKGNhdGVnb3J5SWQsIFN0cmluZylcblx0XHRjaGVjayhqdWRnZWRCeSwgU3RyaW5nKVxuXHRcdGNoZWNrKGNvbW1lbnRzLCBTdHJpbmcpXG5cblx0XHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdFx0Y29uc3QgZXhpc3RpbmcgPSBTY29yZXMuZmluZE9uZSh7IHN0YXRpb25JZCwgY2F0ZWdvcnlJZCwganVkZ2VkQnkgfSlcblxuXHRcdFx0aWYgKGV4aXN0aW5nKSB7XG5cdFx0XHRcdFNjb3Jlcy51cGRhdGUoeyBfaWQ6IGV4aXN0aW5nLl9pZCB9LCB7XG5cdFx0XHRcdFx0c3RhdGlvbklkLFxuXHRcdFx0XHRcdGNhdGVnb3J5SWQsXG5cdFx0XHRcdFx0anVkZ2VkQnksXG5cdFx0XHRcdFx0Y29tbWVudHMsXG5cdFx0XHRcdFx0ZGF0ZTogRGF0ZS5ub3coKVxuXHRcdFx0XHR9LCB7IH0sIChlcnJvcjogc3RyaW5nKSA9PiB7XG5cdFx0XHRcdFx0aWYgKGVycm9yKSByZWplY3QoZXJyb3IpXG5cdFx0XHRcdFx0cmVzb2x2ZSgpXG5cdFx0XHRcdH0pXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRTY29yZXMuaW5zZXJ0KHtcblx0XHRcdFx0XHRzdGF0aW9uSWQsXG5cdFx0XHRcdFx0Y2F0ZWdvcnlJZCxcblx0XHRcdFx0XHRqdWRnZWRCeSxcblx0XHRcdFx0XHRjb21tZW50cyxcblx0XHRcdFx0XHRkYXRlOiBEYXRlLm5vdygpXG5cdFx0XHRcdH0sIChlcnJvcjogc3RyaW5nKSA9PiB7XG5cdFx0XHRcdFx0aWYgKGVycm9yKSByZWplY3QoZXJyb3IpXG5cdFx0XHRcdFx0cmVzb2x2ZSgpXG5cdFx0XHRcdH0pXG5cdFx0XHR9XG5cdFx0fSlcblx0fSxcblx0YXN5bmMgJ3Jlc3VsdC5zZXQnIChcblx0XHRjYXRlZ29yeUlkOiBzdHJpbmcsIHJlc3VsdDogeyBbc3RhdGlvbklkOiBzdHJpbmddOiBudW1iZXIgfSwgam9pbnRGaXJzdD86IGJvb2xlYW4sIGpvaW50SGlnaGx5Q29tbWVuZGVkPzogYm9vbGVhblxuXHQpIHtcblx0XHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdFx0Y29uc3QgaWQgPSBNZXRlb3IudXNlcklkKClcblxuXHRcdFx0aWYgKCFpZCkgcmV0dXJuIHJlamVjdCgpXG5cblx0XHRcdC8vIFRPRE86IEFkZCBqdWRnZWRCeSBpZiBhbGxvd2luZyB0d28ganVkZ2VzIHBlciBjYXRlZ29yeSB0byBoYXZlIGRpZmZlcmVudCBvcmRlcmluZ3MuXG5cdFx0XHRjb25zdCBleGlzdGluZyA9IFJlc3VsdHMuZmluZE9uZSh7XG5cdFx0XHRcdGNhdGVnb3J5SWRcblx0XHRcdH0pXG5cblx0XHRcdGlmIChleGlzdGluZykge1xuXHRcdFx0XHRSZXN1bHRzLnVwZGF0ZSh7IF9pZDogZXhpc3RpbmcuX2lkIH0sIHtcblx0XHRcdFx0XHRjYXRlZ29yeUlkLFxuXHRcdFx0XHRcdGp1ZGdlZEJ5OiBpZCxcblx0XHRcdFx0XHRqb2ludEZpcnN0LFxuXHRcdFx0XHRcdGpvaW50SGlnaGx5Q29tbWVuZGVkLFxuXHRcdFx0XHRcdG9yZGVyOiByZXN1bHRcblx0XHRcdFx0fSwgeyB9LCAoZXJyOiBzdHJpbmcpID0+IHtcblx0XHRcdFx0XHRpZiAoZXJyKSByZWplY3QoKVxuXHRcdFx0XHRcdHJlc29sdmUoKVxuXHRcdFx0XHR9KVxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0UmVzdWx0cy5pbnNlcnQoe1xuXHRcdFx0XHRcdGNhdGVnb3J5SWQsXG5cdFx0XHRcdFx0anVkZ2VkQnk6IGlkLFxuXHRcdFx0XHRcdGpvaW50Rmlyc3QsXG5cdFx0XHRcdFx0am9pbnRIaWdobHlDb21tZW5kZWQsXG5cdFx0XHRcdFx0b3JkZXI6IHJlc3VsdFxuXHRcdFx0XHR9LCAoZXJyOiBzdHJpbmcpID0+IHtcblx0XHRcdFx0XHRpZiAoZXJyKSByZWplY3QoKVxuXHRcdFx0XHRcdHJlc29sdmUoKVxuXHRcdFx0XHR9KVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0sXG5cdGFzeW5jICdzZXRKdWRnZVRvQ2F0ZWdvcnknIChqdWRnZUlkOiBzdHJpbmcsIGNhdGVnb3J5SWQ6IHN0cmluZyk6IFByb21pc2U8YW55PiB7XG5cdFx0Y2hlY2soanVkZ2VJZCwgU3RyaW5nKVxuXHRcdGNoZWNrKGNhdGVnb3J5SWQsIFN0cmluZylcblxuXHRcdHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0XHRjb25zdCB0b0NhdCA9IEp1ZGdlVG9DYXRlZ29yeS5maW5kT25lKHsganVkZ2VJZCB9KVxuXG5cdFx0XHRpZiAodG9DYXQpIHtcblx0XHRcdFx0SnVkZ2VUb0NhdGVnb3J5LnVwZGF0ZShcblx0XHRcdFx0XHR7IF9pZDogdG9DYXQuX2lkIH0sIHsgY2F0ZWdvcnlJZCwganVkZ2VJZCB9LCB7IH0sXG5cdFx0XHRcdFx0KGVycjogc3RyaW5nKSA9PiB7XG5cdFx0XHRcdFx0XHRpZiAoZXJyKSByZWplY3QoZXJyKVxuXHRcdFx0XHRcdFx0cmVzb2x2ZSgpXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHQpXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRKdWRnZVRvQ2F0ZWdvcnkuaW5zZXJ0KFxuXHRcdFx0XHRcdHsgY2F0ZWdvcnlJZCwganVkZ2VJZCB9LFxuXHRcdFx0XHRcdChlcnI6IHN0cmluZykgPT4ge1xuXHRcdFx0XHRcdFx0aWYgKGVycikgcmVqZWN0KGVycilcblx0XHRcdFx0XHRcdHJlc29sdmUoKVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0KVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0sXG5cdCdlbnRyeTpzZXRWZXJpZmljYXRpb24nIChlbnRyeUlkOiBzdHJpbmcsIHN0YXR1czogVmVyaWZpY2F0aW9uU3RhdHVzKSB7XG5cdFx0Y2hlY2soZW50cnlJZCwgU3RyaW5nKVxuXG5cdFx0RW50cmllcy51cGRhdGUoeyBfaWQ6IGVudHJ5SWQgfSwgeyAkc2V0OiB7IHZlcmlmaWVkOiBzdGF0dXMgfSB9KVxuXHR9LFxuXHRhc3luYyAnZXZpZGVuY2U6c2V0VmVyaWZpZWQnIChldmlkZW5jZUlkOiBzdHJpbmcsIGNoZWNrZWQ6IGJvb2xlYW4pIHtcblx0XHRjaGVjayAoZXZpZGVuY2VJZCwgU3RyaW5nKVxuXHRcdGNoZWNrIChjaGVja2VkLCBCb29sZWFuKVxuXG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlICgocmVzb2x2ZSwgX3JlamVjdCkgPT4ge1xuXHRcdFx0RXZpZGVuY2VDb2xsZWN0aW9uLnVwZGF0ZSh7IF9pZDogZXZpZGVuY2VJZCB9LCB7ICRzZXQ6IHsgdmVyaWZpZWQ6IGNoZWNrZWQgfSB9LCB7IH0sICgpID0+IHtcblx0XHRcdFx0cmVzb2x2ZSgpXG5cdFx0XHR9KVxuXHRcdH0pXG5cdH1cbn0pXG4iLCJpbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gJ21ldGVvci9hY2NvdW50cy1iYXNlJ1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXG5pbXBvcnQgeyBSYW5kb20gfSBmcm9tICdtZXRlb3IvcmFuZG9tJ1xuaW1wb3J0IHsgUm9sZXMgfSBmcm9tICcuL2hlbHBlcnMvZW51bXMnXG5pbXBvcnQgeyBTdGF0aW9uLCBTdGF0aW9ucyB9IGZyb20gJy4vc3RhdGlvbnMnXG5cbmV4cG9ydCBpbnRlcmZhY2UgTmFTVEFVc2VyIGV4dGVuZHMgTWV0ZW9yLlVzZXIge1xuXHRyb2xlczogUm9sZXNbXSxcblx0c3RhdGlvbklkPzogc3RyaW5nXG59XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcblx0QWNjb3VudHMub25DcmVhdGVVc2VyKChvcHRpb25zLCB1c2VyKSA9PiB7XG5cdFx0Y29uc3QgbmFzdGFVc2VyOiBOYVNUQVVzZXIgPSB7XG5cdFx0XHQuLi51c2VyLFxuXHRcdFx0cm9sZXM6IFsgUm9sZXMuU1RBVElPTiBdIC8vIFRPRE86IFJlcGxhY2Vcblx0XHR9XG5cblx0XHRpZiAob3B0aW9ucy5wcm9maWxlKSB7XG5cdFx0XHRuYXN0YVVzZXIucHJvZmlsZSA9IG9wdGlvbnMucHJvZmlsZVxuXHRcdH1cblxuXHRcdHJldHVybiBuYXN0YVVzZXJcblx0fSlcblxuXHRBY2NvdW50cy5lbWFpbFRlbXBsYXRlcy5zaXRlTmFtZSA9ICdOYVNUQSBTdWJtaXNzaW9ucyBQb3J0YWwnXG5cdEFjY291bnRzLmVtYWlsVGVtcGxhdGVzLmZyb20gPSAnTmFTVEEgRW50cmllcyA8ZW50cmllc0BuYXN0YS50dj4nXG5cdEFjY291bnRzLmVtYWlsVGVtcGxhdGVzLmVucm9sbEFjY291bnQuc3ViamVjdCA9ICgpID0+IHtcblx0XHRyZXR1cm4gYFlvdSBoYXZlIGJlZW4gaW52aXRlZCB0byB0aGUgTmFTVEEgc3VibWlzc2lvbnMgcG9ydGFsYFxuXHR9XG5cdEFjY291bnRzLmVtYWlsVGVtcGxhdGVzLmVucm9sbEFjY291bnQudGV4dCA9IChfdXNlciwgdXJsKSA9PiB7XG5cdFx0cmV0dXJuIGBZb3UgaGF2ZSBiZWVuIGludml0ZWQgdG8gdGhlIE5hU1RBIHN1Ym1pc3Npb25zIHBvcnRhbCwgY2xpY2sgdGhlIGxpbmsgYmVsb3cgdG8gYWN0aXZhdGUgeW91ciBhY2NvdW50XFxuYFxuXHRcdCsgYCR7dXJsfVxcbmBcblx0XHQrIGBBbnkgaXNzdWVzLCBwbGVhc2UgY29udGFjdCB0ZWNoQG5hc3RhLnR2LiBSZXBsaWVzIHRvIHRoaXMgZW1haWwgd2lsbCBub3QgYmUgZGVsaXZlcmVkLmBcblx0fVxuXHRBY2NvdW50cy51cmxzLmVucm9sbEFjY291bnQgPSAodG9rZW4pID0+IHtcblx0XHRyZXR1cm4gTWV0ZW9yLmFic29sdXRlVXJsKGBlbnJvbGwtYWNjb3VudC8ke3Rva2VufWApXG5cdH1cblxuXHRNZXRlb3IucHVibGlzaCgndXNlcnMnLCAoKSA9PiB7XG5cdFx0cmV0dXJuIE1ldGVvci51c2Vycy5maW5kKHsgfSwgeyBmaWVsZHM6IHsgc3RhdGlvbklkOiAxLCBlbWFpbHM6IDEsIHJvbGVzOiAxIH0gfSlcblx0fSlcblxuXHRNZXRlb3IucHVibGlzaCgnZW5yb2xsZWRVc2VyJywgKHRva2VuKSA9PiB7XG5cdFx0cmV0dXJuIE1ldGVvci51c2Vycy5maW5kKHsgJ3NlcnZpY2VzLnBhc3N3b3JkLnJlc2V0LnRva2VuJzogdG9rZW4gfSlcblx0fSlcbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuXHQnYWNjb3VudHMuY3JlYXRlJyAoZW1haWw6IHN0cmluZywgcGFzc3dvcmQ6IHN0cmluZykge1xuXHRcdGNoZWNrKGVtYWlsLCBTdHJpbmcpXG5cdFx0Y2hlY2socGFzc3dvcmQsIFN0cmluZylcblxuXHRcdEFjY291bnRzLmNyZWF0ZVVzZXIoeyBlbWFpbCwgcGFzc3dvcmR9KVxuXHR9LFxuXHQnYWNjb3VudHMuZGVsZXRlJyAodXNlcklkOiBzdHJpbmcpIHtcblx0XHRjaGVjayAodXNlcklkLCBTdHJpbmcpXG5cblx0XHRNZXRlb3IudXNlcnMucmVtb3ZlKHsgX2lkOiB1c2VySWQgfSlcblx0fSxcblx0YXN5bmMgJ2FjY291bnRzLm5ldy53aXRoU3RhdGlvbicgKGVtYWlsOiBzdHJpbmcsIHN0YXRpb25JZDogc3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcblx0XHRjb25zdCBpZCA9IGF3YWl0IGNyZWF0ZUFjY291bnQoZW1haWwpXG5cblx0XHRjb25zdCBzdGF0aW9uZGIgPSBTdGF0aW9ucy5maW5kT25lKHsgX2lkOiBzdGF0aW9uSWQgfSlcblxuXHRcdGlmICghc3RhdGlvbmRiIHx8ICFzdGF0aW9uZGIuX2lkKSB7XG5cdFx0XHRyZXR1cm4gUHJvbWlzZS5yZWplY3QoYEZhaWxlZCB0byBmaW5kIHN0YXRpb246ICR7c3RhdGlvbklkfWApXG5cdFx0fVxuXG5cdFx0YXdhaXQgYWRkU3RhdGlvbklkVG9Vc2VyKGlkLCBzdGF0aW9uZGIuX2lkKVxuXG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdFN0YXRpb25zLnVwZGF0ZShcblx0XHRcdFx0eyBfaWQ6IChzdGF0aW9uZGIgYXMgU3RhdGlvbikuX2lkIH0sXG5cdFx0XHRcdHsgJHB1c2g6IHsgYXV0aG9yaXplZFVzZXJzOiBpZCB9IH0sXG5cdFx0XHRcdHsgfSxcblx0XHRcdFx0KChlcnI6IHN0cmluZykgPT4ge1xuXHRcdFx0XHRcdGlmIChlcnIpIHJlamVjdCgpXG5cdFx0XHRcdFx0cmVzb2x2ZSgpXG5cdFx0XHRcdH0pXG5cdFx0XHQpXG5cdFx0fSlcblx0fSxcblx0YXN5bmMgJ2FjY291bnRzLm5ldycgKGVtYWlsOiBzdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuXHRcdGNoZWNrKGVtYWlsLCBTdHJpbmcpXG5cblx0XHRjb25zdCBpZCA9IGF3YWl0IGNyZWF0ZUFjY291bnQoZW1haWwpXG5cblx0XHRpZiAoIWlkKSByZXR1cm4gUHJvbWlzZS5yZWplY3QoJ0ZhaWxlZCB0byBjcmVhdGUgdXNlcicpXG5cblx0XHRBY2NvdW50cy5zZW5kRW5yb2xsbWVudEVtYWlsKGlkLCBlbWFpbClcblxuXHRcdHJldHVybiBQcm9taXNlLnJlc29sdmUoaWQpXG5cdH0sXG5cdCdhY2NvdW50cy5sb2dpbicgKGVtYWlsOiBzdHJpbmcsIHBhc3N3b3JkOiBzdHJpbmcpIHtcblx0XHRjaGVjayhlbWFpbCwgU3RyaW5nKVxuXHRcdGNoZWNrKHBhc3N3b3JkLCBTdHJpbmcpXG5cblx0XHRNZXRlb3IubG9naW5XaXRoUGFzc3dvcmQoZW1haWwsIHBhc3N3b3JkKVxuXHR9LFxuXHQnYWNjb3VudHMuc2V0UGFzc3dvcmQnICh1c2VySWQ6IHN0cmluZywgcGFzc3dvcmQ6IHN0cmluZykge1xuXHRcdGNoZWNrICh1c2VySWQsIFN0cmluZylcblx0XHRjaGVjayAocGFzc3dvcmQsIFN0cmluZylcblxuXHRcdGlmICghdGhpcy5pc1NpbXVsYXRpb24pIHtcblx0XHRcdEFjY291bnRzLnNldFBhc3N3b3JkKHVzZXJJZCwgcGFzc3dvcmQpXG5cdFx0fVxuXHR9XG59KVxuXG5leHBvcnQgZnVuY3Rpb24gR2V0VXNlckZyb21JZCAoKTogTmFTVEFVc2VyIHwgdW5kZWZpbmVkIHtcblx0Y29uc3QgaWQgPSBNZXRlb3IudXNlcklkKClcblx0aWYgKGlkKSB7XG5cdFx0Y29uc3QgdXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lKHsgX2lkOiBpZCB9KVxuXHRcdGlmICh1c2VyKSB7XG5cdFx0XHRyZXR1cm4gdXNlciBhcyBOYVNUQVVzZXJcblx0XHR9XG5cdH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFVzZXJIYXNSb2xlIChyb2xlczogUm9sZXNbXSkge1xuXHRjb25zdCB1c2VyID0gR2V0VXNlckZyb21JZCgpXG5cdGlmICh1c2VyKSB7XG5cdFx0cmV0dXJuIHJvbGVzLnNvbWUoKHJvbGUpID0+IHtcblx0XHRcdGlmICh1c2VyLnJvbGVzLmluY2x1ZGVzKHJvbGUpKSB7XG5cdFx0XHRcdHJldHVybiB0cnVlXG5cdFx0XHR9XG5cdFx0fSlcblx0fVxufVxuXG5mdW5jdGlvbiBjcmVhdGVBY2NvdW50IChlbWFpbDogc3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcblx0aWYgKE1ldGVvci51c2Vycy5maW5kKHsgZW1haWxzOiB7ICRlbGVtTWF0Y2g6IHsgYWRkcmVzczogZW1haWwgfSB9IH0gKS5jb3VudCgpKSB7XG5cdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcignRW1haWwgYWxyZWFkeSByZWdpc3RlcmVkJylcblx0fVxuXG5cdHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0Y29uc3QgaWQgPSBBY2NvdW50cy5jcmVhdGVVc2VyKHsgZW1haWwsIHBhc3N3b3JkOiBSYW5kb20uaGV4U3RyaW5nKDEyKSB9KVxuXHRcdGlmIChpZCkge1xuXHRcdFx0cmVzb2x2ZShpZClcblx0XHR9IGVsc2Uge1xuXHRcdFx0cmVqZWN0KClcblx0XHR9XG5cdH0pXG59XG5cbmZ1bmN0aW9uIGFkZFN0YXRpb25JZFRvVXNlciAodXNlcklkOiBzdHJpbmcsIHN0YXRpb25JZDogc3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcblx0cmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHQoTWV0ZW9yLnVzZXJzIGFzIE1vbmdvLkNvbGxlY3Rpb248TmFTVEFVc2VyPikudXBkYXRlKFxuXHRcdFx0eyBfaWQ6IHVzZXJJZCB9LCB7ICRzZXQ6IHsgc3RhdGlvbklkIH0gfSxcblx0XHRcdHsgfSxcblx0XHRcdCgoZXJyOiBzdHJpbmcpID0+IHtcblx0XHRcdFx0aWYgKGVycikgcmVqZWN0KGVycilcblx0XHRcdFx0cmVzb2x2ZSgpXG5cdFx0XHR9KVxuXHRcdClcblx0fSlcbn1cbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbydcbmltcG9ydCB7IENvbGxlY3Rpb25zLCBERUZBVUxUX0FXQVJEU19OQU1FUywgREVGQVVMVF9DQVRFR09SWV9OQU1FUyB9IGZyb20gJy4vaGVscGVycy9lbnVtcydcblxuZXhwb3J0IGludGVyZmFjZSBBd2FyZCB7XG5cdF9pZD86IHN0cmluZ1xuXHQvKiogTmFtZSBvZiBhd2FyZHMgY2VyZW1vbnkuICovXG5cdG5hbWU6IHN0cmluZyxcblx0LyoqIElEcyBvZiBjYXRlZ29yaWVzIGJlbG9uZ2luZyB0byB0aGlzIGF3YXJkcyBjZXJlbW9ueS4gKi9cblx0Y2F0ZWdvcmllczogc3RyaW5nW10sXG5cdHN1Ym1pc3Npb25zT3Blbj86IG51bWJlcixcblx0c3VibWlzc2lvbnNDbG9zZT86IG51bWJlcixcblx0YWN0aXZlOiBib29sZWFuXG59XG5cbmV4cG9ydCBjb25zdCBBd2FyZHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbjxBd2FyZD4oQ29sbGVjdGlvbnMuQVdBUkRTKVxuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cdE1ldGVvci5wdWJsaXNoKENvbGxlY3Rpb25zLkFXQVJEUywgZnVuY3Rpb24gYXdhcmRzUHVibGljdGFpb24gKCkge1xuXHRcdGlmIChNZXRlb3IudXNlcklkKCkpIHtcblx0XHRcdHJldHVybiBBd2FyZHMuZmluZCgpXG5cdFx0fVxuXHR9KVxufVxuXG5leHBvcnQgY29uc3QgREVGQVVMVF9BV0FSRFM6IEF3YXJkW10gPSBbXG5cdHtcblx0XHRuYW1lOiBERUZBVUxUX0FXQVJEU19OQU1FUy5OQVNUQSxcblx0XHRjYXRlZ29yaWVzOiBbXSxcblx0XHRhY3RpdmU6IHRydWVcblx0fSxcblx0e1xuXHRcdG5hbWU6IERFRkFVTFRfQVdBUkRTX05BTUVTLlBFT1BMRVNfQ0hPSUNFLFxuXHRcdGNhdGVnb3JpZXM6IFtdLFxuXHRcdGFjdGl2ZTogZmFsc2Vcblx0fVxuXVxuXG5leHBvcnQgY29uc3QgREVGQVVMVF9DQVRFR09SSUVTX0ZPUl9BV0FSRFM6IHsgW2F3YXJkczogc3RyaW5nXTogc3RyaW5nW10gfSA9IHtcblx0W0RFRkFVTFRfQVdBUkRTX05BTUVTLk5BU1RBXTogW1xuXHRcdERFRkFVTFRfQ0FURUdPUllfTkFNRVMuTmFTVEFfQVdBUkRTX0JFU1RfQlJPQURDQVNURVIsXG5cdFx0REVGQVVMVF9DQVRFR09SWV9OQU1FUy5OYVNUQV9BV0FSRFNfSklTQyxcblx0XHRERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19CRVNUX0RSQU1BVElDX1BFUkZPUk1BTkNFLFxuXHRcdERFRkFVTFRfQ0FURUdPUllfTkFNRVMuTmFTVEFfQVdBUkRTX0JFU1RfT05fU0NSRUVOX1RBTEVOVCxcblx0XHRERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19TVEFUSU9OX01BUktFVElORyxcblx0XHRERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19URUNITklDQUxfQUNISUVWRU1FTlQsXG5cdFx0REVGQVVMVF9DQVRFR09SWV9OQU1FUy5OYVNUQV9BV0FSRFNfRlJFU0hFUlNfQ09WRVJBR0UsXG5cdFx0REVGQVVMVF9DQVRFR09SWV9OQU1FUy5OYVNUQV9BV0FSRFNfQU5JTUFUSU9OLFxuXHRcdERFRkFVTFRfQ0FURUdPUllfTkFNRVMuTmFTVEFfQVdBUkRTX05FV1NfQU5EX0NVUlJFTlRfQUZGQUlSUyxcblx0XHRERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19NQVJTX0VMS0lOU19FTF9CUk9HWSxcblx0XHRERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19XUklUSU5HLFxuXHRcdERFRkFVTFRfQ0FURUdPUllfTkFNRVMuTmFTVEFfQVdBUkRTX0xJVkVfQlJPQURDQVNULFxuXHRcdERFRkFVTFRfQ0FURUdPUllfTkFNRVMuTmFTVEFfQVdBUkRTX0NJTkVNQVRPR1JBUEhZLFxuXHRcdERFRkFVTFRfQ0FURUdPUllfTkFNRVMuTmFTVEFfQVdBUkRTX0xJR0hUX0VOVEVSVEFJTk1FTlQsXG5cdFx0REVGQVVMVF9DQVRFR09SWV9OQU1FUy5OYVNUQV9BV0FSRFNfVElUTEVfU0VRVUVOQ0UsXG5cdFx0REVGQVVMVF9DQVRFR09SWV9OQU1FUy5OYVNUQV9BV0FSRFNfQ09NRURZLFxuXHRcdERFRkFVTFRfQ0FURUdPUllfTkFNRVMuTmFTVEFfQVdBUkRTX0RSQU1BLFxuXHRcdERFRkFVTFRfQ0FURUdPUllfTkFNRVMuTkFTVEFfQVdBUkRTX0RPQ1VNRU5UQVJZX0FORF9GQUNUVUFMLFxuXHRcdERFRkFVTFRfQ0FURUdPUllfTkFNRVMuTmFTVEFfQVdBUkRTX1NQT1JULFxuXHRcdERFRkFVTFRfQ0FURUdPUllfTkFNRVMuTmFTVEFfQVdBUkRTX1BPU1RfUFJPRFVDVElPTl9BV0FSRCxcblx0XHRERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19TVVBFUl9CTE9PUEVSXG5cdF0sXG5cdFtERUZBVUxUX0FXQVJEU19OQU1FUy5QRU9QTEVTX0NIT0lDRV06IFtcblx0XHRERUZBVUxUX0NBVEVHT1JZX05BTUVTLlBDQXNfT1BFTixcblx0XHRERUZBVUxUX0NBVEVHT1JZX05BTUVTLlBDQXNfTElWRV9CUk9BRENBU1QsXG5cdFx0REVGQVVMVF9DQVRFR09SWV9OQU1FUy5QQ0FzX0NPTlRFTlRfSU5OT1ZBVElPTixcblx0XHRERUZBVUxUX0NBVEVHT1JZX05BTUVTLlBDQXNfVEVDSE5JQ0FMX0lOTk9WQVRJT04sXG5cdFx0REVGQVVMVF9DQVRFR09SWV9OQU1FUy5QQ0FzX1ZJU1VBTF9DUkVBVElWSVRZX0FORF9RVUFMSVRZLFxuXHRcdERFRkFVTFRfQ0FURUdPUllfTkFNRVMuUENBc19CRVNUX09OX1NDUkVFTl9UQUxFTlQsXG5cdFx0REVGQVVMVF9DQVRFR09SWV9OQU1FUy5QQ0FzX1VOX1NVTkdfSEVSTyxcblx0XHRERUZBVUxUX0NBVEVHT1JZX05BTUVTLlBDQXNfU1RBVElPTl9PRl9USEVfWUVBUlxuXHRdXG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXG5pbXBvcnQgeyBSYW5kb20gfSBmcm9tICdtZXRlb3IvcmFuZG9tJ1xuaW1wb3J0IHsgTUlOVVRFIH0gZnJvbSAnLi9oZWxwZXJzL2NvbnN0YW50cydcbmltcG9ydCB7IENvbGxlY3Rpb25zLCBERUZBVUxUX0FXQVJEU19OQU1FUywgREVGQVVMVF9DQVRFR09SWV9OQU1FUywgU3VwcG9ydGluZ0V2aWRlbmNlVHlwZSB9IGZyb20gJy4vaGVscGVycy9lbnVtcydcbmltcG9ydCB7IFN1cHBvcnRpbmdFdmlkZW5jZSB9IGZyb20gJy4vc3VwcG9ydGluZy1ldmlkZW5jZSdcblxuZXhwb3J0IGludGVyZmFjZSBDYXRlZ29yeSB7XG5cdF9pZD86IHN0cmluZ1xuXHRuYW1lOiBzdHJpbmdcblx0c3VwcG9ydGluZ0V2aWRlbmNlOiBTdXBwb3J0aW5nRXZpZGVuY2VbXVxuXHRkZXNjcmlwdGlvbjogc3RyaW5nXG5cdGZvckF3YXJkczogc3RyaW5nXG59XG5cbmV4cG9ydCBjb25zdCBDYXRlZ29yaWVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb248Q2F0ZWdvcnk+KENvbGxlY3Rpb25zLkNBVEVHT1JJRVMpXG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcblx0TWV0ZW9yLnB1Ymxpc2goQ29sbGVjdGlvbnMuQ0FURUdPUklFUywgZnVuY3Rpb24gY2F0ZWdvcmllc1B1YmxpY2F0aW9uICgpIHtcblx0XHRpZiAoTWV0ZW9yLnVzZXJJZCgpKSB7XG5cdFx0XHRyZXR1cm4gQ2F0ZWdvcmllcy5maW5kKClcblx0XHR9XG5cdH0pXG59XG5cbmV4cG9ydCBjb25zdCBERUZBVUxUX0NBVEVHT1JJRVM6IENhdGVnb3J5W10gPSBbXG5cdHtcblx0XHRuYW1lOiBERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19CRVNUX0JST0FEQ0FTVEVSLFxuXHRcdHN1cHBvcnRpbmdFdmlkZW5jZTogW1xuXHRcdFx0e1xuXHRcdFx0XHRfaWQ6IFJhbmRvbS5pZCgpLFxuXHRcdFx0XHR0eXBlOiBTdXBwb3J0aW5nRXZpZGVuY2VUeXBlLlZJREVPLFxuXHRcdFx0XHRtYXhMZW5ndGg6IDEwICogTUlOVVRFXG5cdFx0XHR9LFxuXHRcdFx0e1xuXHRcdFx0XHRfaWQ6IFJhbmRvbS5pZCgpLFxuXHRcdFx0XHR0eXBlOiBTdXBwb3J0aW5nRXZpZGVuY2VUeXBlLlBERixcblx0XHRcdFx0bWF4TGVuZ3RoOiAnNTAwIFdvcmRzJ1xuXHRcdFx0fVxuXHRcdF0sXG5cdFx0ZGVzY3JpcHRpb246ICdBIHNob3dyZWVsIGRlbW9uc3RyYXRpbmcgdGhlIHJhbmdlLCBxdWFsaXR5IGFuZCBza2lsbHMgb2YgdGhlIHN0YXRpb24gYW5kIGl0cyBwcm9ncmFtbWluZywgdG8gYmUgYWNjb21wYW5pZWQgYnkgYSB3cml0dGVuIHJlcG9ydCwgd2l0aCBkZXRhaWxzIG9mIHRoZSBvcGVyYXRpb24gb2YgdGhlIHN0YXRpb24gYW5kIGNvbnRyaWJ1dGlvbnMgbWFkZSB3aGljaCBtYXkgbm90IG5lY2Vzc2FyaWx5IGFwcGVhciBvbiBzY3JlZW4uJyxcblx0XHRmb3JBd2FyZHM6IERFRkFVTFRfQVdBUkRTX05BTUVTLk5BU1RBXG5cdH0sXG5cdHtcblx0XHRuYW1lOiBERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19KSVNDLFxuXHRcdHN1cHBvcnRpbmdFdmlkZW5jZTogW1xuXHRcdFx0e1xuXHRcdFx0XHRfaWQ6IFJhbmRvbS5pZCgpLFxuXHRcdFx0XHR0eXBlOiBTdXBwb3J0aW5nRXZpZGVuY2VUeXBlLlRFWFQsXG5cdFx0XHRcdG1heExlbmd0aDogNzUwLFxuXHRcdFx0XHRkZXNjcmlwdGlvbjogJydcblx0XHRcdH0sXG5cdFx0XHR7XG5cdFx0XHRcdF9pZDogUmFuZG9tLmlkKCksXG5cdFx0XHRcdHR5cGU6IFN1cHBvcnRpbmdFdmlkZW5jZVR5cGUuQ0FMTCxcblx0XHRcdFx0ZGVzY3JpcHRpb246ICdTa3lwZSBjYWxsIGJldHdlZW4gcmVwcmVzZW50YXRpdmVzIGZyb20gSmlzYyBhbmQgdGhlIGVudGVyaW5nIHN0YXRpb24uJ1xuXHRcdFx0fVxuXHRcdF0sXG5cdFx0ZGVzY3JpcHRpb246ICdUaGlzIGNhdGVnb3J5IGxvb2tzIGZvciBhIHN0YXRpb24gd29ydGh5IG9mIHNwZWNpYWwgcmVjb2duaXRpb24gZm9yIG91dHN0YW5kaW5nIGFjaGlldmVtZW50LCBlc3BlY2lhbGx5IHdpdGggcmVzcGVjdCB0byB0aGUgc3RhdGlvbuKAmXMgY29tbWl0bWVudCB0byBvdmVyY29taW5nIGNoYWxsZW5naW5nIGNpcmN1bXN0YW5jZXMgYW5kIGFjaGlldmVtZW50IHRocm91Z2ggaW5ub3ZhdGlvbiBpbiB0aGUgcGFzdCB5ZWFyLicsXG5cdFx0Zm9yQXdhcmRzOiBERUZBVUxUX0FXQVJEU19OQU1FUy5OQVNUQVxuXHR9LFxuXHR7XG5cdFx0bmFtZTogREVGQVVMVF9DQVRFR09SWV9OQU1FUy5OYVNUQV9BV0FSRFNfQkVTVF9EUkFNQVRJQ19QRVJGT1JNQU5DRSxcblx0XHRzdXBwb3J0aW5nRXZpZGVuY2U6IFtcblx0XHRcdHtcblx0XHRcdFx0X2lkOiBSYW5kb20uaWQoKSxcblx0XHRcdFx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5WSURFTyxcblx0XHRcdFx0bWF4TGVuZ3RoOiA1ICogTUlOVVRFXG5cdFx0XHR9XG5cdFx0XSxcblx0XHRkZXNjcmlwdGlvbjogJ0Egc2hvd3JlZWwgZGVtb25zdHJhdGluZyB0aGUgb24tc2NyZWVuIGFjdGluZyBza2lsbHMsIHN0eWxlcyBhbmQgdGVjaG5pcXVlcyBvZiBhIHBhcnRpY3VsYXIgSW5kaXZpZHVhbCBpbiBhbnkgZm9ybSBvZiBmaWN0aW9uYWwgcHJvZHVjdGlvbi4gVGhpcyBzaG93cmVlbCBtYXkgYmUgbWFkZSB1cCBvZiBjb250ZW50IGZyb20gbXVsdGlwbGUgcHJvZHVjdGlvbnMgb3IgZXBpc29kZXMuJyxcblx0XHRmb3JBd2FyZHM6IERFRkFVTFRfQVdBUkRTX05BTUVTLk5BU1RBXG5cdH0sXG5cdHtcblx0XHRuYW1lOiBERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19CRVNUX09OX1NDUkVFTl9UQUxFTlQsXG5cdFx0c3VwcG9ydGluZ0V2aWRlbmNlOiBbXG5cdFx0XHR7XG5cdFx0XHRcdF9pZDogUmFuZG9tLmlkKCksXG5cdFx0XHRcdHR5cGU6IFN1cHBvcnRpbmdFdmlkZW5jZVR5cGUuVklERU8sXG5cdFx0XHRcdG1heExlbmd0aDogNSAqIE1JTlVURVxuXHRcdFx0fVxuXHRcdF0sXG5cdFx0ZGVzY3JpcHRpb246ICdBIHNob3dyZWVsIGRlbW9uc3RyYXRpbmcgdGhlIG9uLXNjcmVlbiBza2lsbHMsIHN0eWxlcyBhbmQgdGVjaG5pcXVlcyBvZiBhcGFydGljdWxhciBpbmRpdmlkdWFsIGluIGFueSBwcm9kdWN0aW9uIGV4Y2x1ZGluZyBmaWN0aW9uYWwgY29udGVudC4gVGhpcyBzaG93cmVlbCBtYXkgYmUgbWFkZSB1cCBvZiBjb250ZW50IGZyb20gbXVsdGlwbGUgcHJvZHVjdGlvbnMuJyxcblx0XHRmb3JBd2FyZHM6IERFRkFVTFRfQVdBUkRTX05BTUVTLk5BU1RBXG5cdH0sXG5cdHtcblx0XHRuYW1lOiBERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19TVEFUSU9OX01BUktFVElORyxcblx0XHRzdXBwb3J0aW5nRXZpZGVuY2U6IFtcblx0XHRcdHtcblx0XHRcdFx0X2lkOiBSYW5kb20uaWQoKSxcblx0XHRcdFx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5WSURFTyxcblx0XHRcdFx0bWF4TGVuZ3RoOiAxMCAqIE1JTlVURSxcblx0XHRcdFx0ZGVzY3JpcHRpb246ICdBIHZpZGVvIHN1Ym1pc3Npb24gZGVtb25zdHJhdGluZyB0aGUgYWNoaWV2ZW1lbnRzIG9mIHlvdXIgc3RhdGlvbuKAmXMgbWFya2V0aW5nIHJlY29nbmlzaW5nIGhvdyB5b3VyIHN0YXRpb24gcmVjcnVpdGVkIG1lbWJlcnMgYW5kIGJ1aWx0IGF1ZGllbmNlcyBhY3Jvc3MgeW91ciBjYW1wdXMgYW5kIG9ubGluZSwgaW5jb3Jwb3JhdGluZyBzcGVjaWFsIGV2ZW50cywgYWR2ZXJ0aXNpbmcsIHNvY2lhbCBtZWRpYSBhbmQgb24tYWlyIGJyYW5kaW5nIGFuZCBpZGVudHMuJ1xuXHRcdFx0fSxcblx0XHRcdHtcblx0XHRcdFx0X2lkOiBSYW5kb20uaWQoKSxcblx0XHRcdFx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5URVhULFxuXHRcdFx0XHRtYXhMZW5ndGg6IDUwMCxcblx0XHRcdFx0ZGVzY3JpcHRpb246ICdUaGUgc3VibWlzc2lvbiBtdXN0IGJlIGFjY29tcGFuaWVkIGJ5IGEgd3JpdHRlbiBkb2N1bWVudCBkZXRhaWxpbmcgbWFya2V0aW5nIHN0cmF0ZWdpZXMsIHRvb2xzLCBhbmQgdGVjaG5pcXVlcyB1c2VkIGJ5IHlvdXIgc3RhdGlvbi4nXG5cdFx0XHR9XG5cdFx0XSxcblx0XHRkZXNjcmlwdGlvbjogJ1JlY3J1aXRpbmcgYW5kIHJldGFpbmluZyBtZW1iZXJzLCBhbmQgYnVpbGRpbmcgYW4gYXVkaWVuY2UgYXJlIHR3byBvZiB0aGUgYmlnZ2VzdCBjaGFsbGVuZ2VzIGZhY2VkIGJ5IHN0dWRlbnQgVFYgc3RhdGlvbnMuIFRoaXMgYXdhcmQgcmVjb2duaXNlcyB0aGUgZWZmb3J0cyB0aGF0IHN0YXRpb25zIGdvIHRvIHRvIGVuc3VyZSB0aGF0IHRoZXkgaGF2ZSBhbiBhY3RpdmUgbWVtYmVyc2hpcCBhbmQgdGhhdCB0aGVpciBjb250ZW50IGlzIHdhdGNoZWQgYW5kIHZhbHVlZCBieSB0aGVpciB1bml2ZXJzaXR5LCBsb2NhbCBhbmQgbmF0aW9uYWwgdmlld2Vycy4nLFxuXHRcdGZvckF3YXJkczogREVGQVVMVF9BV0FSRFNfTkFNRVMuTkFTVEFcblx0fSxcblx0e1xuXHRcdG5hbWU6IERFRkFVTFRfQ0FURUdPUllfTkFNRVMuTmFTVEFfQVdBUkRTX1RFQ0hOSUNBTF9BQ0hJRVZFTUVOVCxcblx0XHRzdXBwb3J0aW5nRXZpZGVuY2U6IFtcblx0XHRcdHtcblx0XHRcdFx0X2lkOiBSYW5kb20uaWQoKSxcblx0XHRcdFx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5QREYsXG5cdFx0XHRcdG1heExlbmd0aDogJzUwMCBXb3Jkcydcblx0XHRcdH1cblx0XHRdLFxuXHRcdGRlc2NyaXB0aW9uOiAnQSByZXBvcnQgd2hpY2ggZ2l2ZXMgYW4gYWNjb3VudCBvZiBhbnkgdGVjaG5pY2FsIGFjaGlldmVtZW50KHMpIGFuZC9vciBkZXZlbG9wZWQgdG8gc3VwcG9ydCB5b3VyIHN0YXRpb27igJlzIG91dHB1dC4gRW50cmllcyB3aWxsIGRlbW9uc3RyYXRlIGJvdGggdGhlIHRlY2huaWNhbCBjaGFsbGVuZ2VzIGZhY2VkIGFuZCBvdmVyY29tZSwgYW5kIHRoZSBiZW5lZml0cyB0aGlzIGJyb3VnaHQgdG8gdGhlIHByb2R1Y3Rpb24ocykuJyxcblx0XHRmb3JBd2FyZHM6IERFRkFVTFRfQVdBUkRTX05BTUVTLk5BU1RBXG5cdH0sXG5cdHtcblx0XHRuYW1lOiBERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19GUkVTSEVSU19DT1ZFUkFHRSxcblx0XHRzdXBwb3J0aW5nRXZpZGVuY2U6IFtcblx0XHRcdHtcblx0XHRcdFx0X2lkOiBSYW5kb20uaWQoKSxcblx0XHRcdFx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5WSURFTyxcblx0XHRcdFx0bWF4TGVuZ3RoOiAxMCAqIE1JTlVURVxuXHRcdFx0fVxuXHRcdF0sXG5cdFx0ZGVzY3JpcHRpb246ICdUaGlzIGNhdGVnb3J5IHJlY29nbmlzZXMgdGhlIHF1YWxpdHkgYW5kIGRpdmVyc2l0eSBvZiBhIHN0YXRpb25cXCdzIGNvdmVyaW5nIG9mIHRoZWlyIGNhbXB1c1xcJyBGcmVzaGVyc1xcJyB3ZWVrKHMpIGFjdGl2aXRpZXMuIFRoaXMgY2F0ZWdvcnkgYWxzbyBpbmNsdWRlcyBhbGwgaW5jbHVkaW5nIGFsbCBmcmVzaGVyc1xcJyB0aGVtZWQgY29udGVudC4nLFxuXHRcdGZvckF3YXJkczogREVGQVVMVF9BV0FSRFNfTkFNRVMuTkFTVEFcblx0fSxcblx0e1xuXHRcdG5hbWU6IERFRkFVTFRfQ0FURUdPUllfTkFNRVMuTmFTVEFfQVdBUkRTX0FOSU1BVElPTixcblx0XHRzdXBwb3J0aW5nRXZpZGVuY2U6IFtcblx0XHRcdHtcblx0XHRcdFx0X2lkOiBSYW5kb20uaWQoKSxcblx0XHRcdFx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5WSURFTyxcblx0XHRcdFx0bWF4TGVuZ3RoOiAxMCAqIE1JTlVURVxuXHRcdFx0fVxuXHRcdF0sXG5cdFx0ZGVzY3JpcHRpb246ICdBIHNpbmdsZSBhbmltYXRpb24gcHJvZ3JhbW1lIChvciBhIHNob3J0ZW5lZCBlZGl0IGZyb20gYW4gZXBpc29kZSBvciBzZXJpZXMpLCBvciBhbiBvcmlnaW5hbCBwaWVjZSBvZiBhbmltYXRpb24gb2YgYW55IHR5cGUsIHdoaWNoIGhhcyBiZWVuIHByb2R1Y2VkIGJ5IHRoZSBzdGF0aW9uLiBUaGlzIGNhbiBpbmNsdWRlIGJ1dCBpcyBub3QgbGltaXRlZCB0bzogQ2FydG9vbnMsIENvbXB1dGVyIGdlbmVyYXRlZCBpbWFnZXMsIFRpdGxlIHNlcXVlbmNlcy4nLFxuXHRcdGZvckF3YXJkczogREVGQVVMVF9BV0FSRFNfTkFNRVMuTkFTVEFcblx0fSxcblx0e1xuXHRcdG5hbWU6IERFRkFVTFRfQ0FURUdPUllfTkFNRVMuTmFTVEFfQVdBUkRTX05FV1NfQU5EX0NVUlJFTlRfQUZGQUlSUyxcblx0XHRzdXBwb3J0aW5nRXZpZGVuY2U6IFtcblx0XHRcdHtcblx0XHRcdFx0X2lkOiBSYW5kb20uaWQoKSxcblx0XHRcdFx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5WSURFTyxcblx0XHRcdFx0bWF4TGVuZ3RoOiAxMCAqIE1JTlVURVxuXHRcdFx0fVxuXHRcdF0sXG5cdFx0ZGVzY3JpcHRpb246ICdBIHNpbmdsZSBwcm9ncmFtbWUgKG9yIGEgc2hvcnRlbmVkIGVkaXQgZnJvbSBhbiBlcGlzb2RlIG9yIHNlcmllcykgdGhhdCBkZW1vbnN0cmF0ZXMgY292ZXJhZ2Ugb2YgdW5pdmVyc2l0eSwgbG9jYWwgY29tbXVuaXR5LCBuYXRpb25hbCBvciBpbnRlcm5hdGlvbmFsIG5ld3MuIEl0IGRlbW9uc3RyYXRlcyBhbiB1bmRlcnN0YW5kaW5nIG9mIHRlbGV2aXNpb24gam91cm5hbGlzbSBhbmQgdXRpbGlzZXMsIHdoZXJlIGFwcHJvcHJpYXRlLCB0aGUgc2tpbGxzIG9mIHZpZGVvIGpvdXJuYWxpc20uJyxcblx0XHRmb3JBd2FyZHM6IERFRkFVTFRfQVdBUkRTX05BTUVTLk5BU1RBXG5cdH0sXG5cdHtcblx0XHRuYW1lOiBERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19NQVJTX0VMS0lOU19FTF9CUk9HWSxcblx0XHRzdXBwb3J0aW5nRXZpZGVuY2U6IFtcblx0XHRcdHtcblx0XHRcdFx0X2lkOiBSYW5kb20uaWQoKSxcblx0XHRcdFx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5WSURFTyxcblx0XHRcdFx0bWF4TGVuZ3RoOiAxMCAqIE1JTlVURVxuXHRcdFx0fVxuXHRcdF0sXG5cdFx0ZGVzY3JpcHRpb246ICdBIHNob3dyZWVsIGRlbW9uc3RyYXRpbmcgZWZmZWN0aXZlLCBpbm5vdmF0aXZlIGFuZCBzdHJvbmcgdXNlIG9mIG11bHRpbWVkaWEgY29udGVudCB3aXRoIGFuIGFjY29tcGFueWluZyBkb2N1bWVudC4nLFxuXHRcdGZvckF3YXJkczogREVGQVVMVF9BV0FSRFNfTkFNRVMuTkFTVEFcblx0fSxcblx0e1xuXHRcdG5hbWU6IERFRkFVTFRfQ0FURUdPUllfTkFNRVMuTmFTVEFfQVdBUkRTX1dSSVRJTkcsXG5cdFx0c3VwcG9ydGluZ0V2aWRlbmNlOiBbXG5cdFx0XHR7XG5cdFx0XHRcdF9pZDogUmFuZG9tLmlkKCksXG5cdFx0XHRcdHR5cGU6IFN1cHBvcnRpbmdFdmlkZW5jZVR5cGUuVklERU8sXG5cdFx0XHRcdG1heExlbmd0aDogNSAqIE1JTlVURSxcblx0XHRcdFx0ZGVzY3JpcHRpb246ICdWaWRlbyBlbnRyeSBsaW1pdCBvZiA1IG1pbnV0ZXMgZm9yIHJlZmVyZW5jZSwgZGVtb25zdHJhdGluZyBob3cgdGhlIHNjcmlwdCBoYXMgYmVlbiB2aXN1YWxpemVkLidcblx0XHRcdH0sXG5cdFx0XHR7XG5cdFx0XHRcdF9pZDogUmFuZG9tLmlkKCksXG5cdFx0XHRcdHR5cGU6IFN1cHBvcnRpbmdFdmlkZW5jZVR5cGUuUERGLFxuXHRcdFx0XHRtYXhMZW5ndGg6ICcnLFxuXHRcdFx0XHRkZXNjcmlwdGlvbjogJ1dyaXR0ZW4gZW50cnkgbGltaXQgb2YgMzAgcGFnZXMgb2YgdGV4dCBhdCBmb250IHNpemUgMTIuIFRoaXMgd2lsbCBiZSB3aGF0IGlzIGp1ZGdlZC4nXG5cdFx0XHR9XG5cdFx0XSxcblx0XHRkZXNjcmlwdGlvbjogJ0Egc2NyaXB0IGluIGFueSBnZW5yZSBvciBmb3JtYXQsIGZvciBhbnkga2luZCBvZiBzaG93IHByb2R1Y2VkIGJ5IHRoZSBzdGF0aW9uLiBUaGlzIGNhbiBpbmNsdWRlLCBidXQgaXMgbm90IGxpbWl0ZWQgdG8sIGZpY3Rpb25hbCB0ZWxlcGxheXMsIGZhY3R1YWwgbGlua3MgYW5kIGZlYXR1cmVzLCBkb2N1bWVudGFyeSBzY3JpcHRzLCBsaXZlIHNjcmlwdHMsIG5ld3MgcGllY2UsIGV0Yy4gV3JpdGluZyBtYXkgYmUgZnJvbSBhIHNpbmdsZSBwcm9ncmFtbWUgb3Igc2hvcnRlbmVkIGZyb20gYW4gZXBpc29kZSBvciBzZXJpZXMuJyxcblx0XHRmb3JBd2FyZHM6IERFRkFVTFRfQVdBUkRTX05BTUVTLk5BU1RBXG5cdH0sXG5cdHtcblx0XHRuYW1lOiBERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19MSVZFX0JST0FEQ0FTVCxcblx0XHRzdXBwb3J0aW5nRXZpZGVuY2U6IFtcblx0XHRcdHtcblx0XHRcdFx0X2lkOiBSYW5kb20uaWQoKSxcblx0XHRcdFx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5WSURFTyxcblx0XHRcdFx0bWF4TGVuZ3RoOiAxMCAqIE1JTlVURVxuXHRcdFx0fVxuXHRcdF0sXG5cdFx0ZGVzY3JpcHRpb246ICdBIHNpbmdsZSBwcm9ncmFtbWUgKG9yIGEgc2hvcnRlbmVkIGVkaXQgZnJvbSBhbiBlcGlzb2RlIG9yIHNlcmllcykgdGhhdCBoYXMgYmVlbiBicm9hZGNhc3QgbGl2ZSBvciBzaG90IGFzLWxpdmUgYnkgeW91ciBzdGF0aW9uLiBFbnRyaWVzIGZvciB0aGlzIGNhdGVnb3J5IG11c3Qgbm90IGhhdmUgaGFkIGFueSBhdWRpbyBvciB2aWRlbyBwcm9jZXNzaW5nIGFwcGxpZWQgYWZ0ZXIgdHJhbnNtaXNzaW9uLiBFbnRyaWVzIG1heSBiZSBlZGl0ZWQgaW4gcG9zdCBwcm9kdWN0aW9uIHRvIHByb2R1Y2UgYSBzaG93cmVlbCBlLmcuIGFueSBwYXJ0IG9mIHRoZSBicm9hZGNhc3QgZWRpdGVkIHRvZ2V0aGVyIHRvIG11c2ljLCBidXQgbXVzdCBub3QgaGF2ZSBwcm9jZXNzaW5nIHRvIGZpeCB0ZWNobmljYWwgcHJvYmxlbXMgdGhhdCB3ZXJlIHByZXNlbnQgZHVyaW5nIHRoZSBicm9hZGNhc3QgZS5nLiBlZGl0IG11c2ljIGZyb20gYSBtdWx0aXRyYWNrIHJlY29yZGluZywgY29tcHJlc3NvcnMvZ2F0ZXMgYXBwbGllZCwgY29sb3VyIGNvcnJlY3Rpb24sIGV4cG9zdXJlIGNoYW5nZXMsIGZpbHRlcnMuJyxcblx0XHRmb3JBd2FyZHM6IERFRkFVTFRfQVdBUkRTX05BTUVTLk5BU1RBXG5cdH0sXG5cdHtcblx0XHRuYW1lOiBERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19DSU5FTUFUT0dSQVBIWSxcblx0XHRzdXBwb3J0aW5nRXZpZGVuY2U6IFtcblx0XHRcdHtcblx0XHRcdFx0X2lkOiBSYW5kb20uaWQoKSxcblx0XHRcdFx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5WSURFTyxcblx0XHRcdFx0bWF4TGVuZ3RoOiAxMCAqIE1JTlVURVxuXHRcdFx0fVxuXHRcdF0sXG5cdFx0ZGVzY3JpcHRpb246ICdBbiBvcHBvcnR1bml0eSBmb3IgZmlsbW1ha2VycyB0byBzaG93Y2FzZSB0aGVpciBiZXN0IHdvcmssIGRlbW9uc3RyYXRpbmcgYSBrbm93bGVkZ2Ugb2YgYXBwcm9wcmlhdGUgbGlnaHRpbmcsIGNhbWVyYSBtb3ZlcyBhbmQgb3RoZXIgYXNzb2NpYXRlZCB0ZWNobmlxdWVzIG9mIHRoZSBjcmFmdCwgYW5kIGhvdyB3ZWxsIHRoZXNlIHRoaW5ncyBhcmUgaW1wbGVtZW50ZWQgaW4gZmlsbSBvciB0ZWxldmlzaW9uLiBUaGlzIHNob3dyZWVsIHNob3VsZCBiZSBtYWRlIHVwIG9mIGNvbnRlbnQgZnJvbSBhIHNpbmdsZSBwcm9ncmFtbWUgKG9yIGEgc2hvcnRlbmVkIGVkaXQgZnJvbSBhbiBlcGlzb2RlIG9yIHNlcmllcyknLFxuXHRcdGZvckF3YXJkczogREVGQVVMVF9BV0FSRFNfTkFNRVMuTkFTVEFcblx0fSxcblx0e1xuXHRcdG5hbWU6IERFRkFVTFRfQ0FURUdPUllfTkFNRVMuTmFTVEFfQVdBUkRTX0xJR0hUX0VOVEVSVEFJTk1FTlQsXG5cdFx0c3VwcG9ydGluZ0V2aWRlbmNlOiBbXG5cdFx0XHR7XG5cdFx0XHRcdF9pZDogUmFuZG9tLmlkKCksXG5cdFx0XHRcdHR5cGU6IFN1cHBvcnRpbmdFdmlkZW5jZVR5cGUuVklERU8sXG5cdFx0XHRcdG1heExlbmd0aDogMTAgKiBNSU5VVEVcblx0XHRcdH1cblx0XHRdLFxuXHRcdGRlc2NyaXB0aW9uOiAnQSBzaW5nbGUgcHJvZ3JhbW1lIChvciBhIHNob3J0ZW5lZCBlZGl0IGZyb20gYW4gZXBpc29kZSBvciBzZXJpZXMpIGludGVuZGVkIGFzIGxpZ2h0IGVudGVydGFpbm1lbnQuJyxcblx0XHRmb3JBd2FyZHM6IERFRkFVTFRfQVdBUkRTX05BTUVTLk5BU1RBXG5cdH0sXG5cdHtcblx0XHRuYW1lOiBERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19USVRMRV9TRVFVRU5DRSxcblx0XHRzdXBwb3J0aW5nRXZpZGVuY2U6IFtcblx0XHRcdHtcblx0XHRcdFx0X2lkOiBSYW5kb20uaWQoKSxcblx0XHRcdFx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5WSURFTyxcblx0XHRcdFx0bWF4TGVuZ3RoOiA5MCAqIDEwMDBcblx0XHRcdH0sXG5cdFx0XHR7XG5cdFx0XHRcdF9pZDogUmFuZG9tLmlkKCksXG5cdFx0XHRcdHR5cGU6IFN1cHBvcnRpbmdFdmlkZW5jZVR5cGUuVEVYVCxcblx0XHRcdFx0bWF4TGVuZ3RoOiAxMDAsXG5cdFx0XHRcdGRlc2NyaXB0aW9uOiAnV3JpdHRlbiBlbnRyeSBsaW1pdCBvZiAxMDAgd29yZHMsIG5vdCBqdWRnZWQgYnV0IGFsbG93ZWQgdG8gaGVscCBqdWRnZSBob3cgd2VsbCB0aGUgZW50cnkgaW50cm9kdWNlcyB0aGUgcHJvZ3JhbS4gVGhpcyBpcyBzdXBwbGVtZW50YXJ5IGV2aWRlbmNlIGFuZCBub3QganVkZ2VkIGluIGl0c2VsZi4nXG5cdFx0XHR9XG5cdFx0XSxcblx0XHRkZXNjcmlwdGlvbjogJ1RoZSBpbnRyb2R1Y3Rvcnkgc2VxdWVuY2UgdG8gb25lIG9mIHlvdXIgc3RhdGlvbuKAmXMgcHJvZ3JhbW1lcy4gVGhlIHZlcnkgYmVnaW5uaW5nIG9mIGFuIGV4ZW1wbGFyIHByb2dyYW1tZSBtYXkgYmUgaW5jbHVkZWQuIFRoaXMgZW50cnkgbXVzdCBiZSBhIGNvbXBsZXRlIHZpZGVvIG5vdCBhIGN1dCBkb3duIHZpZGVvIG9yIGFuIGVkaXRlZCBoaWdobGlnaHRzIHJlZWwuJyxcblx0XHRmb3JBd2FyZHM6IERFRkFVTFRfQVdBUkRTX05BTUVTLk5BU1RBXG5cdH0sXG5cdHtcblx0XHRuYW1lOiBERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19DT01FRFksXG5cdFx0c3VwcG9ydGluZ0V2aWRlbmNlOiBbXG5cdFx0XHR7XG5cdFx0XHRcdF9pZDogUmFuZG9tLmlkKCksXG5cdFx0XHRcdHR5cGU6IFN1cHBvcnRpbmdFdmlkZW5jZVR5cGUuVklERU8sXG5cdFx0XHRcdG1heExlbmd0aDogMTAgKiBNSU5VVEVcblx0XHRcdH1cblx0XHRdLFxuXHRcdGRlc2NyaXB0aW9uOiAnQSBzaW5nbGUgcHJvZ3JhbW1lIG9yIHNlcmllcyBlcGlzb2RlIHRoYXQgYWltcyB0byBtYWtlIHRoZSB2aWV3ZXIgbGF1Z2gsIGluY2x1ZGluZywgYnV0IG5vdCBsaW1pdGVkIHRvOiBTaXRjb21zLCBDb21lZHkgRHJhbWFzLCBTdGFuZC11cCwgU2tldGNoU2hvd3MuJyxcblx0XHRmb3JBd2FyZHM6IERFRkFVTFRfQVdBUkRTX05BTUVTLk5BU1RBXG5cdH0sXG5cdHtcblx0XHRuYW1lOiBERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19EUkFNQSxcblx0XHRzdXBwb3J0aW5nRXZpZGVuY2U6IFtcblx0XHRcdHtcblx0XHRcdFx0X2lkOiBSYW5kb20uaWQoKSxcblx0XHRcdFx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5WSURFTyxcblx0XHRcdFx0bWF4TGVuZ3RoOiAxMCAqIE1JTlVURVxuXHRcdFx0fVxuXHRcdF0sXG5cdFx0ZGVzY3JpcHRpb246ICdBIHNpbmdsZSBwcm9ncmFtbWUgKG9yIGEgc2hvcnRlbmVkIGVkaXQgZnJvbSBhbiBlcGlzb2RlIG9yIHNlcmllcykgb2ZvcmlnaW5hbCBzY3JpcHRlZCBkcmFtYXRpYyBwcm9kdWN0aW9uLiBOb3RlOiBTaXRjb21zIG9yIGRyYW1hdGljIHByb2R1Y3Rpb25zIHdoaWNoIGFyZSBwcmltYXJpbHkgY29tZWRpYyBzaG91bGQgYmUgZW50ZXJlZCBmb3IgdGhlIENvbWVkeSBjYXRlZ29yeS4nLFxuXHRcdGZvckF3YXJkczogREVGQVVMVF9BV0FSRFNfTkFNRVMuTkFTVEFcblx0fSxcblx0e1xuXHRcdG5hbWU6IERFRkFVTFRfQ0FURUdPUllfTkFNRVMuTkFTVEFfQVdBUkRTX0RPQ1VNRU5UQVJZX0FORF9GQUNUVUFMLFxuXHRcdHN1cHBvcnRpbmdFdmlkZW5jZTogW1xuXHRcdFx0e1xuXHRcdFx0XHRfaWQ6IFJhbmRvbS5pZCgpLFxuXHRcdFx0XHR0eXBlOiBTdXBwb3J0aW5nRXZpZGVuY2VUeXBlLlZJREVPLFxuXHRcdFx0XHRtYXhMZW5ndGg6IDEwICogTUlOVVRFXG5cdFx0XHR9XG5cdFx0XSxcblx0XHRkZXNjcmlwdGlvbjogJ0Egc2luZ2xlIHByb2dyYW1tZSAob3IgYSBzaG9ydGVuZWQgZWRpdCBmcm9tIGFuIGVwaXNvZGUgb3Igc2VyaWVzKSBmZWF0dXJpbmcgZmFjdHVhbCBtYXRlcmlhbCwgcHJlc2VudGVkIGluIGFueSBmb3JtYXQuJyxcblx0XHRmb3JBd2FyZHM6IERFRkFVTFRfQVdBUkRTX05BTUVTLk5BU1RBXG5cdH0sXG5cdHtcblx0XHRuYW1lOiBERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19TUE9SVCxcblx0XHRzdXBwb3J0aW5nRXZpZGVuY2U6IFtcblx0XHRcdHtcblx0XHRcdFx0X2lkOiBSYW5kb20uaWQoKSxcblx0XHRcdFx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5WSURFTyxcblx0XHRcdFx0bWF4TGVuZ3RoOiAxMCAqIE1JTlVURVxuXHRcdFx0fVxuXHRcdF0sXG5cdFx0ZGVzY3JpcHRpb246ICdDb3ZlcmFnZSBvZiBhIHNwb3J0aW5nIGV2ZW50IG9yIGEgc2luZ2xlIHByb2dyYW1tZSAob3IgYSBzaG9ydGVuZWQgZWRpdCBmcm9tIGFuIGVwaXNvZGUgb3Igc2VyaWVzKSB3aGljaCBmZWF0dXJlcyBsaXZlIG9yIHJlY29yZGVkIHNwb3J0LCBhbmQvb3IgY29tbWVudHMgb24gc3BvcnQgb3Igc3BvcnRzIGZhY2lsaXRpZXMuJyxcblx0XHRmb3JBd2FyZHM6IERFRkFVTFRfQVdBUkRTX05BTUVTLk5BU1RBXG5cdH0sXG5cdHtcblx0XHRuYW1lOiBERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19QT1NUX1BST0RVQ1RJT05fQVdBUkQsXG5cdFx0c3VwcG9ydGluZ0V2aWRlbmNlOiBbXG5cdFx0XHR7XG5cdFx0XHRcdF9pZDogUmFuZG9tLmlkKCksXG5cdFx0XHRcdHR5cGU6IFN1cHBvcnRpbmdFdmlkZW5jZVR5cGUuVklERU8sXG5cdFx0XHRcdG1heExlbmd0aDogMTAgKiBNSU5VVEVcblx0XHRcdH1cblx0XHRdLFxuXHRcdGRlc2NyaXB0aW9uOiAnQSBzaW5nbGUgcHJvZ3JhbW1lIChvciBhIHNob3J0ZW5lZCBlZGl0IGZyb20gYW4gZXBpc29kZSBvciBzZXJpZXMpIHNob3dyZWVsIGRlbW9uc3RyYXRpbmcgZXhjZWxsZW50IHBvc3QgcHJvZHVjdGlvbiBhbmQgZWRpdGluZyBza2lsbHMuJyxcblx0XHRmb3JBd2FyZHM6IERFRkFVTFRfQVdBUkRTX05BTUVTLk5BU1RBXG5cdH0sXG5cdHtcblx0XHRuYW1lOiBERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19TVVBFUl9CTE9PUEVSLFxuXHRcdHN1cHBvcnRpbmdFdmlkZW5jZTogW1xuXHRcdFx0e1xuXHRcdFx0XHRfaWQ6IFJhbmRvbS5pZCgpLFxuXHRcdFx0XHR0eXBlOiBTdXBwb3J0aW5nRXZpZGVuY2VUeXBlLlZJREVPLFxuXHRcdFx0XHRtYXhMZW5ndGg6IDEwICogTUlOVVRFXG5cdFx0XHR9XG5cdFx0XSxcblx0XHRkZXNjcmlwdGlvbjogJ0p1c3QgZm9yIGZ1biwgdXBsb2FkIGEgbW9udGFnZSBvZiB5b3VyIGJsb29wZXJzIGZyb20gdGhpcyB5ZWFyIScsXG5cdFx0Zm9yQXdhcmRzOiBERUZBVUxUX0FXQVJEU19OQU1FUy5OQVNUQVxuXHR9LFxuXHR7XG5cdFx0bmFtZTogREVGQVVMVF9DQVRFR09SWV9OQU1FUy5QQ0FzX09QRU4sXG5cdFx0c3VwcG9ydGluZ0V2aWRlbmNlOiBbXG5cdFx0XHR7XG5cdFx0XHRcdF9pZDogUmFuZG9tLmlkKCksXG5cdFx0XHRcdHR5cGU6IFN1cHBvcnRpbmdFdmlkZW5jZVR5cGUuVklERU8sXG5cdFx0XHRcdG1heExlbmd0aDogMTAgKiBNSU5VVEVcblx0XHRcdH1cblx0XHRdLFxuXHRcdGRlc2NyaXB0aW9uOiAnQW55IHZpZGVvIGNvbnRlbnQgY2FuIGJlIGVudGVyZWQgaW50byB0aGlzIGNhdGVnb3J5LicsXG5cdFx0Zm9yQXdhcmRzOiBERUZBVUxUX0FXQVJEU19OQU1FUy5QRU9QTEVTX0NIT0lDRVxuXHR9LFxuXHR7XG5cdFx0bmFtZTogREVGQVVMVF9DQVRFR09SWV9OQU1FUy5QQ0FzX0xJVkVfQlJPQURDQVNULFxuXHRcdHN1cHBvcnRpbmdFdmlkZW5jZTogW1xuXHRcdFx0e1xuXHRcdFx0XHRfaWQ6IFJhbmRvbS5pZCgpLFxuXHRcdFx0XHR0eXBlOiBTdXBwb3J0aW5nRXZpZGVuY2VUeXBlLlZJREVPLFxuXHRcdFx0XHRtYXhMZW5ndGg6IDEwICogTUlOVVRFXG5cdFx0XHR9XG5cdFx0XSxcblx0XHRkZXNjcmlwdGlvbjogJ0Egc2luZ2xlIHByb2dyYW1tZSAob3IgYSBzaG9ydGVuZWQgZWRpdCBmcm9tIGFuIGVwaXNvZGUgb3Igc2VyaWVzKSB0aGF0IGhhcyBiZWVuIGJyb2FkY2FzdCBsaXZlIG9yIHNob3QgYXMtbGl2ZSBieSB5b3VyIHN0YXRpb24uIEVudHJpZXMgZm9yIHRoaXMgY2F0ZWdvcnkgbXVzdCBub3QgaGF2ZSBoYWQgYW55IGF1ZGlvIG9yIHZpZGVvIHByb2Nlc3NpbmcgYXBwbGllZCBhZnRlciB0cmFuc21pc3Npb24uIEVudHJpZXMgbWF5IGJlIGVkaXRlZCBpbiBwb3N0IHByb2R1Y3Rpb24gdG8gcHJvZHVjZSBhIHNob3dyZWVsIGUuZy4gYW55IHBhcnQgb2YgdGhlIGJyb2FkY2FzdCBlZGl0ZWQgdG9nZXRoZXIgdG8gbXVzaWMsIGJ1dCBtdXN0IG5vdCBoYXZlIHByb2Nlc3NpbmcgdG8gZml4IHRlY2huaWNhbCBwcm9ibGVtcyB0aGF0IHdlcmUgcHJlc2VudGR1cmluZyB0aGUgYnJvYWRjYXN0IGUuZy4gZWRpdCBtdXNpYyBmcm9tIGEgbXVsdGl0cmFjayByZWNvcmRpbmcsIGNvbXByZXNzb3JzL2dhdGVzIGFwcGxpZWQsIGNvbG91ciBjb3JyZWN0aW9uLCBleHBvc3VyZSBjaGFuZ2VzLCBmaWx0ZXJzLicsXG5cdFx0Zm9yQXdhcmRzOiBERUZBVUxUX0FXQVJEU19OQU1FUy5QRU9QTEVTX0NIT0lDRVxuXHR9LFxuXHR7XG5cdFx0bmFtZTogREVGQVVMVF9DQVRFR09SWV9OQU1FUy5QQ0FzX0NPTlRFTlRfSU5OT1ZBVElPTixcblx0XHRzdXBwb3J0aW5nRXZpZGVuY2U6IFtcblx0XHRcdHtcblx0XHRcdFx0X2lkOiBSYW5kb20uaWQoKSxcblx0XHRcdFx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5WSURFTyxcblx0XHRcdFx0bWF4TGVuZ3RoOiAxMCAqIE1JTlVURVxuXHRcdFx0fVxuXHRcdF0sXG5cdFx0ZGVzY3JpcHRpb246ICdBIHNpbmdsZSBwcm9ncmFtbWUgKG9yIGEgc2hvcnRlbmVkIGVkaXQgZnJvbSBhbiBlcGlzb2RlIG9yIHNlcmllcykgc2hvd3JlZWwgZGVtb25zdHJhdGluZyBpbm5vdmF0aXZlIGNvbnRlbnQuIFRoaXMgY2FuIGJlIGFuIGlubm92YXRpdmUgc2hvdyBmb3JtYXQsIGlubm92YXRpb24gaW4gdGhlIHVzZSBvZiBmZWF0dXJlcyBvciBzZWdtZW50cywgb3IgaW5ub3ZhdGl2ZSB3YXlzIG9mIGVuZ2FnaW5nIHdpdGggeW91ciBhdWRpZW5jZS4nLFxuXHRcdGZvckF3YXJkczogREVGQVVMVF9BV0FSRFNfTkFNRVMuUEVPUExFU19DSE9JQ0Vcblx0fSxcblx0e1xuXHRcdG5hbWU6IERFRkFVTFRfQ0FURUdPUllfTkFNRVMuUENBc19URUNITklDQUxfSU5OT1ZBVElPTixcblx0XHRzdXBwb3J0aW5nRXZpZGVuY2U6IFtcblx0XHRcdHtcblx0XHRcdFx0X2lkOiBSYW5kb20uaWQoKSxcblx0XHRcdFx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5QREYsXG5cdFx0XHRcdG1heExlbmd0aDogJzUwMCBXb3JkcycsXG5cdFx0XHRcdGRlc2NyaXB0aW9uOiAnQSByZXBvcnQgd2hpY2ggZ2l2ZXMgYW4gYWNjb3VudCBvZiBhbnkgdGVjaG5pY2FsIGlubm92YXRpb24gZGV2ZWxvcGVkIHRvIHN1cHBvcnQgeW91ciBzdGF0aW9u4oCZcyBvdXRwdXQuIEVudHJpZXMgd2lsbCBkZW1vbnN0cmF0ZSBib3RoIHRoZSB0ZWNobmljYWwgY2hhbGxlbmdlcyBmYWNlZCwgdGhlIGlubm92YXRpdmUgd2F5KHMpIGluIHdoaWNoIHRoZXkgd2VyZSBvdmVyY29tZSwgYW5kIHRoZSBiZW5lZml0cyB0aGlzIGJyb3VnaHQgdG8gdGhlIHByb2R1Y3Rpb24ocykuJ1xuXHRcdFx0fVxuXHRcdF0sXG5cdFx0ZGVzY3JpcHRpb246ICdJdCBpcyBleHBlY3RlZCB0aGF0IGVudHJpZXMgZm9yIHRoaXMgYXdhcmQgZGVtb25zdHJhdGUgc29tZSB0ZWNobmljYWwgZGV2ZWxvcG1lbnQgYnkgeW91ciBzdGF0aW9uLCBlaXRoZXIgaW4gc29mdHdhcmUgKGluY2x1ZGluZyBvbmxpbmUpIG9yIGhhcmR3YXJlLCByYXRoZXIgdGhhbiB1c2Ugb2YgZXhpc3RpbmcgdGVjaG5pY2FsIHNvbHV0aW9ucy4nLFxuXHRcdGZvckF3YXJkczogREVGQVVMVF9BV0FSRFNfTkFNRVMuUEVPUExFU19DSE9JQ0Vcblx0fSxcblx0e1xuXHRcdG5hbWU6IERFRkFVTFRfQ0FURUdPUllfTkFNRVMuUENBc19WSVNVQUxfQ1JFQVRJVklUWV9BTkRfUVVBTElUWSxcblx0XHRzdXBwb3J0aW5nRXZpZGVuY2U6IFtcblx0XHRcdHtcblx0XHRcdFx0X2lkOiBSYW5kb20uaWQoKSxcblx0XHRcdFx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5WSURFTyxcblx0XHRcdFx0bWF4TGVuZ3RoOiAxMCAqIE1JTlVURVxuXHRcdFx0fVxuXHRcdF0sXG5cdFx0ZGVzY3JpcHRpb246ICdBIHNpbmdsZSBwcm9ncmFtbWUgKG9yIGEgc2hvcnRlbmVkIGVkaXQgZnJvbSBhbiBlcGlzb2RlIG9yIHNlcmllcykgc2hvd2Nhc2luZyBleGNlbGxlbmNlIGluIHRoZSBmb2xsb3dpbmcgYXJlYXM6IGNpbmVtYXRvZ3JhcGh5LCBlZGl0aW5nLCBhbmltYXRpb25zIGFuZCB2aXN1YWwgZWZmZWN0cy4nLFxuXHRcdGZvckF3YXJkczogREVGQVVMVF9BV0FSRFNfTkFNRVMuUEVPUExFU19DSE9JQ0Vcblx0fSxcblx0e1xuXHRcdG5hbWU6IERFRkFVTFRfQ0FURUdPUllfTkFNRVMuUENBc19CRVNUX09OX1NDUkVFTl9UQUxFTlQsXG5cdFx0c3VwcG9ydGluZ0V2aWRlbmNlOiBbXG5cdFx0XHR7XG5cdFx0XHRcdF9pZDogUmFuZG9tLmlkKCksXG5cdFx0XHRcdHR5cGU6IFN1cHBvcnRpbmdFdmlkZW5jZVR5cGUuVklERU8sXG5cdFx0XHRcdG1heExlbmd0aDogNSAqIE1JTlVURVxuXHRcdFx0fVxuXHRcdF0sXG5cdFx0ZGVzY3JpcHRpb246ICdBIHNob3dyZWVsIGRlbW9uc3RyYXRpbmcgdGhlIG9uLXNjcmVlbiBza2lsbHMsIHN0eWxlcyBhbmQgdGVjaG5pcXVlcyBvZiBhIHBhcnRpY3VsYXIgaW5kaXZpZHVhbCBpbiBhbnkgcHJvZHVjdGlvbiBleGNsdWRpbmcgZmljdGlvbmFsIGNvbnRlbnQuIFRoaXMgc2hvd3JlZWwgbWF5IGJlIG1hZGUgdXAgb2YgY29udGVudCBmcm9tIG11bHRpcGxlIHByb2R1Y3Rpb25zLicsXG5cdFx0Zm9yQXdhcmRzOiBERUZBVUxUX0FXQVJEU19OQU1FUy5QRU9QTEVTX0NIT0lDRVxuXHR9LFxuXHR7XG5cdFx0bmFtZTogREVGQVVMVF9DQVRFR09SWV9OQU1FUy5QQ0FzX1VOX1NVTkdfSEVSTyxcblx0XHRzdXBwb3J0aW5nRXZpZGVuY2U6IFtcblx0XHRcdHtcblx0XHRcdFx0X2lkOiBSYW5kb20uaWQoKSxcblx0XHRcdFx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5URVhULFxuXHRcdFx0XHRtYXhMZW5ndGg6IDUwMFxuXHRcdFx0fVxuXHRcdF0sXG5cdFx0ZGVzY3JpcHRpb246ICdUaGlzIGF3YXJkIHJlY29nbmlzZXMgdGhlIGNvbnRyaWJ1dGlvbiBvZiBhbiBpbmRpdmlkdWFsIHRvIHRoZWlyIHN0YXRpb24gYW5kL29yIHRoZSBOYVNUQSBjb21tdW5pdHkuIEVudHJpZXMgZm9yIHRoaXMgYXdhcmQgbXVzdCBub21pbmF0ZSBhIHBlcnNvbiB3aG8gaXMgYSBjdXJyZW50IG1lbWJlciBvZiB5b3VyIHN0dWRlbnQgVFYgc3RhdGlvbiBvciB3aG8gd2FzIGEgbWVtYmVyIHdpdGhpbiB0aGUgbGFzdCB0d2VsdmUgbW9udGhzLiBFbnRyaWVzIGZvciB0aGlzIGF3YXJkIG1heSBpbmNsdWRlIGNvbnRyaWJ1dGlvbnMgZnJvbSB0aGUgbm9taW5lZeKAmXMgd2hvbGUgdGltZSBhcyBhIG1lbWJlciBvZiB5b3VyIHN0YXRpb24sIG5vdCBsaW1pdGVkIHRvIHRoZSBsYXN0IHR3ZWx2ZSBtb250aHMuIEhvd2V2ZXIgaXQgaXMgaW50ZW5kZWQgdGhhdCBhIG1ham9yIHBhcnQgb2YgdGhlIGNvbnRyaWJ1dGlvbiBoYXMgdGFrZW4gcGFydCBpbiB0aGUgbGFzdCB0d2VsdmUgbW9udGhzLicsXG5cdFx0Zm9yQXdhcmRzOiBERUZBVUxUX0FXQVJEU19OQU1FUy5QRU9QTEVTX0NIT0lDRVxuXHR9LFxuXHR7XG5cdFx0bmFtZTogREVGQVVMVF9DQVRFR09SWV9OQU1FUy5QQ0FzX1NUQVRJT05fT0ZfVEhFX1lFQVIsXG5cdFx0c3VwcG9ydGluZ0V2aWRlbmNlOiBbXG5cdFx0XHR7XG5cdFx0XHRcdF9pZDogUmFuZG9tLmlkKCksXG5cdFx0XHRcdHR5cGU6IFN1cHBvcnRpbmdFdmlkZW5jZVR5cGUuVklERU8sXG5cdFx0XHRcdG1heExlbmd0aDogMTAgKiBNSU5VVEVcblx0XHRcdH0sXG5cdFx0XHR7XG5cdFx0XHRcdF9pZDogUmFuZG9tLmlkKCksXG5cdFx0XHRcdHR5cGU6IFN1cHBvcnRpbmdFdmlkZW5jZVR5cGUuVEVYVCxcblx0XHRcdFx0bWF4TGVuZ3RoOiA1MDBcblx0XHRcdH1cblx0XHRdLFxuXHRcdGRlc2NyaXB0aW9uOiAnQSBzaG93cmVlbCBkZW1vbnN0cmF0aW5nIHRoZSByYW5nZSwgcXVhbGl0eSBhbmQgc2tpbGxzIG9mIHRoZSBzdGF0aW9uIGFuZCBpdHMgcHJvZ3JhbW1pbmcsIHRvIGJlIGFjY29tcGFuaWVkIGJ5IGEgd3JpdHRlbiByZXBvcnQsIHdpdGggZGV0YWlscyBvZiB0aGUgb3BlcmF0aW9uIG9mIHRoZSBzdGF0aW9uIGFuZCBjb250cmlidXRpb25zIG1hZGUgd2hpY2ggbWF5IG5vdCBuZWNlc3NhcmlseSBhcHBlYXIgb24gc2NyZWVuLicsXG5cdFx0Zm9yQXdhcmRzOiBERUZBVUxUX0FXQVJEU19OQU1FUy5QRU9QTEVTX0NIT0lDRVxuXHR9XG5dXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXG5pbXBvcnQgeyBOYVNUQVVzZXIsIFVzZXJIYXNSb2xlIH0gZnJvbSAnLi9hY2NvdW50cydcbmltcG9ydCB7IENvbGxlY3Rpb25zLCBSb2xlcywgVmVyaWZpY2F0aW9uU3RhdHVzIH0gZnJvbSAnLi9oZWxwZXJzL2VudW1zJ1xuXG5leHBvcnQgaW50ZXJmYWNlIEVudHJ5IHtcblx0X2lkPzogc3RyaW5nXG5cdHN0YXRpb25JZDogc3RyaW5nXG5cdGNhdGVnb3J5SWQ6IHN0cmluZ1xuXHRkYXRlOiBudW1iZXJcblx0ZXZpZGVuY2VJZHM6IHN0cmluZ1tdXG5cdHZpZGVvTGlua3M/OiBzdHJpbmcsXG5cdHZlcmlmaWVkOiBWZXJpZmljYXRpb25TdGF0dXNcbn1cblxuZXhwb3J0IGNvbnN0IEVudHJpZXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbjxFbnRyeT4oQ29sbGVjdGlvbnMuRU5UUklFUylcblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuXHRNZXRlb3IucHVibGlzaChDb2xsZWN0aW9ucy5FTlRSSUVTLCBmdW5jdGlvbiBlbnRyaWVzUHVibGljdGFpb24gKCkge1xuXHRcdGlmIChNZXRlb3IudXNlcklkKCkgJiYgVXNlckhhc1JvbGUoW1JvbGVzLkFETUlOLCBSb2xlcy5IT1NULCBSb2xlcy5KVURHRV0pKSB7XG5cdFx0XHRyZXR1cm4gRW50cmllcy5maW5kKClcblx0XHR9IGVsc2UgaWYgKE1ldGVvci51c2VySWQoKSAmJiBVc2VySGFzUm9sZShbUm9sZXMuU1RBVElPTl0pKSB7XG5cdFx0XHRyZXR1cm4gRW50cmllcy5maW5kKHsgc3RhdGlvbklkOiAoTWV0ZW9yLnVzZXIoKSBhcyBOYVNUQVVzZXIpLnN0YXRpb25JZCB9KVxuXHRcdH1cblx0fSlcbn1cbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbydcbmltcG9ydCB7IFVzZXJIYXNSb2xlIH0gZnJvbSAnLi9hY2NvdW50cydcbmltcG9ydCB7IENvbGxlY3Rpb25zLCBSb2xlcywgU3VwcG9ydGluZ0V2aWRlbmNlVHlwZSB9IGZyb20gJy4vaGVscGVycy9lbnVtcydcblxuZXhwb3J0IGludGVyZmFjZSBFdmlkZW5jZUJhc2Uge1xuXHR0eXBlOiBTdXBwb3J0aW5nRXZpZGVuY2VUeXBlXG5cdF9pZD86IHN0cmluZ1xuXHQvKiogVGhlIGNhdGVnb3J5IHN1cHBvcnRpbmcgZXZpZGVuY2UgdGhpcyBiZWxvbmdzIHRvICovXG5cdHN1cHBvcnRpbmdFdmlkZW5jZUlkOiBzdHJpbmdcblx0c3RhdGlvbklkOiBzdHJpbmdcblx0YXdhcmRJZDogc3RyaW5nIC8vIFRPRE86IFJlbmFtZSB0byBjYXRlZ29yeUlkXG5cdC8qKiBDb3VsZCBiZSB0ZXh0LCB1cmwgKi9cblx0Y29udGVudDogc3RyaW5nXG5cdC8qKiBXaGV0aGVyIHRoZSBldmlkZW5jZSBoYXMgYmVlbiB2ZXJpZmllZCAqL1xuXHR2ZXJpZmllZDogYm9vbGVhblxufVxuXG5leHBvcnQgaW50ZXJmYWNlIEV2aWRlbmNlVmlkZW8gZXh0ZW5kcyBFdmlkZW5jZUJhc2Uge1xuXHR0eXBlOiBTdXBwb3J0aW5nRXZpZGVuY2VUeXBlLlZJREVPXG5cdHNoYXJpbmdMaW5rOiBzdHJpbmdcblx0c2hvcnRDbGlwU2hhcmluZ0xpbms6IHN0cmluZ1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEV2aWRlbmNlUERGIGV4dGVuZHMgRXZpZGVuY2VCYXNlIHtcblx0dHlwZTogU3VwcG9ydGluZ0V2aWRlbmNlVHlwZS5QREZcblx0c2hhcmluZ0xpbms6IHN0cmluZ1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEV2aWRlbmNlVGV4dCBleHRlbmRzIEV2aWRlbmNlQmFzZSB7XG5cdHR5cGU6IFN1cHBvcnRpbmdFdmlkZW5jZVR5cGUuVEVYVFxufVxuXG5leHBvcnQgaW50ZXJmYWNlIEV2aWRlbmNlQ2FsbCBleHRlbmRzIEV2aWRlbmNlQmFzZSB7XG5cdHR5cGU6IFN1cHBvcnRpbmdFdmlkZW5jZVR5cGUuQ0FMTFxufVxuXG5leHBvcnQgdHlwZSBFdmlkZW5jZSA9IEV2aWRlbmNlVmlkZW8gfCBFdmlkZW5jZVBERiB8IEV2aWRlbmNlVGV4dCB8IEV2aWRlbmNlQ2FsbFxuXG5leHBvcnQgY29uc3QgRXZpZGVuY2VDb2xsZWN0aW9uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb248RXZpZGVuY2U+KENvbGxlY3Rpb25zLkVWSURFTkNFKVxuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cdE1ldGVvci5wdWJsaXNoKENvbGxlY3Rpb25zLkVWSURFTkNFLCAoKSA9PiB7XG5cdFx0aWYgKE1ldGVvci51c2VySWQoKSAmJiBVc2VySGFzUm9sZShbUm9sZXMuQURNSU4sIFJvbGVzLkhPU1QsIFJvbGVzLkpVREdFXSkpIHtcblx0XHRcdHJldHVybiBFdmlkZW5jZUNvbGxlY3Rpb24uZmluZCh7IH0pXG5cdFx0fVxuXHR9KVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gSW5zZXJ0RXZpZGVuY2UgKGV2aWRlbmNlOiBFdmlkZW5jZSk6IFByb21pc2U8c3RyaW5nPiB7XG5cdHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0RXZpZGVuY2VDb2xsZWN0aW9uLmluc2VydChldmlkZW5jZSwgKGVycm9yOiBhbnksIGlkOiBzdHJpbmcpID0+IHtcblx0XHRcdGlmIChlcnJvcikgcmVqZWN0KGVycm9yKVxuXHRcdFx0Ly8gVE9ETzogTXVsdGlwbGUgZW50cmllc1xuXHRcdFx0Ly8gVE9ETzogRW50cnkgSURzIGFyZSBudWxsXG5cdFx0XHRyZXNvbHZlKGlkKVxuXHRcdH0pXG5cdH0pXG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXG5pbXBvcnQgeyBVc2VySGFzUm9sZSB9IGZyb20gJy4vYWNjb3VudHMnXG5pbXBvcnQgeyBDb2xsZWN0aW9ucywgUm9sZXMgfSBmcm9tICcuL2hlbHBlcnMvZW51bXMnXG5cbmV4cG9ydCBpbnRlcmZhY2UgSnVkZ2VUb0NhdGVnb3J5IHtcblx0X2lkPzogc3RyaW5nLFxuXHRqdWRnZUlkOiBzdHJpbmcsXG5cdGNhdGVnb3J5SWQ6IHN0cmluZ1xufVxuXG5leHBvcnQgY29uc3QgSnVkZ2VUb0NhdGVnb3J5ID0gbmV3IE1vbmdvLkNvbGxlY3Rpb248SnVkZ2VUb0NhdGVnb3J5PihDb2xsZWN0aW9ucy5KdWRnZVRvQ2F0ZWdvcnkpXG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcblx0TWV0ZW9yLnB1Ymxpc2goQ29sbGVjdGlvbnMuSnVkZ2VUb0NhdGVnb3J5LCAoKSA9PiB7XG5cdFx0aWYgKE1ldGVvci51c2VySWQoKSAmJiBVc2VySGFzUm9sZShbUm9sZXMuSlVER0UsIFJvbGVzLkFETUlOLCBSb2xlcy5IT1NUXSkpIHtcblx0XHRcdHJldHVybiBKdWRnZVRvQ2F0ZWdvcnkuZmluZCh7IH0pXG5cdFx0fVxuXHR9KVxufVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJ1xuaW1wb3J0IHsgVXNlckhhc1JvbGUgfSBmcm9tICcuL2FjY291bnRzJ1xuaW1wb3J0IHsgQ29sbGVjdGlvbnMsIFJvbGVzIH0gZnJvbSAnLi9oZWxwZXJzL2VudW1zJ1xuXG5leHBvcnQgaW50ZXJmYWNlIFJlc3VsdCB7XG5cdF9pZD86IHN0cmluZ1xuXHRjYXRlZ29yeUlkOiBzdHJpbmdcblx0anVkZ2VkQnk6IHN0cmluZ1xuXHRqb2ludEZpcnN0PzogYm9vbGVhblxuXHRqb2ludEhpZ2hseUNvbW1lbmRlZD86IGJvb2xlYW5cblx0b3JkZXI6IHtcblx0XHRbc3RhdGlvbklkOiBzdHJpbmddOiBudW1iZXJcblx0fVxufVxuXG5leHBvcnQgY29uc3QgUmVzdWx0cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uPFJlc3VsdD4oQ29sbGVjdGlvbnMuUkVTVUxUUylcblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuXHRNZXRlb3IucHVibGlzaChDb2xsZWN0aW9ucy5SRVNVTFRTLCAoKSA9PiB7XG5cdFx0aWYgKE1ldGVvci51c2VySWQoKSkge1xuXHRcdFx0aWYgKFVzZXJIYXNSb2xlKFtSb2xlcy5BRE1JTiwgUm9sZXMuSE9TVCwgUm9sZXMuSlVER0VdKSkge1xuXHRcdFx0XHRyZXR1cm4gUmVzdWx0cy5maW5kKHsgfSlcblx0XHRcdH0gZWxzZSBpZiAoVXNlckhhc1JvbGUoW1JvbGVzLkpVREdFXSkpIHtcblx0XHRcdFx0cmV0dXJuIFtdIC8vIFRPRE9cblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdHJldHVybiBbXVxuXHRcdFx0fVxuXHRcdH1cblx0fSlcbn1cbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbydcbmltcG9ydCB7IFVzZXJIYXNSb2xlIH0gZnJvbSAnLi9hY2NvdW50cydcbmltcG9ydCB7IENvbGxlY3Rpb25zLCBSb2xlcyB9IGZyb20gJy4vaGVscGVycy9lbnVtcydcblxuZXhwb3J0IGludGVyZmFjZSBTY29yZSB7XG5cdF9pZD86IHN0cmluZ1xuXHRzdGF0aW9uSWQ6IHN0cmluZ1xuXHRjYXRlZ29yeUlkOiBzdHJpbmdcblx0anVkZ2VkQnk6IHN0cmluZ1xuXHRjb21tZW50czogc3RyaW5nXG5cdGRhdGU6IG51bWJlclxufVxuXG5leHBvcnQgY29uc3QgU2NvcmVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb248U2NvcmU+KENvbGxlY3Rpb25zLlNDT1JFUylcblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuXHRNZXRlb3IucHVibGlzaChDb2xsZWN0aW9ucy5TQ09SRVMsICgpID0+IHtcblx0XHRpZiAoTWV0ZW9yLnVzZXJJZCgpICYmIFVzZXJIYXNSb2xlKFtSb2xlcy5BRE1JTiwgUm9sZXMuSE9TVCwgUm9sZXMuSlVER0VdKSkge1xuXHRcdFx0cmV0dXJuIFNjb3Jlcy5maW5kKHsgfSlcblx0XHR9XG5cdH0pXG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXG5pbXBvcnQgeyBHZXRVc2VyRnJvbUlkLCBVc2VySGFzUm9sZSB9IGZyb20gJy4vYWNjb3VudHMnXG5pbXBvcnQgeyBDb2xsZWN0aW9ucywgUm9sZXMgfSBmcm9tICcuL2hlbHBlcnMvZW51bXMnXG5cbmV4cG9ydCBpbnRlcmZhY2UgU3RhdGlvbiB7XG5cdF9pZD86IHN0cmluZ1xuXHQvKiogU3RhdGlvbiBmdWxsIG5hbWUgKGFzIHdyaXR0ZW4gb24gYXdhcmQpLiAqL1xuXHRuYW1lOiBzdHJpbmdcblx0LyoqIFdoZXRoZXIgdGhlIHN0YXRpb24gaXMgZWxpZ2libGUgdG8gZW50ZXIgdGhlIGF3YXJkcyAoaXMgYWZmaWxpYXRlZCwgbm90IGRpc3F1YWxpZmllZCkuICovXG5cdGVsaWdpYmxlRm9yRW50cnk6IGJvb2xlYW5cblx0LyoqIFVzZXIgSWRzIG9mIHVzZXJzIGVsaWdhYmxlIHRvIGVudGVyIGF3YXJkcyBvbiBiZWhhbGYgb2YgdGhpcyBzdGF0aW9uLiAqL1xuXHRhdXRob3JpemVkVXNlcnM6IHN0cmluZ1tdXG59XG5cbmV4cG9ydCBjb25zdCBTdGF0aW9ucyA9IG5ldyBNb25nby5Db2xsZWN0aW9uPFN0YXRpb24+KENvbGxlY3Rpb25zLlNUQVRJT05TKVxuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cdE1ldGVvci5wdWJsaXNoKENvbGxlY3Rpb25zLlNUQVRJT05TLCAoKSA9PiB7XG5cdFx0Y29uc3QgaWQgPSBNZXRlb3IudXNlcklkKClcblx0XHRpZiAoaWQpIHtcblx0XHRcdGNvbnN0IHVzZXIgPSBHZXRVc2VyRnJvbUlkKClcblx0XHRcdGlmICh1c2VyKSB7XG5cdFx0XHRcdGlmIChVc2VySGFzUm9sZShbUm9sZXMuQURNSU4sIFJvbGVzLkhPU1RdKSkge1xuXHRcdFx0XHRcdHJldHVybiBTdGF0aW9ucy5maW5kKHsgfSlcblx0XHRcdFx0fSBlbHNlIGlmIChVc2VySGFzUm9sZShbUm9sZXMuSlVER0VdKSkge1xuXHRcdFx0XHRcdHJldHVybiBTdGF0aW9ucy5maW5kKHsgbmFtZTogeyAkbmU6ICdOYVNUQScgfSB9KVxuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdHJldHVybiBTdGF0aW9ucy5maW5kKHsgX2lkOiB1c2VyLnN0YXRpb25JZCwgYXV0aG9yaXplZFVzZXJzOiBpZCB9KVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHR9KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gR2V0U3RhdGlvbkZvclVzZXIgKCk6IFN0YXRpb24gfCB1bmRlZmluZWQge1xuXHRjb25zdCBpZCA9IE1ldGVvci51c2VySWQoKVxuXHRpZiAoaWQpIHtcblx0XHRjb25zdCB1c2VyID0gR2V0VXNlckZyb21JZCgpXG5cdFx0aWYgKHVzZXIgJiYgdXNlci5zdGF0aW9uSWQpIHtcblx0XHRcdHJldHVybiBTdGF0aW9ucy5maW5kT25lKHsgX2lkOiB1c2VyLnN0YXRpb25JZCwgYXV0aG9yaXplZFVzZXJzOiBpZCB9KVxuXHRcdH1cblx0fVxufVxuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TVEFUSU9OUzogU3RhdGlvbltdID0gW1xuXHR7XG5cdFx0bmFtZTogJ05hU1RBJyxcblx0XHRlbGlnaWJsZUZvckVudHJ5OiB0cnVlLFxuXHRcdGF1dGhvcml6ZWRVc2VyczogW11cblx0fVxuXVxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXG5pbXBvcnQgeyBDb2xsZWN0aW9ucyB9IGZyb20gJy4vaGVscGVycy9lbnVtcydcblxuZXhwb3J0IGludGVyZmFjZSBTeXN0ZW1Qcm9wcyB7XG5cdHZlcnNpb246IHN0cmluZ1xufVxuXG5leHBvcnQgY29uc3QgU3lzdGVtID0gbmV3IE1vbmdvLkNvbGxlY3Rpb248U3lzdGVtUHJvcHM+KENvbGxlY3Rpb25zLlNZU1RFTSlcbiIsImltcG9ydCB7IEFjY291bnRzIH0gZnJvbSAnbWV0ZW9yL2FjY291bnRzLWJhc2UnXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0ICcuLi9pbXBvcnRzL2FwaS9hY2NvdW50cydcbmltcG9ydCAnLi4vaW1wb3J0cy9hcGkvYWNjb3VudHMnXG5pbXBvcnQgeyBOYVNUQVVzZXIgfSBmcm9tICcuLi9pbXBvcnRzL2FwaS9hY2NvdW50cydcbmltcG9ydCAnLi4vaW1wb3J0cy9hcGkvZW50cmllcydcbmltcG9ydCAnLi4vaW1wb3J0cy9hcGkvZXZpZGVuY2UnXG5pbXBvcnQgJy4uL2ltcG9ydHMvYXBpL2hlbHBlcnMvbWV0aG9kcydcbmltcG9ydCAnLi4vaW1wb3J0cy9hcGkvanVkZ2VUb0NhdGVnb3J5J1xuaW1wb3J0IHsgSnVkZ2VUb0NhdGVnb3J5IH0gZnJvbSAnLi4vaW1wb3J0cy9hcGkvanVkZ2VUb0NhdGVnb3J5J1xuaW1wb3J0ICcuLi9pbXBvcnRzL2FwaS9yZXN1bHRzJ1xuaW1wb3J0ICcuLi9pbXBvcnRzL2FwaS9zY29yZXMnXG5pbXBvcnQgJy4uL2ltcG9ydHMvYXBpL3N0YXRpb25zJ1xuaW1wb3J0ICcuLi9pbXBvcnRzL2FwaS9zeXN0ZW0nXG5pbXBvcnQgeyBTeXN0ZW0gfSBmcm9tICcuLi9pbXBvcnRzL2FwaS9zeXN0ZW0nXG5pbXBvcnQgeyBBd2FyZHMsIERFRkFVTFRfQVdBUkRTLCBERUZBVUxUX0NBVEVHT1JJRVNfRk9SX0FXQVJEUyB9IGZyb20gJy9pbXBvcnRzL2FwaS9hd2FyZHMnXG5pbXBvcnQgeyBDYXRlZ29yaWVzLCBDYXRlZ29yeSwgREVGQVVMVF9DQVRFR09SSUVTIH0gZnJvbSAnL2ltcG9ydHMvYXBpL2NhdGVnb3JpZXMnXG5pbXBvcnQgeyBERUZBVUxUX0FXQVJEU19OQU1FUywgREVGQVVMVF9DQVRFR09SWV9OQU1FUywgUm9sZXMgfSBmcm9tICcvaW1wb3J0cy9hcGkvaGVscGVycy9lbnVtcydcbmltcG9ydCB7IERFRkFVTFRfU1RBVElPTlMsIFN0YXRpb25zIH0gZnJvbSAnL2ltcG9ydHMvYXBpL3N0YXRpb25zJ1xuXG5mdW5jdGlvbiBpbnNlcnRDYXRlZ29yeSAoY2F0ZWdvcnk6IENhdGVnb3J5KSB7XG5cdENhdGVnb3JpZXMuaW5zZXJ0KGNhdGVnb3J5KVxufVxuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG5cdGlmIChDYXRlZ29yaWVzLmZpbmQoKS5jb3VudCgpID09PSAwKSB7XG5cdFx0REVGQVVMVF9DQVRFR09SSUVTLmZvckVhY2goKGNhdGVnb3J5KSA9PiB7XG5cdFx0XHRpbnNlcnRDYXRlZ29yeShjYXRlZ29yeSlcblx0XHR9KVxuXHR9XG5cblx0aWYgKEF3YXJkcy5maW5kKCkuY291bnQoKSA9PT0gMCkge1xuXHRcdERFRkFVTFRfQVdBUkRTLmZvckVhY2goKGF3YXJkKSA9PiB7XG5cdFx0XHRpZiAoYXdhcmQubmFtZSBpbiBERUZBVUxUX0NBVEVHT1JJRVNfRk9SX0FXQVJEUykge1xuXHRcdFx0XHRERUZBVUxUX0NBVEVHT1JJRVNfRk9SX0FXQVJEU1thd2FyZC5uYW1lXS5mb3JFYWNoKChjYXRlZ29yeSkgPT4ge1xuXHRcdFx0XHRcdGNvbnN0IGNhdCA9IENhdGVnb3JpZXMuZmluZE9uZSh7IG5hbWU6IGNhdGVnb3J5LCBmb3JBd2FyZHM6IGF3YXJkLm5hbWUgfSlcblx0XHRcdFx0XHRpZiAoY2F0ICYmIGNhdC5faWQpIHtcblx0XHRcdFx0XHRcdGF3YXJkLmNhdGVnb3JpZXMucHVzaChjYXQuX2lkKVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSlcblx0XHRcdH1cblxuXHRcdFx0QXdhcmRzLmluc2VydChhd2FyZClcblx0XHR9KVxuXHR9XG5cblx0aWYgKE1ldGVvci51c2Vycy5maW5kKHsgfSkuZmV0Y2goKS5sZW5ndGggPT09IDApIHtcblx0XHRBY2NvdW50cy5jcmVhdGVVc2VyKHsgZW1haWw6ICd0ZWNoQG5hc3RhLnR2JywgcGFzc3dvcmQ6ICdwYXNzd29yZCcgfSlcblx0fVxuXG5cdGlmIChTdGF0aW9ucy5maW5kKCkuY291bnQoKSA9PT0gMCkge1xuXHRcdGNvbnN0IHVzZXIgPSBNZXRlb3IudXNlcnMuZmluZE9uZSh7IGVtYWlsczogeyBhZGRyZXNzOiAndGVjaEBuYXN0YS50dicsIHZlcmlmaWVkOiBmYWxzZSB9IH0pXG5cblx0XHRpZiAodXNlcikge1xuXHRcdFx0REVGQVVMVF9TVEFUSU9OUy5mb3JFYWNoKChzdGF0aW9uKSA9PiB7XG5cdFx0XHRcdFN0YXRpb25zLmluc2VydCh7XG5cdFx0XHRcdFx0Li4uc3RhdGlvbixcblx0XHRcdFx0XHQuLi57XG5cdFx0XHRcdFx0XHRhdXRob3JpemVkVXNlcnM6IFt1c2VyLl9pZF1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0pXG5cdFx0XHR9KVxuXG5cdFx0XHRjb25zdCBuYXN0YSA9IFN0YXRpb25zLmZpbmRPbmUoeyBuYW1lOiAnTmFTVEEnIH0pXG5cdFx0XHRpZiAobmFzdGEpIHtcblx0XHRcdFx0TWV0ZW9yLnVzZXJzLnVwZGF0ZSh1c2VyLl9pZCwge1xuXHRcdFx0XHRcdC4uLnVzZXIsXG5cdFx0XHRcdFx0c3RhdGlvbklkOiBuYXN0YS5faWQsXG5cdFx0XHRcdFx0cm9sZXM6IFtSb2xlcy5BRE1JTiwgUm9sZXMuSlVER0UsIFJvbGVzLkhPU1QsIFJvbGVzLlNUQVRJT05dXG5cdFx0XHRcdH0gYXMgTmFTVEFVc2VyIGFzIE1ldGVvci5Vc2VyKVxuXG5cdFx0XHRcdGNvbnN0IGJlc3RCcm9hZGNhc3RlciA9IENhdGVnb3JpZXMuZmluZE9uZSh7IG5hbWU6IERFRkFVTFRfQ0FURUdPUllfTkFNRVMuTmFTVEFfQVdBUkRTX0JFU1RfQlJPQURDQVNURVIgfSlcblx0XHRcdFx0aWYgKGJlc3RCcm9hZGNhc3RlciAmJiBuYXN0YS5faWQgJiYgYmVzdEJyb2FkY2FzdGVyLl9pZCkge1xuXHRcdFx0XHRcdEp1ZGdlVG9DYXRlZ29yeS5pbnNlcnQoe1xuXHRcdFx0XHRcdFx0anVkZ2VJZDogdXNlci5faWQsXG5cdFx0XHRcdFx0XHRjYXRlZ29yeUlkOiBiZXN0QnJvYWRjYXN0ZXIuX2lkXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdGlmIChKdWRnZVRvQ2F0ZWdvcnkuZmluZCgpLmNvdW50KCkgPT09IDEpIHtcblx0XHQvLyBUT0RPOiBSZW1vdmUsIHRlbXBvcmFyeSBkdXJpbmcgdGVzdGluZ1xuXG5cdFx0Y29uc3QgdXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lKHsgZW1haWxzOiB7IGFkZHJlc3M6ICd0ZWNoQG5hc3RhLnR2JywgdmVyaWZpZWQ6IGZhbHNlIH0gfSlcblxuXHRcdGlmICh1c2VyKSB7XG5cdFx0XHRjb25zdCBjYXRlZ29yaWVzID0gQ2F0ZWdvcmllcy5maW5kKHsgfSkuZmV0Y2goKVxuXG5cdFx0XHRjYXRlZ29yaWVzLmZvckVhY2goKGNhdGVnb3J5KSA9PiB7XG5cdFx0XHRcdGlmIChjYXRlZ29yeS5uYW1lID09PSBERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19CRVNUX0JST0FEQ0FTVEVSKSByZXR1cm5cblx0XHRcdFx0SnVkZ2VUb0NhdGVnb3J5Lmluc2VydCh7XG5cdFx0XHRcdFx0anVkZ2VJZDogdXNlci5faWQsXG5cdFx0XHRcdFx0Y2F0ZWdvcnlJZDogY2F0ZWdvcnkuX2lkIHx8ICcnXG5cdFx0XHRcdH0pXG5cdFx0XHR9KVxuXHRcdH1cblx0fVxuXG5cdC8vIENsZWFyIGF1dGggdG9rZW5zIGFmdGVyIGRlcGxveWluZyBuZXcgdmVyc2lvblxuXHRpZiAoTWV0ZW9yLmlzUHJvZHVjdGlvbikge1xuXHRcdE1ldGVvci51c2Vycy51cGRhdGUoeyB9LCB7ICRzZXQ6IHsgJ3NlcnZpY2VzLnJlc3VtZS5sb2dpblRva2Vucyc6IFtdIH0gfSwgeyBtdWx0aTogdHJ1ZSB9KVxuXHR9XG5cblx0aWYgKFN5c3RlbS5maW5kKCkuZmV0Y2goKS5sZW5ndGggPT09IDApIHtcblx0XHRTeXN0ZW0uaW5zZXJ0KHtcblx0XHRcdHZlcnNpb246ICd2MS4wJ1xuXHRcdH0pXG5cblx0XHRjb25zdCBibG9vcGVyQ2F0ZWdvcnkgPSBDYXRlZ29yaWVzLmZpbmRPbmUoeyBuYW1lOiBERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19TVVBFUl9CTE9PUEVSIH0pXG5cblx0XHRpZiAoIWJsb29wZXJDYXRlZ29yeSkge1xuXHRcdFx0Y29uc3QgdG9JbnNlcnQgPSBERUZBVUxUX0NBVEVHT1JJRVMuZmluZChcblx0XHRcdFx0KGNhdGVnb3J5KSA9PiBjYXRlZ29yeS5uYW1lID09PSBERUZBVUxUX0NBVEVHT1JZX05BTUVTLk5hU1RBX0FXQVJEU19TVVBFUl9CTE9PUEVSXG5cdFx0XHQpXG5cblx0XHRcdGlmICh0b0luc2VydCkge1xuXHRcdFx0XHRjb25zdCBpZCA9IENhdGVnb3JpZXMuaW5zZXJ0KHRvSW5zZXJ0KVxuXG5cdFx0XHRcdGNvbnN0IG5hc3RhID0gQXdhcmRzLmZpbmRPbmUoeyBuYW1lOiBERUZBVUxUX0FXQVJEU19OQU1FUy5OQVNUQSB9KVxuXG5cdFx0XHRcdGlmIChuYXN0YSkge1xuXHRcdFx0XHRcdEF3YXJkcy51cGRhdGUoeyBfaWQ6IG5hc3RhLl9pZCB9LCB7ICRwdXNoOiB7IGNhdGVnb3JpZXM6IGlkIH0gfSlcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fVxufSlcbiJdfQ==
